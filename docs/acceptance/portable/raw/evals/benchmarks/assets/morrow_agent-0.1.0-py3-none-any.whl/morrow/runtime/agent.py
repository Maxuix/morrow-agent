"""Single bounded chat state machine: one AgentLoop, one history write path."""

from __future__ import annotations

import asyncio
import hashlib
import inspect
import json
import logging
import random
import time
from collections.abc import AsyncIterator, Callable
from dataclasses import dataclass, field, replace
from datetime import timedelta
from typing import TYPE_CHECKING

from morrow.application.context import ContextBudgetError
from morrow.application.prepared import PreparedIntentError
from morrow.core.application import ApplicationError
from morrow.core.capabilities import ToolRunContext
from morrow.core.compaction import CompactionSummary, TokenAccountingBasis
from morrow.core.diagnostics import PublicDiagnosticError
from morrow.core.events import completion_payload, make_event
from morrow.core.execution import (
    DurableToolExecution,
    ToolExecutionDisposition,
    ToolExecutionState,
)
from morrow.core.faults import InjectedFault
from morrow.core.models import (
    INTERRUPT_STOP_CODES,
    AgentEvent,
    AgentStopCode,
    AssistantMessage,
    FinishReason,
    FunctionToolCall,
    GenerationOptions,
    Message,
    ModelCompletion,
    ModelCost,
    ModelErrorCode,
    ModelEvent,
    ModelFailure,
    ModelFailureOrigin,
    ModelFinishReason,
    ModelProviderError,
    ModelRef,
    ModelUsage,
    ProtocolModel,
    ToolDefinition,
    UserMessage,
    sanitize_text,
    utc_now,
)
from morrow.core.ports import Clock, IdSource, ModelContentObserver, ModelProvider
from morrow.runtime.completion_check import (
    MAX_COMPLETION_REVIEWS,
    check_completion,
    completion_review_prompt,
    has_acceptance_cues,
)
from morrow.runtime.conversation import ConversationLogError
from morrow.runtime.deadline import RunDeadline, RunDeadlineExceeded
from morrow.runtime.durable_log import durable_call_id
from morrow.runtime.ids import RandomIdSource
from morrow.runtime.provider_retry import RetryWait, next_provider_retry_delay
from morrow.runtime.reasoning_filter import ReasoningRedactor
from morrow.runtime.session import Session
from morrow.runtime.text_stream import TextStreamProjection, project_text
from morrow.runtime.tool_cycle import ToolCycleExecutor, ToolPauseRequested
from morrow.runtime.tools import (
    MIN_ERROR_ENVELOPE_CHARS,
    ToolErrorCode,
    ToolExecutionOutcome,
    ToolExecutor,
)

if TYPE_CHECKING:
    from morrow.application.agent_runs.preparation import PreparedAgentRunRuntime

logger = logging.getLogger("morrow.runtime")

MODEL_ATTEMPT_MAX_SECONDS = 600.0
COMPACTION_MAX_OUTPUT_TOKENS = 4_096


def _model_attempt_seconds(deadline: RunDeadline | None) -> float:
    """Use the run work window when a host deadline already bounds the request."""
    return deadline.require_work() if deadline is not None else MODEL_ATTEMPT_MAX_SECONDS


def _internal_error_fingerprint(exc: Exception, phase: str) -> str:
    """Identify a failure site without serializing its message or traceback."""
    frame = exc.__traceback__
    while frame is not None and frame.tb_next is not None:
        frame = frame.tb_next
    site = f"{frame.tb_frame.f_code.co_name}:{frame.tb_lineno}" if frame is not None else "unknown"
    return hashlib.sha256(f"{type(exc).__name__}:{phase}:{site}".encode()).hexdigest()[:24]


class ModelAttemptExceeded(TimeoutError):
    """A single request ran past its total attempt budget."""


TRANSIENT_MODEL_ERRORS = frozenset(
    {ModelErrorCode.NETWORK, ModelErrorCode.RATE_LIMIT, ModelErrorCode.TIMEOUT}
)
# Server failures share the transient retry path when the adapter marks them
# retryable. Resume accounting without a persisted counter uses the same set.
RESUME_RETRY_CODES = TRANSIENT_MODEL_ERRORS | {ModelErrorCode.INTERNAL}
MODEL_ERROR_STOPS = {
    ModelErrorCode.AUTH: AgentStopCode.PROVIDER_AUTH,
    ModelErrorCode.NETWORK: AgentStopCode.PROVIDER_NETWORK,
    ModelErrorCode.RATE_LIMIT: AgentStopCode.PROVIDER_RATE_LIMIT,
    ModelErrorCode.TIMEOUT: AgentStopCode.PROVIDER_TIMEOUT,
    ModelErrorCode.INVALID_RESPONSE: AgentStopCode.INVALID_RESPONSE,
    ModelErrorCode.CONTEXT_OVERFLOW: AgentStopCode.CONTEXT_BUDGET,
    ModelErrorCode.INTERNAL: AgentStopCode.INTERNAL,
}

# Repeated identical tool failures fund a guessing loop instead of progress:
# the second consecutive failure carries a directed correction, and the third
# field-identified validation failure stops the run. Successful calls and
# changed arguments or outcomes break the streak.
# Operational failures without a field path stay hint-only: changing the
# target may legitimately succeed.
REPEATED_FAILURE_HINT_THRESHOLD = 2
REPEATED_FAILURE_STOP_THRESHOLD = 3
REPEATED_SUCCESS_HINT_THRESHOLD = 3
REPEATED_FAILURE_HINT = (
    "这已是第 {count} 次以相同方式失败的工具调用（工具 {tool}，错误 {code}，"
    "位置 {path}）。请先阅读上方错误信息并改变方法，不要重复相同调用。"
)


class ModelCallOutcome(ProtocolModel):
    """One interpreted Provider attempt; carries no SDK objects or fragments."""

    message: AssistantMessage | None = None
    finish_reason: ModelFinishReason | None = None
    failure: ModelFailure | None = None
    usage: ModelUsage = ModelUsage.unavailable()
    cost: ModelCost = ModelCost.unavailable()


class ModelCallRunner:
    """Interprets one Provider attempt; never touches Session or history."""

    def __init__(
        self, provider: ModelProvider, model: ModelRef, generation: GenerationOptions | None = None
    ) -> None:
        self.provider = provider
        self.model = model
        self.generation = generation or GenerationOptions()
        self._outcome = ModelCallOutcome()

    async def attempt(
        self,
        messages: list[Message],
        tools: tuple[ToolDefinition, ...] = (),
    ) -> AsyncIterator[ModelEvent]:
        self._outcome = ModelCallOutcome()
        try:
            options = (
                {"generation": self.generation}
                if self.generation.reasoning_effort is not None
                else {}
            )
            async for model_event in self.provider.stream(self.model, messages, tools, **options):
                if model_event.kind == "completed":
                    self._outcome = self._classify_completion(model_event)
                elif model_event.kind == "error":
                    self._outcome = ModelCallOutcome(
                        failure=model_event.failure
                        or ModelFailure(
                            code=ModelErrorCode.INTERNAL,
                            origin=ModelFailureOrigin.ADAPTER,
                            message="模型服务发生未预期错误",
                        ),
                        usage=model_event.usage,
                        cost=model_event.cost,
                    )
                yield model_event
            if self._outcome.message is None and self._outcome.failure is None:
                # The iterator ended before a completion or an adapter failure.
                # That is an empty stream, not a semantic rejection: it is
                # retryable only until an assistant or tool intent is committed.
                self._outcome = ModelCallOutcome(
                    failure=ModelFailure(
                        code=ModelErrorCode.INVALID_RESPONSE,
                        origin=ModelFailureOrigin.PROVIDER,
                        retryable=True,
                        message="模型响应未正常结束",
                    ),
                    usage=self._outcome.usage,
                    cost=self._outcome.cost,
                )
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            self._outcome = ModelCallOutcome(
                failure=(
                    exc.failure
                    if isinstance(exc, ModelProviderError)
                    else ModelFailure(
                        code=ModelErrorCode.INTERNAL,
                        origin=ModelFailureOrigin.ADAPTER,
                        message="模型服务发生未预期错误",
                    )
                ),
                usage=self._outcome.usage,
                cost=self._outcome.cost,
            )

    @property
    def outcome(self) -> ModelCallOutcome:
        return self._outcome

    @staticmethod
    def _classify_completion(model_event: ModelEvent) -> ModelCallOutcome:
        reason = model_event.finish_reason
        message = model_event.message
        if reason not in (ModelFinishReason.STOP, ModelFinishReason.TOOL_CALLS):
            return ModelCallOutcome(
                finish_reason=reason,
                failure=ModelFailure(
                    code=ModelErrorCode.INVALID_RESPONSE,
                    origin=ModelFailureOrigin.PROVIDER,
                    message="模型响应未正常结束",
                ),
                usage=model_event.usage,
                cost=model_event.cost,
            )
        if reason == ModelFinishReason.STOP:
            if message is None or not (message.content or "").strip() or bool(message.tool_calls):
                return ModelCallOutcome(
                    finish_reason=reason,
                    failure=ModelFailure(
                        code=ModelErrorCode.INVALID_RESPONSE,
                        origin=ModelFailureOrigin.PROVIDER,
                        message="模型没有返回可见文本",
                    ),
                    usage=model_event.usage,
                    cost=model_event.cost,
                )
        elif message is None or not message.tool_calls:
            return ModelCallOutcome(
                finish_reason=reason,
                failure=ModelFailure(
                    code=ModelErrorCode.INVALID_RESPONSE,
                    origin=ModelFailureOrigin.PROVIDER,
                    message="模型没有返回工具调用",
                ),
                usage=model_event.usage,
                cost=model_event.cost,
            )
        return ModelCallOutcome(
            message=message,
            finish_reason=reason,
            usage=model_event.usage,
            cost=model_event.cost,
        )


def _can_retry_provider_failure(failure: ModelFailure) -> bool:
    """Retry a failed request before its assistant response has been committed.

    Both callers inspect the outcome before appending assistant or tool intent.
    Prior tool cycles remain in durable history and are never dispatched here.
    """

    return failure.retryable and failure.code in RESUME_RETRY_CODES | {
        ModelErrorCode.INVALID_RESPONSE
    }


def _pending_cancellation() -> bool:
    task = asyncio.current_task()
    return bool(task and task.cancelling())


def _consume_cancellation_request() -> None:
    task = asyncio.current_task()
    if task is not None:
        while task.cancelling():
            task.uncancel()


async def _next_stream_event(stream):
    """Await one provider event with a race-safe StopAsyncIteration mapping."""
    try:
        return ("event", await anext(stream))
    except StopAsyncIteration:
        return ("stop", None)


def _remaining_text_chunks(
    projection: TextStreamProjection, chunks: list[str], message: AssistantMessage
) -> tuple[list[str], bool]:
    """Preserve accepted chunk boundaries when no line has been displayed early."""
    had_preview = bool(projection.emitted)
    remainder, reset = projection.finish(message.content or "")
    if not had_preview and chunks and "".join(chunks) == remainder:
        return chunks, reset
    return ([remainder] if remainder else []), reset


def _failure_hint(result: ToolExecutionOutcome, count: int) -> str:
    return REPEATED_FAILURE_HINT.format(
        count=count,
        tool=result.name,
        code=result.error_code.value if result.error_code is not None else "unknown",
        path=result.validation_path or "$",
    )


def _with_failure_hint(result: ToolExecutionOutcome, count: int) -> ToolExecutionOutcome:
    """Attach one bounded, reviewed correction to a repeated-failure envelope.

    The augmentation is additive and best-effort: an unparsable or already
    hinted envelope is returned unchanged, and the durable execution record
    keeps the handler's original envelope either way.
    """

    try:
        payload = json.loads(result.envelope)
    except (TypeError, ValueError, json.JSONDecodeError):
        return result
    if not isinstance(payload, dict):
        return result
    error = payload.get("error")
    if not isinstance(error, dict) or "hint" in error:
        return result
    hinted = {
        **payload,
        "error": {**error, "hint": _failure_hint(result, count)},
    }
    encoded = json.dumps(hinted, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return replace(result, envelope=encoded)


def _fingerprint(value: str) -> str:
    """Compare JSON values without keeping raw tool arguments or results in run state."""

    try:
        normalized = json.dumps(
            json.loads(value), ensure_ascii=False, sort_keys=True, separators=(",", ":")
        )
    except (TypeError, ValueError):
        normalized = value.strip()
    return hashlib.sha256(normalized.encode("utf-8")).hexdigest()


def _with_repeated_success_hint(
    result: ToolExecutionOutcome, *, result_limit: int
) -> ToolExecutionOutcome:
    """Suggest a different approach after repeated identical successes; never stop a poll."""

    try:
        payload = json.loads(result.envelope)
    except (TypeError, ValueError):
        return result
    if not isinstance(payload, dict) or "hint" in payload:
        return result
    hinted = {
        **payload,
        "hint": "连续三次相同工具调用返回相同结果，可能没有推进任务。请检查状态或尝试其他方法。",
    }
    encoded = json.dumps(hinted, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return replace(result, envelope=encoded) if len(encoded) <= result_limit else result


@dataclass
class _AgentRunState:
    """Mutable state for one AgentLoop run."""

    turn_id: str
    run_context: ToolRunContext
    agent_run_id: str | None = None
    visible: str = ""
    model_attempts: int = 0
    tool_rounds: int = 0
    tool_calls: int = 0
    retry_count: int = 0
    total_retry_count: int = 0
    summary_retry_count: int = 0
    retry_wait: RetryWait = field(default_factory=RetryWait)
    omission_floor: int = 0
    max_estimated_request_chars: int = 0
    request_char_budget: int = 1
    cleared_cycle_count: int = 0
    dropped_turn_count: int = 0
    dropped_cycle_count: int = 0
    dropped_record_count: int = 0
    compaction_count: int = 0
    overflow_recovery_count: int = 0
    context_observation_count: int = 0
    max_context_tokens: int = 0
    last_context_tokens: int | None = None
    accounting_basis: TokenAccountingBasis | None = None
    active_calls: tuple[FunctionToolCall, ...] = ()
    durable_executions: tuple[DurableToolExecution, ...] = ()
    active_running_id: str | None = None
    active_result_limit: int | None = None
    final_committed: bool = False
    facts_retained: bool = False
    started: bool = False
    settled: bool = False
    observation_finalized: bool = False
    crashed: bool = False
    terminal_finish_reason: FinishReason | None = None
    stop_code: AgentStopCode | None = None
    paused_generation: int | None = None
    internal_phase: str = "run_setup"
    stop_detail: str | None = None
    pending_steering_text: str | None = None
    failure_streak_key: tuple[str, str, str, str, str] | None = None
    failure_streak_count: int = 0
    success_streak_key: tuple[str, str, str] | None = None
    success_streak_count: int = 0


class _RunEventEmitter:
    """Render one run's ordered public events without owning loop transitions."""

    def __init__(
        self,
        *,
        new_id: Callable[[str], str],
        session: Session,
        clock: Clock | None,
        turn_id: Callable[[], str],
        visible: Callable[[], str],
        retain_facts: Callable[[str], None],
    ) -> None:
        self.new_id = new_id
        self.session = session
        self.clock = clock
        self.turn_id = turn_id
        self.visible = visible
        self.retain_facts = retain_facts
        self.sequence = 0

    def event(self, event_type: str, payload: dict) -> AgentEvent:
        self.sequence += 1
        return make_event(
            event_type=event_type,
            event_id=self.new_id("evt"),
            session_id=self.session.session_id,
            turn_id=self.turn_id(),
            sequence=self.sequence,
            payload=payload,
            timestamp=self.clock.now() if self.clock else None,
        )

    def fatal(self, message: str, stop_code: AgentStopCode) -> tuple[AgentEvent, AgentEvent]:
        return (
            self.event(
                "error",
                {"message": sanitize_text(message), "stop_code": stop_code.value},
            ),
            self.event(
                "turn.completed",
                completion_payload(FinishReason.ERROR, self.visible(), stop_code=stop_code),
            ),
        )

    def tool_status(
        self,
        call,
        status: str,
        ordinal: int,
        total: int,
        *,
        error_code: ToolErrorCode | None = None,
        truncated: bool = False,
    ) -> AgentEvent:
        payload = {
            "call_id": call.id,
            "name": call.name,
            "status": status,
            "ordinal": ordinal,
            "total": total,
        }
        if error_code is not None:
            payload["error_code"] = error_code.value
        if truncated:
            payload["truncated"] = True
        return self.event("tool.status", payload)

    def terminal_error(
        self,
        message: str,
        stop_code: AgentStopCode,
        *,
        interrupted: tuple[str, ...] = (),
    ) -> tuple[AgentEvent, AgentEvent]:
        self.session.finish_turn(
            FinishReason.ERROR,
            interrupted_call_ids=interrupted,
            stop_code=stop_code,
        )
        self.retain_facts(FinishReason.ERROR.value)
        return self.fatal(message, stop_code)

    def synthetic_statuses(
        self,
        unresolved: tuple[str, ...],
        *,
        active_calls,
        active_running_id: str | None,
        code: ToolErrorCode,
        running_status: str,
    ) -> list[AgentEvent]:
        statuses = []
        by_id = {call.id: (index, call) for index, call in enumerate(active_calls, start=1)}
        for call_id in unresolved:
            ordinal, call = by_id[call_id]
            status = running_status if call_id == active_running_id else "skipped"
            statuses.append(
                self.tool_status(
                    call,
                    status,
                    ordinal,
                    len(active_calls),
                    error_code=code,
                )
            )
        return statuses


class AgentLoop:
    """Owns task lifecycle, budgets, tool execution and every chat history write."""

    def __init__(
        self,
        provider: ModelProvider,
        model: ModelRef,
        context_builder,
        *,
        id_source: IdSource | None = None,
        clock: Clock | None = None,
        tool_executor: ToolExecutor | None = None,
        grant_provider=None,
        should_stop_after_turn=None,
        retry_sleep=None,
        retry_unit: Callable[[], float] | None = None,
        runtime_control=None,
        activity_observer: ModelContentObserver | None = None,
        steering_mode: str = "end_turn",
        pause_control=None,
        monotonic_clock: Callable[[], float] = time.monotonic,
    ) -> None:
        self.runner = ModelCallRunner(provider, model)
        self.context_builder = context_builder
        self.id_source = id_source or RandomIdSource()
        self.clock = clock
        self.run_policy = context_builder.run_policy
        self.tool_executor = tool_executor
        self.grant_provider = grant_provider
        self.should_stop_after_turn = should_stop_after_turn
        self.retry_sleep = retry_sleep or asyncio.sleep
        self.retry_unit = retry_unit or random.random
        self.runtime_control = runtime_control
        self.activity_observer = activity_observer
        self.activity_observer_drops = 0
        # Leaf drives inject steering at the next request boundary; plain chat
        # keeps the end-turn + orchestrator re-submit semantics.
        self.steering_mode = steering_mode
        # Optional durable pause authority (P03): None keeps plain chat on its
        # exact existing path — no control reads, no wake tasks, no new events.
        self.pause_control = pause_control
        self.monotonic_clock = monotonic_clock
        self.tool_cycle = (
            ToolCycleExecutor(
                tool_executor,
                self.run_policy,
                wall_now=self._wall_now,
                activity_listener=self._tool_activity_listener,
                output_listener_factory=self._tool_output_listener_factory,
                pause_control=pause_control,
            )
            if tool_executor is not None
            else None
        )

    def _tool_output_listener_factory(self, call):
        """Bounded realtime stdout/stderr sink for one tool call (P4.3)."""

        def listener(stream: str, text: str) -> None:
            observer = self.activity_observer
            if observer is None or not text:
                return
            try:
                observer.tool_output(
                    call_id=call.id,
                    text=text.encode("utf-8")[:4096].decode("utf-8", errors="ignore"),
                )
            except Exception:
                if self.activity_observer_drops < 10_000:
                    self.activity_observer_drops += 1

        return listener

    def _tool_activity_listener(self, fact: dict) -> None:
        """Forward one real tool transition to the projection observer (P4.1)."""
        observer = self.activity_observer
        if observer is None:
            return
        try:
            observer.tool_observation(
                call_id=fact["call_id"],
                tool_name=fact["tool_name"],
                ordinal=fact["ordinal"],
                total=fact["total"],
                phase=fact["phase"],
                timestamp=fact["timestamp"],
                disposition=fact.get("disposition"),
                arguments_json=fact.get("arguments_json"),
                facts=fact.get("facts", ()),
                artifact_refs=fact.get("artifact_refs", ()),
                error_code=fact.get("error_code"),
                validation_reason=fact.get("validation_reason"),
                validation_path=fact.get("validation_path"),
                tool_execution_id=fact.get("tool_execution_id"),
            )
        except Exception:
            if self.activity_observer_drops < 10_000:
                self.activity_observer_drops += 1

    def _notify_reasoning(self, *, turn_id: str, attempt_ordinal: int, fragment: str) -> None:
        """Best-effort reasoning projection; never raises, never stores content."""
        observer = self.activity_observer
        if observer is None or not fragment:
            return
        try:
            observer.reasoning_delta(
                turn_id=turn_id, attempt_ordinal=attempt_ordinal, fragment=fragment
            )
        except Exception:
            # Bounded error counting only: never the fragment, never a raise.
            if self.activity_observer_drops < 10_000:
                self.activity_observer_drops += 1

    def _id(self, prefix: str) -> str:
        return self.id_source.new_id(prefix)

    def _retry_sample(self) -> float:
        try:
            return float(self.retry_unit())
        except (TypeError, ValueError):
            return 0.0

    def _pause_signal(self, session: Session):
        """Authority read of the durable pause intent; never raises."""
        control = self.pause_control
        if control is None:
            return None
        try:
            return control.pending_signal(session.session_id)
        except Exception:
            return None

    async def _next_model_step(self, session: Session, stream, waiter):
        """One consume step of the model stream, racing the pause wake signal.

        Returns ``((kind, value), waiter)`` where kind is one of ``event``,
        ``stop``, ``pause`` or ``continue`` (a spurious wake: keep waiting).
        The default path (no pause control) awaits ``anext`` directly and keeps
        the exact cancellation semantics of plain chat.
        """
        if self.pause_control is None:
            try:
                return ("event", await anext(stream)), waiter
            except StopAsyncIteration:
                return ("stop", None), waiter
        if waiter is None:
            waiter = asyncio.ensure_future(self.pause_control.wait_signal(session.session_id))
        task = asyncio.ensure_future(_next_stream_event(stream))
        try:
            done, _pending = await asyncio.wait({task, waiter}, return_when=asyncio.FIRST_COMPLETED)
        except BaseException:
            task.cancel()
            waiter.cancel()
            await asyncio.gather(task, waiter, return_exceptions=True)
            raise
        if task in done:
            if not waiter.done():
                waiter.cancel()
                await asyncio.gather(waiter, return_exceptions=True)
            return task.result(), None
        signal = self._pause_signal(session)
        task.cancel()
        await asyncio.gather(task, return_exceptions=True)
        if signal is None:
            return ("continue", None), waiter
        waiter.cancel()
        await asyncio.gather(waiter, return_exceptions=True)
        return ("pause", signal), None

    def _wall_now(self, session: Session | None = None):
        if self.clock is not None:
            return self.clock.now()
        if session is not None and session.durable_runtime is not None:
            return session.durable_runtime.now()
        return utc_now()

    async def _request_pending_grant(self, session: Session) -> None:
        if not session.pending_full_access_grant:
            return
        if self.grant_provider is None:
            raise RuntimeError("本地 Host 权限授予接口不可用")
        result = self.grant_provider(session)
        if inspect.isawaitable(result):
            result = await result
        if not result:
            raise RuntimeError("本地 Host 权限授予未完成")
        session.pending_full_access_grant = False

    async def _host_stop_requested(self, session: Session, message: AssistantMessage) -> bool:
        """Ask the optional host hook at Pi's completed-tool-turn boundary."""

        hook = self.should_stop_after_turn
        if hook is None:
            return False
        try:
            parameters = tuple(inspect.signature(hook).parameters.values())
        except (TypeError, ValueError):
            result = hook(session, message)
        else:
            positional = tuple(
                item
                for item in parameters
                if item.kind
                in (inspect.Parameter.POSITIONAL_ONLY, inspect.Parameter.POSITIONAL_OR_KEYWORD)
            )
            accepts_many = any(item.kind is inspect.Parameter.VAR_POSITIONAL for item in parameters)
            if accepts_many or len(positional) >= 2:
                result = hook(session, message)
            elif len(positional) == 1:
                result = hook(session)
            else:
                result = hook()
        if inspect.isawaitable(result):
            result = await result
        return bool(result)

    async def _steering_pending(self, session: Session) -> bool:
        control = self.runtime_control
        if control is None:
            return False
        result = control.peek_steering(session.session_id)
        if inspect.isawaitable(result):
            result = await result
        return result is not None

    async def _take_steering(self, session: Session):
        """Atomically consume one pending steering entry (P6.3 inject mode)."""
        control = self.runtime_control
        if control is None:
            return None
        result = control.consume_first_steering(session.session_id)
        if inspect.isawaitable(result):
            result = await result
        return result

    async def _compact_context(
        self,
        session: Session,
        provider,
        model,
        context_builder,
        *,
        instructions: str = "",
        tools=(),
        retry_observer: Callable[[float], None] | None = None,
        request_admitter=None,
        request_settler=None,
        retry_wait: RetryWait | None = None,
    ) -> bool:
        """Generate and install one immutable summary projection."""

        if session.compaction_in_progress:
            raise ContextBudgetError("上下文压缩正在进行中")
        candidate = context_builder.prepare_compaction(
            session, instructions=instructions, tools=tuple(tools)
        )
        if candidate is None:
            return False
        session.compaction_in_progress = True
        try:
            try:
                if not callable(getattr(provider, "complete", None)) and not callable(
                    getattr(provider, "complete_result", None)
                ):
                    raise ContextBudgetError(
                        "当前 Provider 不支持上下文压缩",
                        cause_phase="summary_request",
                        cause_code="unsupported_provider",
                    )
                completion = await self._complete_compaction_summary(
                    provider,
                    model,
                    list(candidate.summary_messages),
                    context_builder.run_policy,
                    retry_observer=retry_observer,
                    request_admitter=request_admitter,
                    request_settler=request_settler,
                    retry_wait=retry_wait,
                )
                try:
                    summary = CompactionSummary.from_provider_text(completion.content)
                except ValueError as exc:
                    raise ContextBudgetError(
                        "上下文压缩摘要无效",
                        cause_phase="summary_parse",
                        cause_code="invalid_summary",
                    ) from exc
            except asyncio.CancelledError:
                raise
            except ContextBudgetError:
                raise
            except ModelProviderError as exc:
                raise ContextBudgetError(
                    "上下文压缩失败，请稍后重试",
                    cause_phase=exc.cause_phase or "summary_request",
                    cause_code=exc.code.value,
                    http_status_class=exc.http_status_class,
                ) from exc
            except ApplicationError:
                raise
            except Exception as exc:
                raise ContextBudgetError(
                    "上下文压缩失败，请稍后重试",
                    cause_phase="summary_request",
                    cause_code="internal_error",
                ) from exc
            # Persistence and in-memory installation are outside the summary
            # fallback boundary. A failed commit must not become an omission.
            durable_runtime = session.durable_runtime
            context_builder.apply_compaction(
                session,
                candidate,
                summary,
                entry_id=self._id("cmp"),
                model=model,
                task_run_id=(
                    durable_runtime.current_task_run_id if durable_runtime is not None else None
                ),
                agent_run_id=(
                    durable_runtime.current_agent_run_id if durable_runtime is not None else None
                ),
                usage=completion.usage,
                cost=completion.cost,
            )
            return True
        finally:
            session.compaction_in_progress = False

    async def _complete_compaction_summary(
        self,
        provider,
        model,
        messages: list[Message],
        policy,
        *,
        retry_observer: Callable[[float], None] | None = None,
        request_admitter=None,
        request_settler=None,
        retry_wait: RetryWait | None = None,
    ) -> ModelCompletion:
        """Use the same bounded transient-retry policy for LLM summaries as agent requests."""

        wait = retry_wait if retry_wait is not None else RetryWait()
        wait.reset_window()
        retry_count = 0
        while True:
            admission = request_admitter(messages) if request_admitter is not None else None
            completion = None
            failure = None
            cancelled = False
            try:
                complete_result = getattr(provider, "complete_result", None)
                if callable(complete_result):
                    result = await complete_result(
                        model,
                        messages,
                        max_output_tokens=min(COMPACTION_MAX_OUTPUT_TOKENS, policy.reserve_tokens),
                    )
                    if not isinstance(result, ModelCompletion):
                        raise TypeError("completion result must contain normalized facts")
                    completion = result
                else:
                    # String-only injected providers retain their existing contract. Unknown
                    # usage stays explicitly unavailable rather than being counted as zero.
                    completion = ModelCompletion(
                        content=await provider.complete(model, messages),
                        finish_reason=ModelFinishReason.STOP,
                    )
                if (
                    completion.finish_reason is not ModelFinishReason.STOP
                    or not completion.content.strip()
                ):
                    raise ModelProviderError(
                        ModelFailure(
                            code=ModelErrorCode.INVALID_RESPONSE,
                            origin=ModelFailureOrigin.PROVIDER,
                            message="上下文压缩响应未正常结束",
                        ),
                        cause_phase="summary_parse",
                    )
            except asyncio.CancelledError:
                cancelled = True
                raise
            except Exception as exc:
                failure = (
                    exc
                    if isinstance(exc, ModelProviderError)
                    else ModelProviderError(
                        ModelFailure(
                            code=ModelErrorCode.INTERNAL,
                            origin=ModelFailureOrigin.ADAPTER,
                            message="上下文压缩请求失败",
                        ),
                        cause_phase="summary_request",
                    )
                )
                if failure.cause_phase is None or failure.cause_phase.startswith("completion_"):
                    phase = (
                        "summary_parse"
                        if failure.cause_phase == "completion_parse"
                        else "summary_request"
                    )
                    failure = ModelProviderError(
                        failure.failure,
                        cause_phase=phase,
                        http_status_class=failure.http_status_class,
                    )
            finally:
                if admission is not None and request_settler is not None:
                    request_settler(
                        admission,
                        state_name="cancelled"
                        if cancelled
                        else "failed"
                        if failure
                        else "completed",
                        finish_reason=completion.finish_reason
                        if completion and not cancelled
                        else None,
                        error_code=failure.code if failure else None,
                        usage=completion.usage if completion else ModelUsage.unavailable(),
                        cost=completion.cost if completion else ModelCost.unavailable(),
                    )
            if failure is None:
                wait.reset_window()
                return completion
            if failure.code is ModelErrorCode.CONTEXT_OVERFLOW:
                raise ContextBudgetError(
                    "上下文压缩请求超过模型上下文限制",
                    cause_phase=failure.cause_phase or "summary_request",
                    cause_code=failure.code.value,
                    http_status_class=failure.http_status_class,
                ) from failure
            if not policy.retry_enabled or not _can_retry_provider_failure(failure.failure):
                raise failure
            wait.begin(self._wall_now())
            delay = next_provider_retry_delay(
                policy=policy,
                retry_index=retry_count + 1,
                retry_after_seconds=failure.retry_after_seconds,
                waited_seconds=wait.seconds,
                total_waited_seconds=wait.total_seconds,
                elapsed_seconds=wait.elapsed(self._wall_now()),
                unit=self._retry_sample(),
            )
            if delay is None:
                raise failure
            retry_count += 1
            wait.add(delay)
            if retry_observer is not None:
                retry_observer(delay)
            await self.retry_sleep(delay)

    async def compact_idle(self, session: Session, *, instructions: str = "") -> bool:
        """Run the manual Pi-style compaction command only while the Session is idle."""

        if session.read_only:
            raise ContextBudgetError("只读 Session 不能持久化上下文压缩")
        if session.log.has_active_turn:
            raise ContextBudgetError("手动上下文压缩只能在 Session 空闲时执行")
        return await self._compact_context(
            session,
            self.runner.provider,
            self.runner.model,
            self.context_builder,
            instructions=instructions,
        )

    async def run_task(
        self,
        session: Session,
        user_input: str,
        *,
        client_message_id: str | None = None,
        resume_current_turn: bool = False,
        prepared: PreparedAgentRunRuntime | None = None,
        startup_error: str | ApplicationError | None = None,
        agent_run_id: str | None = None,
        cancelled_is_user: bool | Callable[[], bool] = True,
        run_timeout_seconds: float | None = None,
    ) -> AsyncIterator[AgentEvent]:
        deadline = (
            RunDeadline.from_seconds(run_timeout_seconds, clock=self.monotonic_clock)
            if run_timeout_seconds is not None
            else None
        )
        client_message_id = client_message_id or self._id("cmsg")
        if prepared is not None:
            provider = prepared.provider
            model = prepared.model
            context_builder = prepared.context_builder
            tool_executor = prepared.tool_executor
            policy = prepared.run_policy
        else:
            provider = self.runner.provider
            model = self.runner.model
            context_builder = self.context_builder
            tool_executor = self.tool_executor
            policy = self.run_policy
        if session.latest_model_usage_model not in (None, model):
            session.latest_model_usage = ModelUsage.unavailable()
            session.latest_model_usage_context_digest = None
            session.latest_model_usage_message_count = None
        if not resume_current_turn:
            session.pending_prompt_projection = None
        prompt_projection = None
        if not resume_current_turn and startup_error is None:
            prepare_prompt = getattr(context_builder, "prepare_prompt_projection", None)
            if callable(prepare_prompt):
                try:
                    prompt_projection = prepare_prompt(user_input)
                    session.pending_prompt_projection = prompt_projection
                except Exception as exc:
                    # Project-instruction diagnostics are already bounded and value-free;
                    # unknown preparation failures stay at the fixed public boundary.
                    code = getattr(exc, "code", "prompt_assembly")
                    if not isinstance(code, str) or not code.isidentifier():
                        code = "prompt_assembly"
                    startup_error = f"项目指令读取受阻（{code}），请先检查具体文件状态。"
        prepared_spec = prepared.spec if prepared is not None else None
        if prepared_spec is not None and prompt_projection is not None:
            evidence = prompt_projection.evidence
            prepared_spec = prepared_spec.model_copy(
                update={
                    "prompt_profile_id": evidence.profile_id,
                    "prompt_profile_version": evidence.profile_version,
                    "prompt_profile_digest": evidence.profile_digest,
                    "role_prompt_digest": evidence.role_prompt_digest,
                    "project_instruction_resolver_version": (
                        evidence.project_instruction_resolver_version
                    ),
                    "project_instruction_sources": evidence.project_instruction_sources,
                    "project_instruction_selection_digest": (
                        evidence.project_instruction_selection_digest
                    ),
                }
            )
        runner = ModelCallRunner(
            provider,
            model,
            prepared.spec.provider_runtime.generation if prepared is not None else None,
        )
        tool_cycle = (
            ToolCycleExecutor(
                tool_executor,
                policy,
                wall_now=self._wall_now,
                activity_listener=self._tool_activity_listener,
                output_listener_factory=self._tool_output_listener_factory,
            )
            if tool_executor is not None
            else None
        )
        durable_runtime = session.durable_runtime
        initial_turn_id = self._id("turn")
        initial_agent_run_id = (
            getattr(durable_runtime, "current_agent_run_id", None)
            if durable_runtime is not None and resume_current_turn
            else None
        )
        state = _AgentRunState(
            turn_id=initial_turn_id,
            run_context=ToolRunContext(
                run_id=initial_agent_run_id or initial_turn_id,
                session_id=session.session_id,
            ),
            agent_run_id=initial_agent_run_id,
        )
        completion_review_count = 0
        completion_review_tool_calls = 0
        pending_completion_review: str | None = None

        observation_runtime = (
            durable_runtime
            if durable_runtime is not None
            and callable(getattr(durable_runtime, "admit_model_request", None))
            else None
        )

        def install_agent_run(agent_run_id: str | None) -> None:
            if agent_run_id is None:
                return
            state.agent_run_id = agent_run_id
            state.run_context = ToolRunContext(
                run_id=agent_run_id,
                session_id=session.session_id,
            )

        def restore_observation_progress() -> None:
            """Continue a resumed AgentRun after already-settled request rows."""

            if not resume_current_turn or observation_runtime is None or state.agent_run_id is None:
                return
            getter = getattr(observation_runtime, "get_agent_run_observation", None)
            if not callable(getter):
                return
            observation = getter(state.agent_run_id)
            if observation is None or not observation.requests:
                return
            requests = observation.requests
            latest = observation.requests[-1]
            latest_is_open = latest.state.value == "admitted"
            state.model_attempts = max(
                0,
                max(item.attempt_ordinal for item in requests) - (1 if latest_is_open else 0),
            )
            state.max_estimated_request_chars = max(
                item.estimated_request_chars for item in requests
            )
            state.request_char_budget = latest.request_char_budget
            state.cleared_cycle_count = sum(item.cleared_cycle_count for item in requests)
            state.dropped_turn_count = sum(item.dropped_turn_count for item in requests)
            state.dropped_cycle_count = sum(item.dropped_cycle_count for item in requests)
            state.dropped_record_count = sum(item.dropped_record_count for item in requests)
            state.tool_rounds = max(item.tool_rounds for item in requests)
            state.tool_calls = max(item.tool_calls for item in requests)
            context_requests = [
                item for item in requests if item.estimated_context_tokens is not None
            ]
            if context_requests:
                state.context_observation_count = len(context_requests)
                state.max_context_tokens = max(
                    item.estimated_context_tokens for item in context_requests
                )
                state.last_context_tokens = context_requests[-1].estimated_context_tokens
                bases = {item.accounting_basis for item in context_requests}
                state.accounting_basis = bases.pop() if len(bases) == 1 else None
            settled_before_latest = requests[:-1] if latest_is_open else requests
            retry_progress = getattr(observation, "retry_progress", None)
            if retry_progress is not None:
                state.total_retry_count = retry_progress.total_retry_count
                state.retry_count = retry_progress.consecutive_model_retries
                state.summary_retry_count = retry_progress.summary_retry_count
                if retry_progress.total_retry_wait_seconds is not None:
                    state.retry_wait.seconds = retry_progress.retry_wait_seconds or 0.0
                    state.retry_wait.total_seconds = retry_progress.total_retry_wait_seconds
                    state.retry_wait.started_at = retry_progress.retry_window_started_at
                else:
                    # Older rows lack delays; do not grant a fresh budget on resume.
                    state.retry_wait.seconds = min(state.retry_count * 60.0, 120.0)
                    state.retry_wait.total_seconds = min(state.total_retry_count * 60.0, 600.0)
                if state.retry_count and state.retry_wait.started_at is None:
                    state.retry_wait.started_at = self._wall_now(session) - timedelta(seconds=120)
                return

            # Before the first retry-progress write, derive only transient failures;
            # an arbitrary non-retryable or overflow failure must never consume the retry budget.
            transient_codes = RESUME_RETRY_CODES
            state.total_retry_count = sum(
                item.state.value == "failed" and item.error_code in transient_codes
                for item in settled_before_latest
            )
            trailing_failures = 0
            for index in range(len(settled_before_latest) - 1, -1, -1):
                item = settled_before_latest[index]
                if item.state.value != "failed" or item.error_code not in transient_codes:
                    break
                trailing_failures += 1
            state.retry_count = trailing_failures
            state.retry_wait.seconds = min(trailing_failures * 60.0, 120.0)
            state.retry_wait.total_seconds = min(state.total_retry_count * 60.0, 600.0)
            if trailing_failures:
                state.retry_wait.started_at = self._wall_now(session) - timedelta(seconds=120)

        def settle_model_request(
            admission,
            *,
            state_name: str,
            finish_reason: ModelFinishReason | None = None,
            error_code: ModelErrorCode | None = None,
            usage: ModelUsage | None = None,
            cost: ModelCost | None = None,
        ) -> None:
            if admission is None or observation_runtime is None:
                return
            try:
                observation_runtime.settle_model_request(
                    admission.model_request_id,
                    state=state_name,
                    finish_reason=finish_reason,
                    error_code=error_code,
                    usage=usage or ModelUsage.unavailable(),
                    cost=cost or ModelCost.unavailable(),
                )
            except Exception:
                # A failed observation write remains visible as an open request;
                # it must never replace the existing public terminal lifecycle.
                return

        def persist_retry_progress() -> None:
            if (
                observation_runtime is None
                or state.agent_run_id is None
                or not callable(getattr(observation_runtime, "record_retry_progress", None))
            ):
                return
            try:
                observation_runtime.record_retry_progress(
                    agent_run_id=state.agent_run_id,
                    consecutive_model_retries=state.retry_count,
                    total_retry_count=state.total_retry_count,
                    summary_retry_count=state.summary_retry_count,
                    retry_wait_seconds=state.retry_wait.seconds,
                    total_retry_wait_seconds=state.retry_wait.total_seconds,
                    retry_window_started_at=state.retry_wait.started_at,
                )
            except Exception:
                # Retry telemetry is bounded best-effort evidence and must not replace the
                # existing public AgentLoop lifecycle when its storage write is unavailable.
                return

        def observe_compaction_retry(_delay: float) -> None:
            state.total_retry_count += 1
            state.summary_retry_count += 1
            persist_retry_progress()

        def admit_compaction_request(messages: list[Message]):
            state.model_attempts += 1
            if observation_runtime is None or state.agent_run_id is None:
                return None
            estimated_chars = context_builder.estimate_request_chars(tuple(messages), ())
            return observation_runtime.admit_model_request(
                agent_run_id=state.agent_run_id,
                attempt_ordinal=state.model_attempts,
                estimated_request_chars=estimated_chars,
                request_char_budget=context_builder.request_char_limit,
                tool_rounds=state.tool_rounds,
                tool_calls=state.tool_calls,
                purpose="compaction",
                policy_schema_version=policy.policy_schema_version,
                estimated_context_tokens=context_builder.estimate_request_tokens(
                    tuple(messages), ()
                ),
                context_window_tokens=policy.context_window_tokens,
                reserve_tokens=policy.reserve_tokens,
                keep_recent_tokens=policy.keep_recent_tokens,
                accounting_basis=TokenAccountingBasis.PI_ESTIMATOR,
                compaction_required=True,
            )

        def finalize_observation() -> None:
            if (
                observation_runtime is None
                or state.agent_run_id is None
                or state.observation_finalized
                or state.crashed
            ):
                return
            finish_reason = state.terminal_finish_reason or FinishReason.ERROR
            run_metrics = state.run_context.metrics(finish_reason.value)
            try:
                observation_runtime.finalize_agent_run(
                    agent_run_id=state.agent_run_id,
                    finish_reason=finish_reason,
                    stop_code=state.stop_code,
                    stop_detail=state.stop_detail,
                    model_attempts=state.model_attempts,
                    retry_count=state.total_retry_count,
                    tool_rounds=state.tool_rounds,
                    tool_calls=state.tool_calls,
                    max_estimated_request_chars=state.max_estimated_request_chars,
                    request_char_budget=state.request_char_budget,
                    cleared_cycle_count=state.cleared_cycle_count,
                    dropped_turn_count=state.dropped_turn_count,
                    dropped_cycle_count=state.dropped_cycle_count,
                    dropped_record_count=state.dropped_record_count,
                    policy_schema_version=policy.policy_schema_version,
                    max_context_tokens=state.max_context_tokens,
                    last_context_tokens=state.last_context_tokens,
                    context_window_tokens=policy.context_window_tokens,
                    reserve_tokens=policy.reserve_tokens,
                    keep_recent_tokens=policy.keep_recent_tokens,
                    accounting_basis=state.accounting_basis,
                    compaction_count=state.compaction_count,
                    overflow_recovery_count=state.overflow_recovery_count,
                    validation_outcome=run_metrics.validation_outcome,
                    execution_finished=run_metrics.execution_finished,
                    goal_verification=run_metrics.goal_verification,
                )
            except Exception:
                # Observation persistence must never leak raw storage details into
                # the existing public event lifecycle.
                return
            state.observation_finalized = True

        def retain_facts(finish_reason: str = "unknown") -> None:
            if not state.facts_retained:
                session.retain_run_facts(state.run_context, finish_reason=finish_reason)
                state.facts_retained = True

        events = _RunEventEmitter(
            new_id=self._id,
            session=session,
            clock=self.clock,
            turn_id=lambda: state.turn_id,
            visible=lambda: state.visible,
            retain_facts=retain_facts,
        )
        event = events.event
        fatal = events.fatal
        tool_status = events.tool_status
        emit_terminal_error = events.terminal_error

        def terminal_error(
            message: str,
            stop_code: AgentStopCode,
            *,
            interrupted: tuple[str, ...] = (),
            cause_phase: str | None = None,
            cause_code: str | None = None,
        ) -> tuple[AgentEvent, ...]:
            state.terminal_finish_reason = FinishReason.ERROR
            state.stop_code = stop_code
            diagnostic = (
                (
                    event(
                        "status.changed",
                        {
                            "status": "terminal_cause",
                            "cause_phase": cause_phase,
                            "cause_code": cause_code,
                        },
                    ),
                )
                if cause_phase is not None and cause_code is not None
                else ()
            )
            return (*diagnostic, *emit_terminal_error(message, stop_code, interrupted=interrupted))

        def compaction_failure_event(exc: ContextBudgetError) -> AgentEvent:
            return event(
                "status.changed",
                {
                    "status": "compaction_failure",
                    "cause_phase": exc.cause_phase,
                    "cause_code": exc.cause_code,
                    "http_status_class": exc.http_status_class,
                    "request_output_tokens": min(
                        COMPACTION_MAX_OUTPUT_TOKENS, policy.reserve_tokens
                    ),
                },
            )

        def synthetic_statuses(
            unresolved: tuple[str, ...], *, code: ToolErrorCode, running_status: str
        ) -> list[AgentEvent]:
            return events.synthetic_statuses(
                unresolved,
                active_calls=state.active_calls,
                active_running_id=state.active_running_id,
                code=code,
                running_status=running_status,
            )

        async def finish_interrupted(
            signal, *, partial_text: str = "", stop_code=AgentStopCode.USER_PAUSE
        ):
            """Typed user-pause terminal: close this turn, never the task.

            The interrupted terminal ends the Turn and the AgentRun metrics
            only; TaskRun, NodeRun, and WorkflowRun stay open so the user's
            next message continues the same business identity (D02/D05). No
            ``CancelledError`` is raised and no cancel cascade runs. The
            streamed-but-uncommitted text rides along as a bounded display
            fragment; it is never committed as a full reply.
            """
            reason = "user_pause" if stop_code is AgentStopCode.USER_PAUSE else "provider_failure"
            state.internal_phase = "interrupt"
            state.settled = True
            fragment = (partial_text or state.visible)[:8192]
            unresolved = session.log.unresolved_call_ids
            interrupted = self._close_unresolved(
                session,
                state.active_calls,
                state.durable_executions,
                ToolErrorCode.CANCELLED,
                "用户已暂停，未开始的工具调用不再执行",
                tool_executor=tool_executor,
                result_limit=state.active_result_limit,
            )
            for status_event in synthetic_statuses(
                unresolved,
                code=ToolErrorCode.CANCELLED,
                running_status="cancelled",
            ):
                yield status_event
            if session.log.has_active_turn:
                try:
                    session.finish_turn(
                        FinishReason.INTERRUPTED,
                        interrupted_call_ids=interrupted,
                        stop_code=stop_code,
                    )
                except ConversationLogError:
                    pass
            state.terminal_finish_reason = FinishReason.INTERRUPTED
            state.stop_code = stop_code
            state.paused_generation = signal.control_generation if signal is not None else None
            retain_facts(FinishReason.INTERRUPTED.value)
            if self.pause_control is not None:
                try:
                    self.pause_control.clear(session.session_id)
                except Exception:
                    pass
            payload = completion_payload(FinishReason.INTERRUPTED, fragment, stop_code=stop_code)
            payload["reason"] = reason
            if signal is not None:
                payload["control_generation"] = signal.control_generation
            if interrupted:
                payload["interrupted_call_ids"] = list(interrupted)
            yield event("status.changed", {"status": "paused", "reason": reason})
            yield event("turn.completed", payload)

        try:
            if startup_error is not None:
                if resume_current_turn:
                    current_turn_id = (
                        durable_runtime.current_turn_id if durable_runtime is not None else None
                    )
                    if current_turn_id:
                        state.turn_id = current_turn_id
                        install_agent_run(getattr(durable_runtime, "current_agent_run_id", None))
                        restore_observation_progress()
                        if state.agent_run_id is None:
                            state.run_context = ToolRunContext(
                                run_id=state.turn_id,
                                session_id=session.session_id,
                            )
                if isinstance(startup_error, ApplicationError):
                    raise startup_error
                state.started = True
                yield event("turn.started", {})
                if session.log.has_active_turn:
                    try:
                        session.finish_turn(
                            FinishReason.ERROR,
                            stop_code=AgentStopCode.INTERNAL,
                        )
                    except ConversationLogError:
                        pass
                state.settled = True
                state.terminal_finish_reason = FinishReason.ERROR
                state.stop_code = AgentStopCode.INTERNAL
                retain_facts(FinishReason.ERROR.value)
                for item in fatal(startup_error, AgentStopCode.INTERNAL):
                    yield item
                return
            if resume_current_turn:
                if not session.log.has_active_turn:
                    raise ConversationLogError("no active turn is available to resume")
                current_turn_id = (
                    durable_runtime.current_turn_id if durable_runtime is not None else None
                )
                if current_turn_id:
                    state.turn_id = current_turn_id
                    install_agent_run(getattr(durable_runtime, "current_agent_run_id", None))
                    restore_observation_progress()
                    if state.agent_run_id is None:
                        state.run_context = ToolRunContext(
                            run_id=state.turn_id,
                            session_id=session.session_id,
                        )
            else:
                state.internal_phase = "run_setup"
                if durable_runtime is not None:
                    requested_agent_run_id = (
                        agent_run_id
                        or (
                            getattr(prepared, "agent_run_id", None)
                            if prepared is not None
                            else None
                        )
                        or self._id("arun")
                    )
                    submit_outcome = durable_runtime.submit_user(
                        session,
                        user_input,
                        client_message_id,
                        turn_id=state.turn_id,
                        agent_run_id=requested_agent_run_id,
                        tools=tool_executor.definitions if tool_executor else (),
                        prepared_spec=prepared_spec,
                        prompt_projection=prompt_projection,
                        prepared_mcp_run=(
                            getattr(prepared, "mcp_run", None) if prepared is not None else None
                        ),
                    )
                    if submit_outcome.turn_id:
                        state.turn_id = submit_outcome.turn_id
                        if submit_outcome.kind == "accepted":
                            install_agent_run(
                                getattr(durable_runtime, "current_agent_run_id", None)
                                or requested_agent_run_id
                            )
                        else:
                            state.agent_run_id = None
                            state.run_context = ToolRunContext(
                                run_id=state.turn_id,
                                session_id=session.session_id,
                            )
                    if submit_outcome.kind != "accepted":
                        yield event("turn.started", {})
                        state.started = True
                        state.settled = True
                        if submit_outcome.kind == "closed_replay":
                            finish_reason = submit_outcome.finish_reason or FinishReason.ERROR
                            text = submit_outcome.assistant_text or ""
                            if finish_reason is FinishReason.STOP and text:
                                yield event("text.delta", {"text": text})
                            stop_code = submit_outcome.stop_code
                            if finish_reason is FinishReason.ERROR:
                                stop_code = stop_code or AgentStopCode.INTERNAL
                                state.stop_code = stop_code
                                yield event(
                                    "error",
                                    {"message": "先前回合已失败", "stop_code": stop_code.value},
                                )
                            elif finish_reason is FinishReason.STEERED:
                                yield event("status.changed", {"status": "steered"})
                            state.terminal_finish_reason = finish_reason
                            retain_facts(finish_reason.value)
                            yield event(
                                "turn.completed",
                                completion_payload(finish_reason, text, stop_code=stop_code),
                            )
                            return
                        message = (
                            "当前回合需要恢复后才能继续"
                            if submit_outcome.kind == "recovery"
                            else "client_message_id 与已有请求冲突"
                        )
                        state.terminal_finish_reason = FinishReason.ERROR
                        state.stop_code = AgentStopCode.INTERNAL
                        yield event(
                            "error",
                            {"message": message, "stop_code": AgentStopCode.INTERNAL.value},
                        )
                        retain_facts(FinishReason.ERROR.value)
                        yield event(
                            "turn.completed",
                            completion_payload(
                                FinishReason.ERROR, "", stop_code=AgentStopCode.INTERNAL
                            ),
                        )
                        return
                else:
                    session.begin_user_turn(UserMessage(content=user_input))

            state.started = True
            tools = tool_executor.definitions if tool_executor else ()
            yield event("turn.started", {})
            permission_snapshot = None
            await self._request_pending_grant(session)

            def freeze_permissions() -> None:
                nonlocal permission_snapshot
                if durable_runtime is None or permission_snapshot is not None:
                    return
                permission_snapshot = durable_runtime.freeze_permission_snapshot(
                    session,
                    tools=tools,
                    mcp_review_evidence=(
                        getattr(getattr(prepared, "mcp_run", None), "review_evidence", ())
                        if prepared is not None
                        else ()
                    ),
                )

            while True:
                state.internal_phase = "run_control"
                if deadline is not None:
                    deadline.require_work()
                if _pending_cancellation():
                    _consume_cancellation_request()
                    raise asyncio.CancelledError
                pause_signal = self._pause_signal(session)
                if pause_signal is not None:
                    # Durable pause accepted: no new model/tool admission may
                    # commit; end this turn interrupted before the request.
                    async for interrupted_event in finish_interrupted(pause_signal):
                        yield interrupted_event
                    return
                steering_entry = None
                if await self._steering_pending(session):
                    if self.steering_mode == "inject":
                        # Leaf drive: consume atomically (at-most-once) and
                        # inject into THIS request; the turn stays open.
                        steering_entry = await self._take_steering(session)
                        if steering_entry is not None:
                            yield event(
                                "status.changed",
                                {
                                    "status": "steered",
                                    "receipt": "applied",
                                    "client_message_id": steering_entry["client_message_id"],
                                },
                            )
                    else:
                        session.finish_turn(FinishReason.STEERED)
                        state.settled = True
                        state.terminal_finish_reason = FinishReason.STEERED
                        state.stop_code = None
                        retain_facts(FinishReason.STEERED.value)
                        yield event("status.changed", {"status": "steered"})
                        yield event(
                            "turn.completed",
                            completion_payload(FinishReason.STEERED, state.visible),
                        )
                        return
                try:
                    state.internal_phase = "context_build"

                    def build_model_context():
                        return context_builder.build(
                            session, tools=tools, omission_floor=state.omission_floor
                        )

                    context = build_model_context()
                    while context.compaction_required:
                        if deadline is not None:
                            deadline.require_work()
                        if not policy.compaction_enabled:
                            raise ContextBudgetError("模型上下文需要压缩，但自动压缩已禁用")
                        previous_boundary = session.compaction_boundary_sequence
                        yield event("status.changed", {"status": "compacting"})
                        compact_error = "当前上下文没有可安全压缩的完整边界"
                        compacted = False
                        try:
                            async with asyncio.timeout(
                                deadline.require_work() if deadline is not None else None
                            ):
                                compacted = await self._compact_context(
                                    session,
                                    provider,
                                    model,
                                    context_builder,
                                    tools=tools,
                                    retry_observer=observe_compaction_retry,
                                    request_admitter=admit_compaction_request,
                                    request_settler=settle_model_request,
                                    retry_wait=state.retry_wait,
                                )
                            if (
                                compacted
                                and session.compaction_boundary_sequence <= previous_boundary
                            ):
                                compacted = False
                                compact_error = "上下文压缩未推进有效边界"
                        except ContextBudgetError as exc:
                            compacted = False
                            compact_error = str(exc)
                            yield compaction_failure_event(exc)
                        except TimeoutError as exc:
                            if deadline is not None and deadline.remaining_seconds() <= 0:
                                raise RunDeadlineExceeded(
                                    "任务运行时间已用尽，正在保存已有结果"
                                ) from exc
                            compacted = False
                            compact_error = "上下文压缩请求超时"
                        if compacted:
                            state.compaction_count += 1
                            context = build_model_context()
                            yield event("status.changed", {"status": "compacted"})
                            continue
                        degraded = context_builder.degrade_model_input(
                            session, tools=tools, omission_floor=state.omission_floor
                        )
                        if degraded is None:
                            raise ContextBudgetError(compact_error)
                        state.omission_floor = degraded.omission_floor
                        context = degraded
                        if (
                            degraded.dropped_turn_count
                            or degraded.dropped_cycle_count
                            or degraded.dropped_record_count
                        ):
                            yield event(
                                "status.changed",
                                {
                                    "status": "context_degraded",
                                    "dropped_turn_count": degraded.dropped_turn_count,
                                    "dropped_cycle_count": degraded.dropped_cycle_count,
                                    "dropped_record_count": degraded.dropped_record_count,
                                },
                            )
                        break
                    call_messages = list(context.messages)
                    injected_steering = (
                        steering_entry["text"]
                        if steering_entry is not None
                        else state.pending_steering_text
                    )
                    if injected_steering:
                        # The correction rides the next model request (P6.3);
                        # the durable receipt is the consumed control row.
                        call_messages.append(UserMessage(content=injected_steering))
                        state.pending_steering_text = None
                    if pending_completion_review is not None:
                        call_messages.append(UserMessage(content=pending_completion_review))
                    if deadline is not None:
                        remaining = deadline.require_work()
                        if remaining <= 120:
                            call_messages.append(
                                UserMessage(
                                    content=(
                                        f"本次运行还可用于工作的时间约 {remaining:.0f} 秒。"
                                        "请优先验证和保存已有成果，并尽快给出可用结论。"
                                    )
                                )
                            )
                    estimated_chars = context_builder.validate_request(call_messages, tools)
                except ContextBudgetError as exc:
                    if self.pause_control is not None:
                        async for item in finish_interrupted(
                            None, stop_code=AgentStopCode.CONTEXT_BUDGET
                        ):
                            yield item
                    else:
                        for item in terminal_error(str(exc), AgentStopCode.CONTEXT_BUDGET):
                            yield item
                    return

                state.max_estimated_request_chars = max(
                    state.max_estimated_request_chars, estimated_chars
                )
                state.request_char_budget = context_builder.request_char_limit
                state.cleared_cycle_count += context.cleared_cycle_count
                state.dropped_turn_count += context.dropped_turn_count
                state.dropped_cycle_count += context.dropped_cycle_count
                state.dropped_record_count += context.dropped_record_count
                state.context_observation_count += 1
                state.max_context_tokens = max(
                    state.max_context_tokens, context.estimated_context_tokens
                )
                state.last_context_tokens = context.estimated_context_tokens
                if state.context_observation_count == 1:
                    state.accounting_basis = context.accounting_basis
                elif state.accounting_basis != context.accounting_basis:
                    state.accounting_basis = None
                # Request budgets are enforced durably at request admission
                # (AgentRun and workflow lineage caps refuse over-cap requests
                # with budget_exhausted); the loop never duplicates that gate.
                state.internal_phase = "model_call"
                if state.retry_count == 0:
                    # A completed tool cycle or failed compaction ends the prior
                    # failure window; the run-wide wait budget remains consumed.
                    state.retry_wait.reset_window()
                if deadline is not None:
                    deadline.require_work()
                # A task deadline already reserves time for persistence and Harbor
                # log export. Let active reasoning use the remaining work window.
                attempt_seconds = _model_attempt_seconds(deadline)
                attempt_until = asyncio.get_running_loop().time() + attempt_seconds
                state.model_attempts += 1
                admission = None
                if observation_runtime is not None and state.agent_run_id is not None:
                    request_projection = (
                        session.run_context_projection.prompt_projection
                        if session.run_context_projection is not None
                        else getattr(session, "pending_prompt_projection", None)
                    )
                    admission = observation_runtime.admit_model_request(
                        agent_run_id=state.agent_run_id,
                        attempt_ordinal=state.model_attempts,
                        estimated_request_chars=estimated_chars,
                        request_char_budget=context_builder.request_char_limit,
                        cleared_cycle_count=context.cleared_cycle_count,
                        dropped_turn_count=context.dropped_turn_count,
                        dropped_cycle_count=context.dropped_cycle_count,
                        dropped_record_count=context.dropped_record_count,
                        tool_rounds=state.tool_rounds,
                        tool_calls=state.tool_calls,
                        policy_schema_version=policy.policy_schema_version,
                        estimated_context_tokens=context.estimated_context_tokens,
                        context_window_tokens=policy.context_window_tokens,
                        reserve_tokens=policy.reserve_tokens,
                        keep_recent_tokens=policy.keep_recent_tokens,
                        accounting_basis=context.accounting_basis,
                        compaction_required=context.compaction_required,
                        purpose="agent",
                        prompt_evidence=(
                            request_projection.evidence if request_projection is not None else None
                        ),
                    )
                candidate_chunks: list[str] = []
                candidate_bytes = 0
                response_overflow = False
                text_projection = TextStreamProjection()
                # The request may stream nothing for a long time (reasoning-only
                # responses, slow providers). "awaiting_model" is the factual
                # no-content stage; "model_responding" fires only on real output.
                yield event(
                    "status.changed",
                    {"status": "awaiting_model", "attempt_ordinal": state.model_attempts},
                )
                responding_reported = False
                thinking_reported = False
                reasoning_redactor = ReasoningRedactor()
                stream = runner.attempt(call_messages, tools)
                model_started_at = self.monotonic_clock()
                activity_counts: dict[str, int] = {}
                last_activity_kind: str | None = None
                attempt_timed_out = False
                pause_signal = None
                pause_waiter = None
                try:
                    while True:
                        if deadline is not None:
                            try:
                                deadline.require_work()
                            except RunDeadlineExceeded:
                                attempt_timed_out = True
                                break
                        if asyncio.get_running_loop().time() >= attempt_until:
                            attempt_timed_out = True
                            break
                        try:
                            async with asyncio.timeout_at(attempt_until):
                                (step_kind, step_value), pause_waiter = await self._next_model_step(
                                    session, stream, pause_waiter
                                )
                        except TimeoutError:
                            attempt_timed_out = True
                            break
                        if step_kind == "stop":
                            break
                        if step_kind == "pause":
                            pause_signal = step_value
                            break
                        if step_kind == "continue":
                            continue
                        model_event = step_value
                        activity_kind = (
                            "reasoning"
                            if model_event.kind == "reasoning_delta"
                            or (
                                model_event.kind == "activity"
                                and model_event.activity == "reasoning"
                            )
                            else "tool_call"
                            if model_event.kind == "activity"
                            and model_event.activity == "tool_call"
                            else "text"
                            if model_event.kind == "text_delta"
                            else None
                        )
                        if activity_kind is not None:
                            last_activity_kind = activity_kind
                            count = activity_counts.get(activity_kind, 0) + 1
                            activity_counts[activity_kind] = count
                            if deadline is not None and (count == 1 or count % 128 == 0):
                                yield event(
                                    "status.changed",
                                    {
                                        "status": "model_activity",
                                        "activity": activity_kind,
                                        "chunk_count": count,
                                        "elapsed_seconds": round(
                                            self.monotonic_clock() - model_started_at, 2
                                        ),
                                        "attempt_ordinal": state.model_attempts,
                                    },
                                )
                        if model_event.kind == "reasoning_delta" and model_event.reasoning_text:
                            # Vendor-visible thinking (P3.2): a distinct
                            # content-free stage plus bounded projected
                            # fragments to the observer; never the reply text.
                            if not thinking_reported:
                                thinking_reported = True
                                yield event(
                                    "status.changed",
                                    {
                                        "status": "thinking",
                                        "attempt_ordinal": state.model_attempts,
                                    },
                                )
                            visible = reasoning_redactor.feed(model_event.reasoning_text)
                            self._notify_reasoning(
                                turn_id=state.turn_id,
                                attempt_ordinal=state.model_attempts,
                                fragment=visible,
                            )
                            continue
                        if model_event.kind == "activity":
                            # Content-free arrival marker; never carries fragments.
                            if model_event.activity == "reasoning":
                                # Reasoning activity means thinking, not reply
                                # text: keep the two stages distinct (P3.4).
                                if not thinking_reported:
                                    thinking_reported = True
                                    yield event(
                                        "status.changed",
                                        {
                                            "status": "thinking",
                                            "attempt_ordinal": state.model_attempts,
                                        },
                                    )
                                continue
                            if not responding_reported:
                                responding_reported = True
                                yield event(
                                    "status.changed",
                                    {
                                        "status": "model_responding",
                                        "attempt_ordinal": state.model_attempts,
                                    },
                                )
                            if model_event.activity == "tool_call":
                                yield event(
                                    "status.changed",
                                    {
                                        "status": "tool_preparing",
                                        "attempt_ordinal": state.model_attempts,
                                    },
                                )
                            continue
                        if model_event.kind == "text_delta" and model_event.text:
                            if not responding_reported:
                                responding_reported = True
                                yield event(
                                    "status.changed",
                                    {
                                        "status": "model_responding",
                                        "attempt_ordinal": state.model_attempts,
                                    },
                                )
                            candidate_bytes += len(model_event.text.encode("utf-8"))
                            if candidate_bytes > 256 * 1024:
                                response_overflow = True
                                break
                            candidate_chunks.append(model_event.text)
                            visible_chunk = text_projection.feed(model_event.text)
                            if visible_chunk:
                                yield event(
                                    "text.delta",
                                    {
                                        "text": visible_chunk,
                                        "attempt_ordinal": state.model_attempts,
                                    },
                                )
                finally:
                    if pause_waiter is not None and not pause_waiter.done():
                        pause_waiter.cancel()
                        await asyncio.gather(pause_waiter, return_exceptions=True)
                    try:
                        close = getattr(stream, "aclose", None)
                        if close is not None:
                            await close()
                    finally:
                        if admission is not None:
                            if _pending_cancellation() or pause_signal is not None:
                                settle_model_request(
                                    admission,
                                    state_name="cancelled",
                                )
                            elif attempt_timed_out:
                                settle_model_request(
                                    admission,
                                    state_name="failed",
                                    error_code=ModelErrorCode.TIMEOUT,
                                )
                            elif response_overflow:
                                # The stream was closed before a provider completion. A
                                # completed request without a finish reason is invalid and
                                # leaves the whole run without terminal metrics.
                                settle_model_request(
                                    admission,
                                    state_name="failed",
                                    error_code=ModelErrorCode.INVALID_RESPONSE,
                                )
                            else:
                                attempt_outcome = runner.outcome
                                if attempt_outcome.failure is not None:
                                    settled_state = "failed"
                                else:
                                    settled_state = "completed"
                                settle_model_request(
                                    admission,
                                    state_name=settled_state,
                                    finish_reason=attempt_outcome.finish_reason,
                                    error_code=(
                                        attempt_outcome.failure.code
                                        if attempt_outcome.failure is not None
                                        else None
                                    ),
                                    usage=attempt_outcome.usage,
                                    cost=attempt_outcome.cost,
                                )
                # Attempt end: release or drop the redactor's held tail —
                if attempt_timed_out:
                    yield event(
                        "status.changed",
                        {
                            "status": "model_attempt_timeout",
                            "cause_phase": "task_deadline"
                            if deadline is not None and deadline.remaining_seconds() <= 0
                            else "local_attempt_limit",
                            "cause_code": "active_stream"
                            if activity_counts
                            else "no_stream_activity",
                            "last_activity": last_activity_kind,
                            "internal_remaining_seconds": round(deadline.remaining_seconds(), 2)
                            if deadline is not None
                            else None,
                        },
                    )
                    if deadline is not None and deadline.remaining_seconds() <= 0:
                        raise RunDeadlineExceeded("任务运行时间已用尽，正在保存已有结果")
                    raise ModelAttemptExceeded("单次模型请求超过总用时上限")
                # ambiguous content stays hidden even at the stream boundary.
                tail = reasoning_redactor.finish()
                if tail:
                    self._notify_reasoning(
                        turn_id=state.turn_id,
                        attempt_ordinal=state.model_attempts,
                        fragment=tail,
                    )
                if response_overflow:
                    for item in terminal_error(
                        "回复超过单条消息存储上限", AgentStopCode.MODEL_OUTPUT_LIMIT
                    ):
                        yield item
                    return
                if pause_signal is not None:
                    # The pause woke before the provider response completed; the
                    # uncommitted response is dropped and shown as a partial
                    # fragment only. The turn ends interrupted, the task stays.
                    async for interrupted_event in finish_interrupted(
                        pause_signal, partial_text="".join(candidate_chunks)
                    ):
                        yield interrupted_event
                    return
                if _pending_cancellation():
                    _consume_cancellation_request()
                    raise asyncio.CancelledError
                outcome = runner.outcome
                if outcome.failure is None and outcome.message is not None:
                    # A review belongs to the logical request, not one network
                    # attempt. Keep it through transient and malformed responses.
                    pending_completion_review = None
                    session.latest_model_usage = outcome.usage
                    context_digest = getattr(context_builder, "context_digest", None)
                    usage_messages = (*call_messages, outcome.message)
                    session.latest_model_usage_context_digest = (
                        context_digest(usage_messages, tuple(tools))
                        if callable(context_digest)
                        else None
                    )
                    session.latest_model_usage_message_count = len(usage_messages)
                    session.latest_model_usage_model = model
                if outcome.failure is not None:
                    failure = outcome.failure
                    if failure.code is ModelErrorCode.CONTEXT_OVERFLOW:
                        if policy.compaction_enabled and state.overflow_recovery_count == 0:
                            state.overflow_recovery_count += 1
                            yield event("status.changed", {"status": "compacting"})
                            try:
                                async with asyncio.timeout(
                                    deadline.require_work() if deadline is not None else None
                                ):
                                    compacted = await self._compact_context(
                                        session,
                                        provider,
                                        model,
                                        context_builder,
                                        tools=tools,
                                        retry_observer=observe_compaction_retry,
                                        request_admitter=admit_compaction_request,
                                        request_settler=settle_model_request,
                                        retry_wait=state.retry_wait,
                                    )
                            except ContextBudgetError as exc:
                                compacted = False
                                yield compaction_failure_event(exc)
                            except TimeoutError as exc:
                                if deadline is not None and deadline.remaining_seconds() <= 0:
                                    raise RunDeadlineExceeded(
                                        "任务运行时间已用尽，正在保存已有结果"
                                    ) from exc
                                compacted = False
                            if not compacted:
                                degraded = context_builder.degrade_model_input(
                                    session, tools=tools, omission_floor=state.omission_floor
                                )
                                if degraded is None:
                                    if self.pause_control is not None:
                                        async for item in finish_interrupted(
                                            None, stop_code=AgentStopCode.CONTEXT_BUDGET
                                        ):
                                            yield item
                                    else:
                                        for item in terminal_error(
                                            "上下文压缩失败，请稍后重试",
                                            AgentStopCode.CONTEXT_BUDGET,
                                        ):
                                            yield item
                                    return
                                state.omission_floor = degraded.omission_floor
                                state.dropped_turn_count += degraded.dropped_turn_count
                                state.dropped_cycle_count += degraded.dropped_cycle_count
                                state.dropped_record_count += degraded.dropped_record_count
                                continue
                            state.compaction_count += 1
                            yield event("status.changed", {"status": "compacted"})
                            continue
                    delay = None
                    if policy.retry_enabled and _can_retry_provider_failure(failure):
                        state.retry_wait.begin(self._wall_now(session))
                        delay = next_provider_retry_delay(
                            policy=policy,
                            retry_index=state.retry_count + 1,
                            retry_after_seconds=failure.retry_after_seconds,
                            waited_seconds=state.retry_wait.seconds,
                            total_waited_seconds=state.retry_wait.total_seconds,
                            elapsed_seconds=state.retry_wait.elapsed(self._wall_now(session)),
                            unit=self._retry_sample(),
                        )
                    if delay is not None:
                        state.retry_count += 1
                        state.total_retry_count += 1
                        state.retry_wait.add(delay)
                        persist_retry_progress()
                        if text_projection.emitted:
                            # A failed attempt may have shown provisional lines.
                            # Discard that draft before streaming the next attempt.
                            yield event(
                                "status.changed",
                                {
                                    "status": "response_reset",
                                    "attempt_ordinal": state.model_attempts,
                                },
                            )
                        payload = {"status": "retrying", "retry_delay_seconds": delay}
                        yield event("status.changed", payload)
                        if deadline is not None:
                            if payload["retry_delay_seconds"] >= deadline.require_work():
                                raise RunDeadlineExceeded("任务运行时间已用尽，正在保存已有结果")
                            try:
                                async with asyncio.timeout(deadline.require_work()):
                                    await self.retry_sleep(payload["retry_delay_seconds"])
                            except TimeoutError as exc:
                                raise RunDeadlineExceeded(
                                    "任务运行时间已用尽，正在保存已有结果"
                                ) from exc
                        else:
                            await self.retry_sleep(payload["retry_delay_seconds"])
                        continue
                    if outcome.finish_reason == ModelFinishReason.LENGTH:
                        stop_code = AgentStopCode.MODEL_OUTPUT_LIMIT
                    elif outcome.finish_reason == ModelFinishReason.CONTENT_FILTER:
                        stop_code = AgentStopCode.CONTENT_FILTERED
                    else:
                        stop_code = MODEL_ERROR_STOPS[failure.code]
                    if failure.code is ModelErrorCode.INTERNAL:
                        state.stop_detail = f"{failure.origin.value}_internal"
                        yield event(
                            "status.changed",
                            {
                                "status": "internal_error",
                                "error_class": "ModelFailure",
                                "phase": state.stop_detail,
                                "reason_fingerprint": hashlib.sha256(
                                    f"ModelFailure:{state.stop_detail}".encode()
                                ).hexdigest()[:24],
                            },
                        )
                    persist_retry_progress()
                    # An interrupted terminal is meaningful only when the host
                    # supplied a pause authority (durable chat/workflow). The
                    # standalone in-memory AgentLoop keeps its historical
                    # fatal terminal because it has no task checkpoint to
                    # resume from.
                    if stop_code in INTERRUPT_STOP_CODES and self.pause_control is not None:
                        async for item in finish_interrupted(
                            None, partial_text="".join(candidate_chunks), stop_code=stop_code
                        ):
                            yield item
                    else:
                        for item in terminal_error(failure.message, stop_code):
                            yield item
                    return
                state.retry_count = 0
                state.retry_wait.reset_window()
                persist_retry_progress()
                message = outcome.message
                if message is not None and message.content:
                    message = message.model_copy(update={"content": project_text(message.content)})
                is_final_text = (
                    outcome.finish_reason == ModelFinishReason.STOP
                    and message is not None
                    and not message.tool_calls
                )
                if is_final_text:
                    candidate_text = message.content or ""
                    if await self._steering_pending(session) and self.steering_mode != "inject":
                        session.finish_turn(FinishReason.STEERED)
                        state.settled = True
                        state.terminal_finish_reason = FinishReason.STEERED
                        state.stop_code = None
                        retain_facts(FinishReason.STEERED.value)
                        yield event("status.changed", {"status": "steered"})
                        yield event(
                            "turn.completed",
                            completion_payload(FinishReason.STEERED, state.visible),
                        )
                        return
                    completion_check = check_completion(state.run_context)
                    needs_review = (
                        state.tool_calls > 0
                        and getattr(durable_runtime, "workflow_leaf", None) is None
                        and (
                            (
                                completion_review_count == 0
                                and (completion_check.issues or has_acceptance_cues(user_input))
                            )
                            or (
                                completion_check.issues
                                and state.tool_calls > completion_review_tool_calls
                            )
                        )
                    )
                    if (
                        needs_review
                        and completion_review_count < MAX_COMPLETION_REVIEWS
                        and (
                            prepared_spec is None
                            or prepared_spec.max_agent_generation_requests is None
                            or state.model_attempts < prepared_spec.max_agent_generation_requests
                        )
                        and (deadline is None or deadline.remaining_seconds() > 15)
                    ):
                        completion_review_count += 1
                        completion_review_tool_calls = state.tool_calls
                        pending_completion_review = completion_review_prompt(
                            user_input,
                            completion_check,
                            candidate_text=candidate_text,
                            final=completion_review_count == MAX_COMPLETION_REVIEWS,
                        )
                        if text_projection.emitted:
                            yield event(
                                "status.changed",
                                {
                                    "status": "response_reset",
                                    "attempt_ordinal": state.model_attempts,
                                },
                            )
                        yield event(
                            "status.changed",
                            {
                                "status": "completion_review",
                                "review_ordinal": completion_review_count,
                                "validation_outcome": completion_check.validation_outcome,
                            },
                        )
                        continue
                    try:
                        state.internal_phase = "conversation_commit"
                        freeze_permissions()
                        session.append_assistant(message)
                    except ConversationLogError:
                        for item in terminal_error(
                            "模型响应未正常结束",
                            AgentStopCode.INVALID_RESPONSE,
                            cause_phase="answer_commit",
                            cause_code="conversation_commit_rejected",
                        ):
                            yield item
                        return
                    state.visible = candidate_text
                    state.final_committed = True
                    current = asyncio.current_task()
                    if current is not None:
                        while current.cancelling():
                            current.uncancel()
                    session.finish_turn(FinishReason.STOP)
                    state.terminal_finish_reason = FinishReason.STOP
                    state.stop_code = None
                    retain_facts(FinishReason.STOP.value)
                    chunks, reset = _remaining_text_chunks(
                        text_projection, candidate_chunks, message
                    )
                    if reset:
                        yield event(
                            "status.changed",
                            {"status": "response_reset", "attempt_ordinal": state.model_attempts},
                        )
                    for chunk in chunks:
                        yield event("text.delta", {"text": chunk})
                    yield event(
                        "turn.completed",
                        completion_payload(FinishReason.STOP, state.visible),
                    )
                    return
                if tool_executor is None or message is None:
                    for item in terminal_error(
                        "模型响应未正常结束",
                        AgentStopCode.INVALID_RESPONSE,
                        cause_phase="response_interpretation",
                        cause_code="missing_tool_response",
                    ):
                        yield item
                    return

                calls = message.tool_calls
                if len(calls) > 1 and not policy.provider_tool_support.multiple_tool_calls:
                    for item in terminal_error(
                        "当前 Provider 不支持并行工具调用", AgentStopCode.INVALID_RESPONSE
                    ):
                        yield item
                    return
                per_call_result_limit = self._cycle_result_limit(policy)
                if per_call_result_limit is None:
                    for item in terminal_error(
                        "模型工具调用输出超过 Cycle 预算",
                        AgentStopCode.MODEL_OUTPUT_LIMIT,
                    ):
                        yield item
                    return

                try:
                    state.internal_phase = "conversation_commit"
                    commit_cause_code = "conversation_plan_rejected"
                    freeze_permissions()
                    planned = session.log.plan_append_assistant(message)
                    if durable_runtime is not None:
                        commit_cause_code = "conversation_commit_rejected"
                        state.durable_executions = durable_runtime.prepare_and_commit_assistant(
                            planned,
                            message,
                            run_context=state.run_context,
                            tool_executor=tool_executor,
                        )
                        missing = [
                            item.tool_execution_id
                            for item in state.durable_executions
                            if not durable_runtime.execution_is_visible(item.tool_execution_id)
                        ]
                        if missing:
                            commit_cause_code = "committed_intent_invisible"
                            raise ConversationLogError("committed tool intent is not observable")
                    else:
                        commit_cause_code = "conversation_commit_rejected"
                        session.commit_append(planned)
                except (ConversationLogError, PreparedIntentError) as exc:
                    for item in terminal_error(
                        "模型响应未正常结束",
                        AgentStopCode.INVALID_RESPONSE,
                        cause_phase="tool_intent_prepare",
                        cause_code=(
                            "prepared_intent_rejected"
                            if isinstance(exc, PreparedIntentError)
                            else commit_cause_code
                        ),
                    ):
                        yield item
                    return
                # A response that finished with tool calls is not a final answer. Its
                # remaining text is rendered after the assistant/tool intent is committed.
                chunks, reset = _remaining_text_chunks(text_projection, candidate_chunks, message)
                if reset:
                    yield event(
                        "status.changed",
                        {"status": "response_reset", "attempt_ordinal": state.model_attempts},
                    )
                for chunk in chunks:
                    yield event("text.delta", {"text": chunk})
                state.active_calls = calls
                state.active_running_id = None
                state.active_result_limit = per_call_result_limit
                state.tool_calls += len(calls)
                state.tool_rounds += 1
                state.internal_phase = "tool_cycle"
                for index, call in enumerate(calls, start=1):
                    if deadline is not None:
                        deadline.require_work()
                    if _pending_cancellation():
                        _consume_cancellation_request()
                        raise asyncio.CancelledError
                    tool_pause = self._pause_signal(session)
                    if tool_pause is not None:
                        # Pause beats tool admission: everything not yet
                        # dispatched closes as not-executed (P03.4).
                        async for interrupted_event in finish_interrupted(tool_pause):
                            yield interrupted_event
                        return
                    if self.steering_mode == "inject" and await self._steering_pending(session):
                        # Per-call admission check (P6.3 / proposal 5.2): the
                        # correction applies before each not-yet-admitted call;
                        # the rest close through the existing cancellation
                        # closure so no tool call is left dangling.
                        steering_entry = await self._take_steering(session)
                        if steering_entry is not None:
                            state.pending_steering_text = steering_entry["text"]
                            yield event(
                                "status.changed",
                                {
                                    "status": "steered",
                                    "receipt": "applied",
                                    "client_message_id": steering_entry["client_message_id"],
                                },
                            )
                            remaining = calls[index - 1 :]
                            remaining_durable = (
                                state.durable_executions[index - 1 :]
                                if state.durable_executions
                                else ()
                            )
                            self._close_unresolved(
                                session,
                                remaining,
                                remaining_durable,
                                ToolErrorCode.CANCELLED,
                                "纠偏已生效，剩余工具调用未执行",
                                tool_executor=tool_executor,
                                result_limit=per_call_result_limit,
                            )
                            for remaining_call in remaining:
                                yield tool_status(
                                    remaining_call,
                                    "cancelled",
                                    calls.index(remaining_call) + 1,
                                    len(calls),
                                    error_code=ToolErrorCode.CANCELLED,
                                )
                            break
                    state.active_running_id = call.id
                    yield tool_status(call, "running", index, len(calls))
                    durable = (
                        state.durable_executions[index - 1] if state.durable_executions else None
                    )
                    if tool_cycle is None:
                        raise RuntimeError("tool cycle executor is unavailable")
                    task_run_id = getattr(durable_runtime, "current_task_run_id", None)
                    if isinstance(task_run_id, str) and task_run_id.strip():
                        state.run_context.owner_task_id = task_run_id
                    try:
                        async with asyncio.timeout(
                            deadline.require_work() if deadline is not None else None
                        ):
                            call_execution = await tool_cycle.execute_call(
                                session,
                                call,
                                durable_execution=durable,
                                run_context=state.run_context,
                                ordinal=index,
                                total=len(calls),
                                result_limit=per_call_result_limit,
                            )
                    except TimeoutError as exc:
                        if deadline is not None and deadline.remaining_seconds() <= 0:
                            raise RunDeadlineExceeded(
                                "任务运行时间已用尽，正在保存已有结果"
                            ) from exc
                        raise
                    except ToolPauseRequested as pause_exc:
                        # The approval wait was interrupted: the durable
                        # approval row stays pending (never auto-approved or
                        # denied); the call closes as not-executed.
                        async for interrupted_event in finish_interrupted(pause_exc.signal):
                            yield interrupted_event
                        return
                    result = call_execution.outcome
                    durable = call_execution.durable_execution
                    failure_streak = 0
                    repeated_stop: str | None = None
                    argument_fingerprint = _fingerprint(call.arguments)
                    if not result.ok and result.error_code is not None:
                        streak_key = (
                            call.name,
                            result.error_code.value,
                            result.validation_path or "",
                            argument_fingerprint,
                            _fingerprint(result.envelope),
                        )
                        failure_streak = (
                            state.failure_streak_count + 1
                            if state.failure_streak_key == streak_key
                            else 1
                        )
                        state.failure_streak_key = streak_key
                        state.failure_streak_count = failure_streak
                        state.success_streak_key = None
                        state.success_streak_count = 0
                        if failure_streak >= REPEATED_FAILURE_HINT_THRESHOLD:
                            result = _with_failure_hint(result, failure_streak)
                        if (
                            failure_streak >= REPEATED_FAILURE_STOP_THRESHOLD
                            and result.validation_path is not None
                        ):
                            repeated_stop = (
                                f"工具 {call.name} 已连续 {failure_streak} 次以相同参数和错误结果失败"
                                f"（错误 {result.error_code.value}，"
                                f"位置 {result.validation_path}），继续重试无法取得进展，"
                                "已停止本轮任务。请保留已有结论并修正完成方式。"
                            )
                    else:
                        state.failure_streak_key = None
                        state.failure_streak_count = 0
                        if result.ok:
                            success_key = (
                                call.name,
                                argument_fingerprint,
                                _fingerprint(result.envelope),
                            )
                            success_count = (
                                state.success_streak_count + 1
                                if state.success_streak_key == success_key
                                else 1
                            )
                            state.success_streak_key = success_key
                            state.success_streak_count = min(
                                success_count, REPEATED_SUCCESS_HINT_THRESHOLD
                            )
                            if success_count == REPEATED_SUCCESS_HINT_THRESHOLD:
                                result = _with_repeated_success_hint(
                                    result, result_limit=per_call_result_limit
                                )
                        else:
                            state.success_streak_key = None
                            state.success_streak_count = 0
                    if durable is not None:
                        if durable_runtime is None:
                            raise RuntimeError(
                                "durable execution requires a durable runtime coordinator"
                            )
                        planned_tool = session.log.plan_append_tool_result(call.id, result.envelope)
                        durable_runtime.commit_tool_message(
                            planned_tool, durable, now=self._wall_now(session)
                        )
                    else:
                        session.append_tool_result(call.id, result.envelope)
                    state.run_context.note_tool_outcome(ok=result.ok, error_code=result.error_code)
                    state.active_running_id = None
                    yield tool_status(
                        call,
                        "succeeded" if result.ok else "failed",
                        index,
                        len(calls),
                        error_code=result.error_code,
                        truncated=result.truncated,
                    )
                    commit_pause = self._pause_signal(session)
                    if commit_pause is not None:
                        # Check point: the tool result just committed durably.
                        # Already-committed results are preserved; no further
                        # dispatch happens this turn (A04).
                        async for interrupted_event in finish_interrupted(commit_pause):
                            yield interrupted_event
                        return
                    if repeated_stop is not None:
                        for item in terminal_error(repeated_stop, AgentStopCode.LOOP_DETECTED):
                            yield item
                        return
                state.active_calls = ()
                state.active_result_limit = None
                if await self._host_stop_requested(session, message):
                    yield event("status.changed", {"status": "stopped", "source": "host"})
                    session.finish_turn(FinishReason.CANCELLED)
                    state.terminal_finish_reason = FinishReason.CANCELLED
                    state.stop_code = None
                    retain_facts(FinishReason.CANCELLED.value)
                    yield event(
                        "turn.completed",
                        completion_payload(FinishReason.CANCELLED, state.visible),
                    )
                    return
                if await self._steering_pending(session) and self.steering_mode != "inject":
                    session.finish_turn(FinishReason.STEERED)
                    state.settled = True
                    state.terminal_finish_reason = FinishReason.STEERED
                    state.stop_code = None
                    retain_facts(FinishReason.STEERED.value)
                    yield event("status.changed", {"status": "steered"})
                    yield event(
                        "turn.completed",
                        completion_payload(FinishReason.STEERED, state.visible),
                    )
                    return
        except InjectedFault:
            state.settled = True
            state.crashed = True
            raise
        except (RunDeadlineExceeded, ModelAttemptExceeded) as exc:
            if not state.started:
                state.started = True
                yield event("turn.started", {})
            state.settled = True
            stop_code = (
                AgentStopCode.RUN_TIMEOUT
                if isinstance(exc, RunDeadlineExceeded)
                else AgentStopCode.PROVIDER_TIMEOUT
            )
            unresolved = session.log.unresolved_call_ids
            interrupted = self._close_unresolved(
                session,
                state.active_calls,
                state.durable_executions,
                ToolErrorCode.TIMEOUT,
                "任务截止时间已到，工具调用未完成",
                tool_executor=tool_executor,
                result_limit=state.active_result_limit,
            )
            for status_event in synthetic_statuses(
                unresolved, code=ToolErrorCode.TIMEOUT, running_status="failed"
            ):
                yield status_event
            if session.log.has_active_turn:
                for item in terminal_error(str(exc), stop_code, interrupted=interrupted):
                    yield item
            else:
                state.terminal_finish_reason = FinishReason.ERROR
                state.stop_code = stop_code
                for item in fatal(str(exc), stop_code):
                    yield item
            return
        except asyncio.CancelledError:
            if state.final_committed:
                return
            if not (cancelled_is_user() if callable(cancelled_is_user) else cancelled_is_user):
                # A process-local driver disappearing is a recovery boundary,
                # not a durable user command. Keep the active Turn, TaskRun,
                # AgentRun, and workflow leaf open so another host can resume
                # from their committed evidence.
                state.settled = True
                state.crashed = True
                raise
            if not state.started:
                yield event("turn.started", {})
            _consume_cancellation_request()
            state.settled = True
            unresolved = session.log.unresolved_call_ids
            interrupted = self._close_unresolved(
                session,
                state.active_calls,
                state.durable_executions,
                ToolErrorCode.CANCELLED,
                "任务已取消，工具调用未完成",
                tool_executor=tool_executor,
                result_limit=state.active_result_limit,
            )
            for status_event in synthetic_statuses(
                unresolved,
                code=ToolErrorCode.CANCELLED,
                running_status="cancelled",
            ):
                yield status_event
            if session.log.has_active_turn:
                try:
                    session.finish_turn(FinishReason.CANCELLED, interrupted_call_ids=interrupted)
                except ConversationLogError:
                    pass
            state.terminal_finish_reason = FinishReason.CANCELLED
            state.stop_code = None
            retain_facts(FinishReason.CANCELLED.value)
            yield event(
                "turn.completed",
                completion_payload(FinishReason.CANCELLED, state.visible),
            )
            return
        except Exception as exc:
            fingerprint = _internal_error_fingerprint(exc, state.internal_phase)
            logger.error(
                "task failed: class=%s phase=%s fingerprint=%s",
                type(exc).__name__,
                state.internal_phase,
                fingerprint,
            )
            if not state.started:
                state.started = True
                yield event("turn.started", {})
            state.settled = True
            known_failure = isinstance(exc, ApplicationError)
            state.stop_detail = None if known_failure else state.internal_phase
            stop_code = AgentStopCode.KNOWN_FAILURE if known_failure else AgentStopCode.INTERNAL
            unresolved = session.log.unresolved_call_ids
            interrupted = self._close_unresolved(
                session,
                state.active_calls,
                state.durable_executions,
                ToolErrorCode.INTERNAL,
                "任务执行发生未预期错误",
                tool_executor=tool_executor,
                result_limit=state.active_result_limit,
            )
            for status_event in synthetic_statuses(
                unresolved,
                code=ToolErrorCode.INTERNAL,
                running_status="failed",
            ):
                yield status_event
            if session.log.has_active_turn:
                try:
                    session.finish_turn(
                        FinishReason.ERROR,
                        interrupted_call_ids=interrupted,
                        stop_code=stop_code,
                    )
                except ConversationLogError:
                    pass
            state.terminal_finish_reason = FinishReason.ERROR
            state.stop_code = stop_code
            retain_facts(FinishReason.ERROR.value)
            if stop_code is AgentStopCode.INTERNAL and state.agent_run_id is not None:
                error_class = type(exc).__name__
                phase = state.internal_phase
                yield event(
                    "status.changed",
                    {
                        "status": "internal_error",
                        "error_class": error_class[:64],
                        "phase": phase,
                        "reason_fingerprint": fingerprint,
                    },
                )
            if isinstance(exc, ApplicationError):
                message = exc.message
            elif isinstance(exc, PublicDiagnosticError):
                message = exc.public_message
            else:
                message = "任务执行发生未预期错误"
            for item in fatal(message, stop_code):
                yield item
            return
        finally:
            retain_facts()
            if not state.settled and session.log.has_active_turn:
                try:
                    interrupted = self._close_unresolved(
                        session,
                        state.active_calls,
                        state.durable_executions,
                        ToolErrorCode.CANCELLED,
                        "任务已取消，工具调用未完成",
                        tool_executor=tool_executor,
                        result_limit=state.active_result_limit,
                    )
                    session.finish_turn(FinishReason.CANCELLED, interrupted_call_ids=interrupted)
                    state.terminal_finish_reason = FinishReason.CANCELLED
                    state.stop_code = None
                except Exception:
                    pass
            finalize_observation()
            if prepared is not None:
                close = getattr(prepared, "aclose", None)
                if close is None:
                    prepared.close()
                else:
                    result = close()
                    if inspect.isawaitable(result):
                        await result

    @staticmethod
    def _cycle_result_limit(policy) -> int | None:
        """Return the per-call raw envelope cap when it can fit an error envelope."""
        high = policy.effective_result_limit
        return high if high >= MIN_ERROR_ENVELOPE_CHARS else None

    def _close_unresolved(
        self,
        session: Session,
        active_calls,
        durable_executions,
        code: ToolErrorCode,
        message: str,
        *,
        tool_executor,
        result_limit: int | None,
    ) -> tuple[str, ...]:
        """One synthetic envelope per unresolved call, in original order."""
        interrupted = session.log.unresolved_call_ids
        if result_limit is not None:
            effective_result_limit = result_limit
        elif tool_executor is not None:
            effective_result_limit = tool_executor.run_policy.effective_result_limit
        else:
            # Pre-start failures and generator close can have no executor at all.
            # There should be no unresolved calls in that state, but use the loop
            # policy for the defensive path instead of dereferencing ``None``.
            effective_result_limit = self.run_policy.effective_result_limit
        calls_by_id = {call.id: call for call in active_calls}
        executions_by_call_id = {durable_call_id(item.call_id): item for item in durable_executions}
        durable_runtime = session.durable_runtime
        while session.log.unresolved_call_ids:
            call_id = session.log.unresolved_call_ids[0]
            call = calls_by_id.get(call_id)
            if call is None:
                raise RuntimeError("open ToolCycle call is missing from the active batch")
            if tool_executor is None:
                raise RuntimeError("open ToolCycle requires a ToolExecutor")
            outcome = tool_executor.error_outcome(
                call,
                code,
                message,
                result_limit=effective_result_limit,
            )
            durable = executions_by_call_id.get(durable_call_id(call_id))
            if durable is None or durable_runtime is None:
                session.append_tool_result(call_id, outcome.envelope)
                continue

            durable = ToolCycleExecutor.reload_durable(session, durable)
            if durable.state in {
                ToolExecutionState.PREPARED,
                ToolExecutionState.AWAITING_APPROVAL,
            }:
                durable = durable_runtime.cancel_execution_before_handler(
                    durable, now=self._wall_now(session)
                )
            elif durable.state is ToolExecutionState.EXECUTING:
                durable = durable_runtime.record_handler_completed(
                    durable,
                    outcome,
                    now=self._wall_now(session),
                    disposition=ToolExecutionDisposition.UNKNOWN,
                )
            outcome = ToolCycleExecutor._attach_artifact_references(
                outcome,
                (
                    *outcome.artifact_refs,
                    *outcome.mcp_result_artifact_refs,
                    *durable.artifact_refs,
                ),
                result_limit=effective_result_limit,
            )
            if durable.state not in {
                ToolExecutionState.CLOSED,
                ToolExecutionState.HANDLER_COMPLETED,
            }:
                session.append_tool_result(call_id, outcome.envelope)
                continue
            planned = session.log.plan_append_tool_result(call_id, outcome.envelope)
            durable_runtime.commit_tool_message(planned, durable, now=self._wall_now(session))
        return interrupted


class AgentRuntime:
    """Plain-chat runtime composed around the single AgentLoop."""

    def __init__(
        self,
        provider: ModelProvider,
        model: ModelRef,
        context_builder,
        *,
        id_source: IdSource | None = None,
        clock: Clock | None = None,
        tool_executor: ToolExecutor | None = None,
        grant_provider=None,
        should_stop_after_turn=None,
        retry_sleep=None,
        retry_unit: Callable[[], float] | None = None,
        runtime_control=None,
        activity_observer: ModelContentObserver | None = None,
        pause_control=None,
    ) -> None:
        self._loop = AgentLoop(
            provider,
            model,
            context_builder,
            id_source=id_source,
            clock=clock,
            tool_executor=tool_executor,
            grant_provider=grant_provider,
            should_stop_after_turn=should_stop_after_turn,
            retry_sleep=retry_sleep,
            retry_unit=retry_unit,
            runtime_control=runtime_control,
            activity_observer=activity_observer,
            pause_control=pause_control,
        )

    @property
    def loop(self) -> AgentLoop:
        return self._loop

    def run_turn(
        self,
        session: Session,
        user_input: str,
        *,
        client_message_id: str | None = None,
        prepared: PreparedAgentRunRuntime | None = None,
        startup_error: str | ApplicationError | None = None,
        agent_run_id: str | None = None,
        cancelled_is_user: bool | Callable[[], bool] = True,
        run_timeout_seconds: float | None = None,
    ) -> AsyncIterator[AgentEvent]:
        return self._loop.run_task(
            session,
            user_input,
            client_message_id=client_message_id,
            prepared=prepared,
            startup_error=startup_error,
            agent_run_id=agent_run_id,
            cancelled_is_user=cancelled_is_user,
            run_timeout_seconds=run_timeout_seconds,
        )

    async def compact_idle(self, session: Session, *, instructions: str = "") -> bool:
        return await self._loop.compact_idle(session, instructions=instructions)
