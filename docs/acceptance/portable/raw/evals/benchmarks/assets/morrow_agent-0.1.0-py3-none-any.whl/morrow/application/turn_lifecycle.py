"""Durable Turn submission, terminal commit, and Session restoration boundaries."""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from datetime import datetime
from typing import Literal

from morrow.application.compaction_persistence import compaction_entries_from_checkpoints
from morrow.application.preferences.jobs import PreferenceReviewJobEnqueuer
from morrow.application.preferences.run_projection import select_run_preferences
from morrow.application.recovery import RecoveryService
from morrow.application.tasks import TaskOutcomeAssembler, TaskService
from morrow.core.agent_runs import PreparedAgentRunSpec
from morrow.core.application import ApplicationError, ApplicationErrorCode
from morrow.core.context import ContextCheckpoint
from morrow.core.domain import (
    AGENT_RUN_ID_PREFIX,
    COMMAND_ID_PREFIX,
    TASK_RUN_ID_PREFIX,
    AgentRunSnapshot,
    DurableAgentRun,
    DurableSession,
    DurableTaskRun,
    DurableTurn,
    SessionHealth,
    SessionLifecycle,
    SourceRevisionRef,
    TaskOutcomeTrigger,
    TaskRunStatus,
    TurnSubmitDisposition,
    TurnSubmitReceipt,
    canonical_json_bytes,
    session_can_start_work,
    sha256_digest,
)
from morrow.core.journal import TurnLifecycleJournalPort
from morrow.core.memory_selection import MemoryQuery, MemorySelection
from morrow.core.memory_selection_ports import (
    MemoryRunProjectionJournalPort,
    MemorySelectionAdmissionPort,
)
from morrow.core.models import (
    AgentStopCode,
    FinishReason,
    ModelRef,
    StatePresence,
    ToolDefinition,
    UserMessage,
)
from morrow.core.ports import IdSource
from morrow.core.preference_documents import PreferenceDocument
from morrow.core.prompt import PromptProjection
from morrow.core.recovery import RecoveryReport, RecoveryReportStatus
from morrow.core.skills.selection import SkillSelectionPlan
from morrow.core.store import StorageError, StorageErrorCode
from morrow.runtime.conversation import (
    ConversationAppend,
    ConversationLog,
    ConversationLogError,
    ConversationSnapshot,
    TurnTerminalRecord,
)
from morrow.runtime.durable_log import (
    DurableConversationWriter,
    restore_conversation_log,
)
from morrow.runtime.session import Session

from .learning.memory_run_projection import (
    build_run_context_projection,
    load_run_context_projection,
)
from .learning.memory_selector import MemorySelector


@dataclass
class DurableTurnState:
    """Mutable in-process projection of the currently durable foreground work."""

    turn_id: str | None = None
    task_run_id: str | None = None
    agent_run_id: str | None = None
    permission_snapshot_id: str | None = None
    last_client_message_id: str | None = None
    open_report: RecoveryReport | None = None
    pending_resume: bool = False

    def reset(self) -> None:
        self.turn_id = None
        self.task_run_id = None
        self.agent_run_id = None
        self.permission_snapshot_id = None
        self.last_client_message_id = None
        self.open_report = None
        self.pending_resume = False


@dataclass(frozen=True)
class TurnSubmitResult:
    kind: Literal["accepted", "closed_replay", "recovery", "conflict"]
    turn_id: str | None
    receipt: TurnSubmitReceipt | None = None
    assistant_text: str | None = None
    finish_reason: FinishReason | None = None
    stop_code: AgentStopCode | None = None


@dataclass(frozen=True)
class _AcceptedTurn:
    turn_id: str
    task_run_id: str
    agent_run_id: str


@dataclass(frozen=True, slots=True)
class PreferenceRunSources:
    """Pre-transaction YAML sources, including empty layers for degraded reads."""

    global_document: PreferenceDocument
    workspace_document: PreferenceDocument
    workspace_presence: StatePresence = StatePresence.PRESENT
    refresh_status: Literal["ok", "degraded"] = "ok"
    refresh_error: str | None = None


class TurnSubmissionCoordinator:
    """Own atomic Turn admission, submit replay, and terminal Task transitions."""

    def __init__(
        self,
        journal: MemorySelectionAdmissionPort,
        *,
        workspace_id: str,
        id_source: IdSource,
        model: ModelRef,
        run_policy,
        runtime_instance_id: str,
        tasks: TaskService,
        clock: Callable[[], datetime],
        state: DurableTurnState,
        preference_reviews: PreferenceReviewJobEnqueuer | None = None,
        preference_loader: Callable[[], PreferenceRunSources] | None = None,
        skill_selection=None,
        prompt_assembler=None,
        workflow_leaf=None,
    ) -> None:
        self.journal = journal
        self.workspace_id = workspace_id
        self.id_source = id_source
        self.model = model
        self.run_policy = run_policy
        self.runtime_instance_id = runtime_instance_id
        self.tasks = tasks
        self.clock = clock
        self.state = state
        self.preference_reviews = preference_reviews
        self.preference_loader = preference_loader
        self.skill_selection = skill_selection
        self.prompt_assembler = prompt_assembler
        self.workflow_leaf = workflow_leaf
        self.memory_selector = MemorySelector(id_source=id_source, clock=clock)

    def commit(
        self,
        planned: ConversationAppend,
        *,
        session: Session,
        writer: DurableConversationWriter,
    ) -> None:
        terminal = planned.added[-1] if planned.added else None
        if not isinstance(terminal, TurnTerminalRecord):
            writer.commit(planned)
            return
        if terminal.turn_id is None and self.state.turn_id is not None:
            terminal = terminal.model_copy(update={"turn_id": self.state.turn_id})
            planned = ConversationAppend(
                added=(*planned.added[:-1], terminal),
                snapshot=ConversationSnapshot(records=(*planned.snapshot.records[:-1], terminal)),
            )

        # A Workflow leaf publishes/binds its declared outputs after the final
        # Assistant commit and before this terminal transaction; a known output
        # failure raises here so the ordinary error path closes the leaf.
        leaf_bindings: tuple = ()
        if self.workflow_leaf is not None and terminal.finish_reason is FinishReason.STOP:
            leaf_bindings = self.workflow_leaf.prepare_terminal_outputs()

        def work(txn: TurnLifecycleJournalPort) -> bool:
            writer.persist_with_records(planned)
            if self.preference_reviews is not None:
                self.preference_reviews.enqueue_terminal_turn(
                    txn,
                    session=session,
                    turn_id=self.state.turn_id,
                    conversation=planned.snapshot,
                    terminal=terminal,
                )
            if self.workflow_leaf is not None:
                clear_task = self.workflow_leaf.apply_terminal_in_txn(
                    txn,
                    session,
                    terminal,
                    leaf_bindings,
                    turn_id=self.state.turn_id,
                )
            else:
                clear_task = self._apply_task_terminal_in_txn(txn, session, terminal)
                if terminal.finish_reason is FinishReason.INTERRUPTED:
                    from morrow.application.task_continuity import save_chat_interruption

                    save_chat_interruption(
                        txn,
                        workspace_id=self.workspace_id,
                        session_id=session.session_id,
                        state=self.state,
                        terminal=terminal,
                        now=self.clock(),
                    )
            self._close_open_receipt_in_txn(txn, session)
            return clear_task

        clear_task = self.journal.transact(work)
        session.log.apply_committed(planned)
        session.dirty = session.log.has_active_turn
        if clear_task:
            self.state.task_run_id = None

    def close_open_receipt(self, session: Session) -> None:
        if self.state.last_client_message_id is None:
            return
        receipt = self.journal.get_receipt(
            self.workspace_id, session.session_id, self.state.last_client_message_id
        )
        if receipt is None or receipt.disposition is TurnSubmitDisposition.ACCEPTED_CLOSED:
            return
        self.journal.update_receipt(
            self.workspace_id,
            receipt.model_copy(update={"disposition": TurnSubmitDisposition.ACCEPTED_CLOSED}),
        )

    def _attachments(self, session, key):
        from morrow.core.models import AttachmentRef

        entry = self.journal.interactions.get(self.workspace_id, session.session_id, key)
        return (
            tuple(AttachmentRef.model_validate(a) for a in entry["request"].get("attachments", ()))
            if entry
            else ()
        )

    def probe(
        self,
        session: Session,
        user_input: str,
        client_message_id: str,
        *,
        digest: str | None = None,
    ) -> TurnSubmitResult:
        """Classify one submission read-only.

        Never creates IDs, loads preferences YAML, or performs external work;
        `prepare_new()` may then run only when the probe says the run is new.
        """
        digest = digest or request_digest(user_input, self._attachments(session, client_message_id))
        classified = _classify_receipt(
            self.journal.get_receipt(self.workspace_id, session.session_id, client_message_id),
            digest,
            session,
            journal=self.journal,
            workspace_id=self.workspace_id,
        )
        if classified is not None:
            return classified
        if session.health is SessionHealth.NEEDS_RECOVERY:
            return TurnSubmitResult("recovery", self.state.turn_id, None)
        if session.lifecycle is not SessionLifecycle.ACTIVE:
            raise ApplicationError(
                ApplicationErrorCode.INVALID,
                "only an active Session can start a Turn",
            )
        if session.health is not SessionHealth.OK:
            raise _turn_health_error(session.health)
        return TurnSubmitResult("new", None, None)

    def submit_user(
        self,
        session: Session,
        user_input: str,
        client_message_id: str,
        *,
        turn_id: str,
        agent_run_id: str,
        tools: tuple[ToolDefinition, ...] = (),
        prepared_spec: PreparedAgentRunSpec | None = None,
        prepared_mcp_run=None,
        prompt_projection=None,
        writer: DurableConversationWriter,
    ) -> TurnSubmitResult:
        digest = request_digest(user_input, self._attachments(session, client_message_id))
        result = self.probe(session, user_input, client_message_id, digest=digest)
        if result.kind != "new":
            if result.kind == "recovery" and result.receipt is not None:
                self._mark_needs_recovery(session)
            return result
        if prompt_projection is None and self.prompt_assembler is not None:
            try:
                prompt_projection = self.prompt_assembler.prepare_for_task()
            except Exception as exc:
                raise StorageError(
                    StorageErrorCode.NEEDS_REPAIR,
                    "project instruction projection cannot be prepared",
                ) from exc
        if prompt_projection is not None:
            if self.prompt_assembler is None:
                raise StorageError(
                    StorageErrorCode.NEEDS_REPAIR,
                    "fresh prompt projection cannot be verified",
                )
            try:
                self.prompt_assembler.verify_projection(prompt_projection)
            except Exception as exc:
                raise StorageError(
                    StorageErrorCode.NEEDS_REPAIR,
                    "fresh prompt projection cannot be verified",
                ) from exc

        preference_sources = (
            self.preference_loader() if self.preference_loader is not None else None
        )
        attachments = self._attachments(session, client_message_id)
        entry = (
            self.journal.interactions.get(self.workspace_id, session.session_id, client_message_id)
            if attachments
            else None
        )
        planned = session.log.plan_begin_turn(
            UserMessage(
                content=entry["request"]["text"] if entry else user_input, attachments=attachments
            )
        )
        command_id = self.id_source.new_id(COMMAND_ID_PREFIX)

        def work(txn: MemorySelectionAdmissionPort) -> _AcceptedTurn | TurnSubmitResult:
            # Concurrent-loser recheck: a receipt that appeared after the probe
            # wins; the unused prepared runtime is closed by the caller.
            recheck = _classify_receipt(
                txn.get_receipt(self.workspace_id, session.session_id, client_message_id),
                digest,
                session,
                journal=txn,
                workspace_id=self.workspace_id,
            )
            if recheck is not None:
                return recheck
            row = txn.get_session(self.workspace_id, session.session_id)
            if row is None:
                if self.workflow_leaf is not None:
                    raise ApplicationError(
                        ApplicationErrorCode.INVALID,
                        "Workflow leaf Session must already exist before its Turn",
                    )
                stamp = self.clock()
                row = txn.create_session(
                    DurableSession(
                        session_id=session.session_id,
                        workspace_id=self.workspace_id,
                        created_at=stamp,
                        updated_at=stamp,
                    )
                )
            if not session_can_start_work(row.lifecycle, row.health):
                if row.lifecycle is not SessionLifecycle.ACTIVE:
                    raise ApplicationError(
                        ApplicationErrorCode.INVALID,
                        "only an active Session can start a Turn",
                    )
                if row.health is SessionHealth.NEEDS_RECOVERY:
                    return TurnSubmitResult("recovery", self.state.turn_id, None)
                raise _turn_health_error(row.health)
            task_id = row.current_task_run_id
            if (
                self.workflow_leaf is not None
                and task_id != self.workflow_leaf.context.leaf_task_run_id
            ):
                raise ApplicationError(
                    ApplicationErrorCode.INVALID,
                    "Workflow leaf Session does not point at its owned Task",
                )
            follow_up_task = None
            if task_id is not None:
                current_task = txn.get_task_run(self.workspace_id, task_id)
                if current_task is None:
                    raise RuntimeError("current durable TaskRun is missing")
                if current_task.status is TaskRunStatus.READY_FOR_ACCEPTANCE:
                    follow_up_task = current_task
                elif current_task.status is TaskRunStatus.FAILED:
                    raise ApplicationError(
                        ApplicationErrorCode.INVALID,
                        "当前 TaskRun 已失败；请先运行 "
                        f"`morrow task resume {current_task.task_run_id}`，再继续此 Session。",
                    )
                elif current_task.status.is_terminal:
                    task_id = None
            if task_id is None:
                stamp = self.clock()
                task = txn.create_task_run(
                    self.workspace_id,
                    DurableTaskRun(
                        task_run_id=self.id_source.new_id(TASK_RUN_ID_PREFIX),
                        session_id=session.session_id,
                        workspace_id=self.workspace_id,
                        created_at=stamp,
                        updated_at=stamp,
                    ),
                    make_current=True,
                )
                task_id = task.task_run_id
            stamp = self.clock()
            durable_turn = DurableTurn(
                turn_id=turn_id,
                session_id=session.session_id,
                task_run_id=task_id,
                client_message_id=client_message_id,
                created_at=stamp,
            )
            if self.workflow_leaf is not None:
                self.workflow_leaf.create_turn_in_txn(txn, durable_turn)
            else:
                txn.create_turn(self.workspace_id, durable_turn)
            if follow_up_task is not None:
                self.tasks._transition_in_txn(
                    txn,
                    follow_up_task,
                    TaskRunStatus.OPEN,
                    reason="ordinary_follow_up",
                    turn_id=turn_id,
                )
            stored_agent_run_id = agent_run_id or self.id_source.new_id(AGENT_RUN_ID_PREFIX)
            definition_skills = None
            if prepared_spec is not None and prepared_spec.definition_ref is not None:
                if self.workflow_leaf is not None:
                    # Workflow leaf admission checks frozen evidence and revocation,
                    # never the mutable head; ordinary disable cannot reach an
                    # already-admitted Run.
                    definition_skills = self.workflow_leaf.check_turn_admission_in_txn(
                        txn, prepared_spec
                    )
                    # Input binding joins the same authoritative transaction, so
                    # a Pause can never land between binding and admission.
                    self.workflow_leaf.bind_node_inputs_in_txn(txn)
                else:
                    from morrow.application.agent_definitions.admission import (
                        require_definition_admission,
                    )

                    definition = require_definition_admission(
                        txn,
                        self.workspace_id,
                        prepared_spec,
                        session.session_id,
                    )
                    definition_skills = definition.source.skill_version_ids
                if definition_skills and self.skill_selection is None:
                    from morrow.application.agent_definitions.errors import (
                        AgentDefinitionAdmissionError,
                        DefinitionFailure,
                    )

                    raise AgentDefinitionAdmissionError(DefinitionFailure.SKILLS)
            skill_plan = (
                self.skill_selection.select(
                    agent_run_id=stored_agent_run_id,
                    **(
                        {
                            "exact_version_ids": definition_skills,
                            "available_tools": tuple(tool.function.name for tool in tools),
                        }
                        if definition_skills is not None
                        else {}
                    ),
                    user_input=user_input,
                    workspace_id=self.workspace_id,
                    now=stamp,
                )
                if self.skill_selection is not None
                else SkillSelectionPlan()
            )
            selection = self.memory_selector.select(
                txn,
                MemoryQuery(
                    workspace_id=self.workspace_id,
                    task_run_id=task_id,
                    turn_id=turn_id,
                    task_goal=user_input or "分析所附文件",
                ),
                now=stamp,
            )
            snapshot = build_agent_run_snapshot(
                session,
                model=self.model if prepared_spec is None else prepared_spec.provider_runtime.model,
                run_policy=self.run_policy if prepared_spec is None else prepared_spec.run_policy,
                tools=tools,
                runtime_instance_id=self.runtime_instance_id,
                input_attachments=self._attachments(session, client_message_id),
                memory_selection=selection,
                preference_sources=preference_sources,
                prepared_spec=prepared_spec,
                skill_plan=skill_plan,
                prompt_projection=prompt_projection,
            )
            txn.put_memory_selection(self.workspace_id, selection)
            resume_parent = None
            pause_owner = "workflow_run" if self.workflow_leaf is not None else "chat_turn"
            pause_owner_id = (
                self.workflow_leaf.context.workflow_run_id
                if self.workflow_leaf is not None
                else session.session_id
            )
            point = txn.workflows.execution_pause.latest_pause_point(
                self.workspace_id, owner=pause_owner, owner_id=pause_owner_id
            )
            if point is not None and point.cancelled_at is None:
                continuation_accepted = (
                    point.fact.lifecycle == "suspended"
                    or point.continuation_command_id == client_message_id
                )
                if continuation_accepted and self.workflow_leaf is not None:
                    segments = txn.workflows.segments_for_node(
                        self.workspace_id, self.workflow_leaf.context.node_run_id
                    )
                    if segments and segments[-1].status == "interrupted":
                        resume_parent = segments[-1].agent_run_id
                elif continuation_accepted and point.safety is not None:
                    if point.safety.task_run_id == task_id:
                        resume_parent = point.safety.interrupted_agent_run_id
                        from morrow.application.execution_pause import ExecutionPauseService

                        ExecutionPauseService(
                            self.journal,
                            workspace_id=self.workspace_id,
                            clock=self.clock,
                        ).resume_chat_pause(session.session_id, command_id=client_message_id)
            txn.create_agent_run(
                self.workspace_id,
                DurableAgentRun(
                    resume_of_agent_run_id=resume_parent,
                    agent_run_id=stored_agent_run_id,
                    turn_id=turn_id,
                    session_id=session.session_id,
                    snapshot=snapshot,
                    created_at=stamp,
                ),
            )
            if self.workflow_leaf is not None:
                if self.workflow_leaf.parallel_read_digest is not None:
                    from morrow.application.turn_permissions import build_permission_snapshot

                    permission = build_permission_snapshot(
                        session,
                        workspace_id=self.workspace_id,
                        base_snapshot=snapshot,
                        permission_snapshot_id=self.id_source.new_id("psnap"),
                        task_run_id=task_id,
                        turn_id=turn_id,
                        agent_run_id=stored_agent_run_id,
                        created_at=stamp,
                    )
                    txn.freeze_agent_run_permission_snapshot(
                        self.workspace_id, stored_agent_run_id, permission
                    )
                self.workflow_leaf.admit_node_in_txn(
                    txn, agent_run_id=stored_agent_run_id, turn_id=turn_id
                )
            if prepared_mcp_run is not None:
                expected_ids = (
                    prepared_spec.mcp_run_snapshot_ids if prepared_spec is not None else ()
                )
                if prepared_mcp_run.snapshot_ids != expected_ids:
                    raise StorageError(
                        StorageErrorCode.UNAVAILABLE,
                        "prepared MCP snapshot references are inconsistent",
                    )
                for launch_snapshot in prepared_mcp_run.launch_snapshots:
                    txn.put_mcp_launch_snapshot(launch_snapshot)
                for tool_snapshot in prepared_mcp_run.tool_snapshots:
                    txn.put_mcp_tool_snapshot(self.workspace_id, tool_snapshot)
            if self.skill_selection is not None:
                self.skill_selection.sync_catalog(txn, skill_plan.selections, now=stamp)
            for skill_selection in skill_plan.selections:
                txn.put_skill_selection(self.workspace_id, skill_selection)
            for skill_context in skill_plan.contexts:
                txn.put_skill_context(self.workspace_id, skill_context)
            txn.put_receipt(
                self.workspace_id,
                TurnSubmitReceipt(
                    session_id=session.session_id,
                    client_message_id=client_message_id,
                    request_digest=digest,
                    disposition=TurnSubmitDisposition.ACCEPTED_OPEN,
                    turn_id=turn_id,
                    command_id=command_id,
                ),
            )
            writer.persist(planned)
            interactions = getattr(txn, "interactions", None)
            if interactions is not None:
                interactions.bind_turn(
                    self.workspace_id,
                    session.session_id,
                    client_message_id,
                    turn_id,
                    stored_agent_run_id,
                )
            runtime_control = (
                txn.get_runtime_control(self.workspace_id, session.session_id, client_message_id)
                if self.workflow_leaf is None
                else None
            )
            if runtime_control is not None:
                if runtime_control.text != user_input:
                    raise StorageError(
                        StorageErrorCode.UNAVAILABLE,
                        "runtime control entry does not match the submitted Turn",
                    )
                txn.consume_runtime_control(
                    self.workspace_id,
                    session.session_id,
                    client_message_id,
                    consumed_at=stamp,
                )
            return _AcceptedTurn(turn_id, task_id, stored_agent_run_id)

        accepted = self.journal.transact(work)
        if isinstance(accepted, TurnSubmitResult):
            if accepted.kind == "recovery":
                if accepted.receipt is not None:
                    self._mark_needs_recovery(session)
                session.health = SessionHealth.NEEDS_RECOVERY
            return accepted
        try:
            projection = load_run_context_projection(
                self.journal,
                self.workspace_id,
                accepted.agent_run_id,
                prompt_assembler=self.prompt_assembler,
                prompt_projection=prompt_projection,
            )
        except StorageError as exc:
            session.run_context_projection = None
            session.skill_context_projection = None
            if exc.code is StorageErrorCode.NEEDS_REPAIR:
                session.health = SessionHealth.QUARANTINED
            raise
        self.state.turn_id = accepted.turn_id
        self.state.task_run_id = accepted.task_run_id
        self.state.agent_run_id = accepted.agent_run_id
        self.state.permission_snapshot_id = None
        self.state.last_client_message_id = client_message_id
        session.run_context_projection = projection
        session.skill_context_projection = projection.skill_context
        if preference_sources is not None:
            session.global_preferences = preference_sources.global_document
            session.workspace_preferences = preference_sources.workspace_document
            session.global_preferences_revision = preference_sources.global_document.revision
            session.preferences_revision = preference_sources.workspace_document.revision
            session.workspace_preferences_presence = preference_sources.workspace_presence
        session.log.apply_committed(planned)
        session.dirty = True
        receipt = self.journal.get_receipt(self.workspace_id, session.session_id, client_message_id)
        return TurnSubmitResult("accepted", accepted.turn_id, receipt)

    def _mark_needs_recovery(self, session: Session) -> None:
        session.health = SessionHealth.NEEDS_RECOVERY
        row = self.journal.get_session(self.workspace_id, session.session_id)
        if row is not None and row.health is not SessionHealth.NEEDS_RECOVERY:
            self.journal.save_session(
                self.workspace_id,
                row.model_copy(update={"health": SessionHealth.NEEDS_RECOVERY}),
            )

    def _apply_task_terminal_in_txn(
        self,
        txn: TurnLifecycleJournalPort,
        session: Session,
        terminal: TurnTerminalRecord,
    ) -> bool:
        if self.state.task_run_id is None:
            return False
        task = txn.get_task_run(self.workspace_id, self.state.task_run_id)
        if task is None:
            raise RuntimeError("durable TaskRun is missing for the active turn")
        if terminal.finish_reason is FinishReason.STEERED:
            return False
        if terminal.finish_reason is FinishReason.INTERRUPTED:
            # Interrupted turns only occur with a pause authority (workflow
            # leaves); defensively keep any plain-chat task open as well.
            return False
        if terminal.finish_reason is FinishReason.STOP:
            target = TaskRunStatus.READY_FOR_ACCEPTANCE
            # Publish the result before asking the user to accept it. The snapshot
            # keeps acceptance explicit and is committed atomically with the answer.
            trigger = TaskOutcomeTrigger.SNAPSHOT
            reason = "assistant_answer_presented"
        elif terminal.finish_reason is FinishReason.CANCELLED:
            target = TaskRunStatus.CANCELLED
            trigger = TaskOutcomeTrigger.TERMINAL_CLOSE
            reason = "turn_cancelled"
        else:
            target = TaskRunStatus.FAILED
            trigger = TaskOutcomeTrigger.TERMINAL_CLOSE
            reason = "turn_failed"
        updated = self.tasks._transition_in_txn(
            txn,
            task,
            target,
            reason=reason,
            turn_id=self.state.turn_id,
        )
        if trigger is not None:
            outcomes = TaskOutcomeAssembler(
                txn,
                workspace_id=self.workspace_id,
                id_source=self.id_source,
                clock=self.clock,
            )
            txn.put_task_outcome(self.workspace_id, outcomes.build(updated, trigger=trigger))
        return target.is_terminal

    def _close_open_receipt_in_txn(self, txn: TurnLifecycleJournalPort, session: Session) -> None:
        if self.state.last_client_message_id is None:
            return
        receipt = txn.get_receipt(
            self.workspace_id, session.session_id, self.state.last_client_message_id
        )
        if receipt is None or receipt.disposition is TurnSubmitDisposition.ACCEPTED_CLOSED:
            return
        txn.update_receipt(
            self.workspace_id,
            receipt.model_copy(update={"disposition": TurnSubmitDisposition.ACCEPTED_CLOSED}),
        )


class SessionRestoreCoordinator:
    """Rebuild the in-process Session and durable foreground-work projection."""

    def __init__(
        self,
        journal: MemoryRunProjectionJournalPort,
        *,
        workspace_id: str,
        recovery: RecoveryService,
        clock: Callable[[], datetime],
        state: DurableTurnState,
        prompt_assembler=None,
    ) -> None:
        self.journal = journal
        self.workspace_id = workspace_id
        self.recovery = recovery
        self.clock = clock
        self.state = state
        self.prompt_assembler = prompt_assembler

    def start_new_session(self, session: Session, session_id: str) -> None:
        stamp = self.clock()
        self.journal.create_session(
            DurableSession(
                session_id=session_id,
                workspace_id=self.workspace_id,
                created_at=stamp,
                updated_at=stamp,
            )
        )
        session.reset(session_id)
        session.log = ConversationLog()
        self.state.reset()

    def restore_into(self, session: Session) -> None:
        self.state.reset()
        session.run_context_projection = None
        session.skill_context_projection = None
        session.restore_compaction_entries(())
        row = self.journal.get_session(self.workspace_id, session.session_id)
        if row is None:
            stamp = self.clock()
            self.journal.create_session(
                DurableSession(
                    session_id=session.session_id,
                    workspace_id=self.workspace_id,
                    created_at=stamp,
                    updated_at=stamp,
                )
            )
            return
        session.lifecycle = row.lifecycle
        session.health = row.health
        self._restore_compactions(session, row)
        session.context_checkpoint = self._restore_context_checkpoint(row)
        self.state.task_run_id = row.current_task_run_id
        try:
            session.log = restore_conversation_log(
                self.journal, self.workspace_id, session.session_id
            )
        except (ConversationLogError, ValueError):
            session.log = ConversationLog()
            session.health = SessionHealth.QUARANTINED
        except StorageError as exc:
            if exc.code is not StorageErrorCode.NEEDS_REPAIR:
                raise
            session.log = ConversationLog()
            session.health = SessionHealth.QUARANTINED
        else:
            self._restore_active_work(session)
        if session.health in (SessionHealth.NEEDS_RECOVERY, SessionHealth.QUARANTINED):
            self.journal.save_session(
                self.workspace_id,
                row.model_copy(update={"health": session.health}),
            )

    def synchronize_projection(self, session: Session) -> bool:
        """Restore a basic projection after an application transaction rolls back."""

        row = self.journal.get_session(self.workspace_id, session.session_id)
        if row is None:
            return False
        restored = restore_conversation_log(self.journal, self.workspace_id, session.session_id)
        session.log.install_snapshot(restored.snapshot())
        session.health = row.health
        session.lifecycle = row.lifecycle
        self._restore_compactions(session, row)
        session.context_checkpoint = self._restore_context_checkpoint(row)
        session.dirty = session.log.has_active_turn
        self.state.reset()
        self.state.task_run_id = row.current_task_run_id
        self._restore_active_work(session)
        return True

    def synchronize_recovery(
        self,
        session: Session,
        report: RecoveryReport,
        resumed_agent_run_id: str | None,
    ) -> None:
        row = self.journal.get_session(self.workspace_id, report.session_id)
        if row is None:
            return
        session.health = row.health
        self.state.task_run_id = row.current_task_run_id
        if resumed_agent_run_id is not None:
            self.state.agent_run_id = resumed_agent_run_id
            self.state.permission_snapshot_id = None
            try:
                session.run_context_projection = load_run_context_projection(
                    self.journal,
                    self.workspace_id,
                    resumed_agent_run_id,
                    prompt_assembler=self.prompt_assembler,
                )
            except StorageError as exc:
                if exc.code is StorageErrorCode.NEEDS_REPAIR:
                    session.run_context_projection = None
                    session.skill_context_projection = None
                    session.health = SessionHealth.QUARANTINED
                    self.journal.save_session(
                        self.workspace_id,
                        row.model_copy(update={"health": SessionHealth.QUARANTINED}),
                    )
                raise
            session.skill_context_projection = session.run_context_projection.skill_context
        elif report.status is RecoveryReportStatus.RESOLVED:
            session.run_context_projection = None
            session.skill_context_projection = None
        self.state.open_report = None if report.status is RecoveryReportStatus.RESOLVED else report

    def _restore_context_checkpoint(self, row: DurableSession) -> ContextCheckpoint | None:
        try:
            checkpoints = tuple(
                checkpoint
                for checkpoint in self.journal.list_context_checkpoints(
                    self.workspace_id, row.session_id
                )
                if checkpoint.codec != "pi_compaction"
            )
            checkpoint = checkpoints[-1] if checkpoints else None
            if checkpoint is None and row.parent_checkpoint_id is not None:
                parent = self.journal.get_context_checkpoint(
                    self.workspace_id, row.parent_checkpoint_id
                )
                if parent is not None and parent.codec != "pi_compaction":
                    checkpoint = parent
            return checkpoint
        except StorageError:
            return None

    def _restore_compactions(self, session: Session, row: DurableSession) -> None:
        try:
            checkpoints = self.journal.list_context_checkpoints(self.workspace_id, row.session_id)
            entries = compaction_entries_from_checkpoints(checkpoints)
            session.restore_compaction_entries(entries)
        except (StorageError, ValueError):
            # A corrupt projection must never silently fall back to the full recent tail: doing so
            # could repeat already compacted work.  The immutable ConversationLog remains
            # available for diagnosis, while this Session is quarantined for explicit recovery.
            session.restore_compaction_entries(())
            session.health = SessionHealth.QUARANTINED

    def _restore_active_work(self, session: Session) -> None:
        session.run_context_projection = None
        session.skill_context_projection = None
        report = self.recovery.discover(session.session_id, session.log)
        self.state.open_report = report
        if report is not None:
            self.state.turn_id = report.turn_id
            self.state.agent_run_id = report.agent_run_id
            if report.turn_id is not None:
                turn = self.journal.get_turn(self.workspace_id, report.turn_id)
                if turn is not None:
                    self.state.last_client_message_id = turn.client_message_id
            interrupted = (
                self.journal.get_agent_run(self.workspace_id, report.agent_run_id)
                if report.agent_run_id is not None
                else None
            )
            self.state.permission_snapshot_id = (
                interrupted.permission_snapshot_id if interrupted is not None else None
            )
            if interrupted is not None:
                self._install_memory_projection(session, interrupted.snapshot)
        if report is not None and session.health is not SessionHealth.QUARANTINED:
            session.health = SessionHealth.NEEDS_RECOVERY
        elif session.lifecycle is SessionLifecycle.ACTIVE and session.log.has_active_turn:
            turns = self.journal.list_session_turns(self.workspace_id, session.session_id)
            runs = self.journal.list_session_agent_runs(self.workspace_id, session.session_id)
            self.state.turn_id = turns[-1].turn_id if turns else None
            self.state.agent_run_id = runs[-1].agent_run_id if runs else None
            if turns:
                self.state.last_client_message_id = turns[-1].client_message_id
            if runs:
                self._install_memory_projection(session, runs[-1].snapshot)
            self.state.pending_resume = session.health is SessionHealth.OK

    def _install_memory_projection(self, session: Session, snapshot: AgentRunSnapshot) -> None:
        try:
            session.run_context_projection = build_run_context_projection(
                self.journal,
                self.workspace_id,
                snapshot,
                prompt_assembler=self.prompt_assembler,
            )
            session.skill_context_projection = session.run_context_projection.skill_context
        except StorageError as exc:
            if exc.code is StorageErrorCode.NEEDS_REPAIR:
                session.run_context_projection = None
                session.skill_context_projection = None
                session.health = SessionHealth.QUARANTINED
                return
            raise


def request_digest(user_input: str, attachments=()) -> str:
    payload = {"content": user_input}
    if attachments:
        payload["attachments"] = [a.model_dump(mode="json") for a in attachments]
    return sha256_digest(canonical_json_bytes(payload))


def _classify_receipt(
    receipt: TurnSubmitReceipt | None,
    digest: str,
    session: Session,
    *,
    journal: TurnLifecycleJournalPort,
    workspace_id: str,
) -> TurnSubmitResult | None:
    """Shared receipt classification used by the probe and the in-txn recheck."""
    if receipt is None:
        return None
    if receipt.request_digest != digest:
        return TurnSubmitResult("conflict", receipt.turn_id, receipt)
    if receipt.disposition is TurnSubmitDisposition.ACCEPTED_CLOSED:
        finish_reason, stop_code, assistant_text = _closed_turn_replay(
            journal, workspace_id, session, receipt
        )
        return TurnSubmitResult(
            "closed_replay",
            receipt.turn_id,
            receipt,
            assistant_text=assistant_text,
            finish_reason=finish_reason,
            stop_code=stop_code,
        )
    return TurnSubmitResult("recovery", receipt.turn_id, receipt)


def build_agent_run_snapshot(
    session: Session,
    *,
    model: ModelRef,
    run_policy,
    tools: tuple[ToolDefinition, ...],
    runtime_instance_id: str,
    input_attachments=(),
    memory_selection: MemorySelection | None = None,
    preference_sources: PreferenceRunSources | None = None,
    prepared_spec: PreparedAgentRunSpec | None = None,
    skill_plan: SkillSelectionPlan | None = None,
    prompt_projection: PromptProjection | None = None,
) -> AgentRunSnapshot:
    def source_digest(presence: StatePresence, value) -> str:
        if value is not None and not hasattr(value, "model_dump"):
            value = [item.model_dump(mode="json") for item in value]
        payload = value.model_dump(mode="json") if hasattr(value, "model_dump") else value
        return sha256_digest(
            canonical_json_bytes(
                {
                    "presence": presence.value,
                    "value": payload,
                }
            )
        )

    global_document = preference_sources.global_document if preference_sources is not None else None
    workspace_document = (
        preference_sources.workspace_document if preference_sources is not None else None
    )
    global_entries = (
        global_document.entries
        if global_document is not None
        else session.global_preferences.entries
    )
    workspace_entries = (
        workspace_document.entries
        if workspace_document is not None
        else session.workspace_preferences.entries
    )
    session_entries = session.session_preferences
    preference_projection = select_run_preferences(
        global_entries,
        workspace_entries,
        session_entries,
    )
    global_revision = (
        global_document.revision
        if global_document is not None
        else session.global_preferences_revision
    )
    workspace_revision = (
        workspace_document.revision
        if workspace_document is not None
        else session.preferences_revision
    )
    workspace_presence = (
        preference_sources.workspace_presence
        if preference_sources is not None
        else session.workspace_preferences_presence
    )

    revisions = (
        SourceRevisionRef(
            kind="global_config",
            revision=global_revision,
            content_sha256=source_digest(
                StatePresence.PRESENT,
                global_document or session.global_preferences,
            ),
        ),
        SourceRevisionRef(
            kind="workspace_profile",
            revision=session.profile_revision,
            content_sha256=source_digest(session.profile_presence, session.profile),
        ),
        SourceRevisionRef(
            kind="workspace_preferences",
            revision=workspace_revision,
            content_sha256=source_digest(
                workspace_presence,
                workspace_document or session.workspace_preferences,
            ),
        ),
        SourceRevisionRef(
            kind="session_preferences",
            revision=0,
            content_sha256=source_digest(StatePresence.PRESENT, session_entries),
        ),
    )
    tool_payload = [tool.model_dump(mode="json") for tool in tools]
    prompt_evidence = prompt_projection.evidence if prompt_projection is not None else None
    prompt_values = {
        "prompt_profile_id": (
            prompt_evidence.profile_id
            if prompt_evidence is not None
            else prepared_spec.prompt_profile_id
            if prepared_spec is not None
            else None
        ),
        "prompt_profile_version": (
            prompt_evidence.profile_version
            if prompt_evidence is not None
            else prepared_spec.prompt_profile_version
            if prepared_spec is not None
            else None
        ),
        "prompt_profile_digest": (
            prompt_evidence.profile_digest
            if prompt_evidence is not None
            else prepared_spec.prompt_profile_digest
            if prepared_spec is not None
            else None
        ),
        "role_prompt_digest": (
            prompt_evidence.role_prompt_digest
            if prompt_evidence is not None
            else prepared_spec.role_prompt_digest
            if prepared_spec is not None
            else None
        ),
        "project_instruction_resolver_version": (
            prompt_evidence.project_instruction_resolver_version
            if prompt_evidence is not None
            else (
                prepared_spec.project_instruction_resolver_version
                if prepared_spec is not None
                else None
            )
        ),
        "project_instruction_sources": (
            prompt_evidence.project_instruction_sources
            if prompt_evidence is not None
            else prepared_spec.project_instruction_sources
            if prepared_spec is not None
            else ()
        ),
        "project_instruction_selection_digest": (
            prompt_evidence.project_instruction_selection_digest
            if prompt_evidence is not None
            else (
                prepared_spec.project_instruction_selection_digest
                if prepared_spec is not None
                else None
            )
        ),
    }
    return AgentRunSnapshot(
        input_attachments=input_attachments,
        definition_ref=prepared_spec.definition_ref if prepared_spec else None,
        max_agent_generation_requests=(
            prepared_spec.max_agent_generation_requests if prepared_spec else None
        ),
        conversation_session_id=(prepared_spec.conversation_session_id if prepared_spec else None),
        profile=session.profile,
        model=model,
        provider_id=model.provider_id,
        source_revisions=revisions,
        run_policy_digest=sha256_digest(canonical_json_bytes(run_policy.model_dump(mode="json"))),
        tool_schema_digest=sha256_digest(canonical_json_bytes(tool_payload)),
        permission_profile_digest=sha256_digest(
            canonical_json_bytes(session.permission_profile.model_dump(mode="json"))
        ),
        runtime_instance_id=runtime_instance_id,
        mcp_run_snapshot_ids=(prepared_spec.mcp_run_snapshot_ids if prepared_spec else ()),
        memory_selection_id=memory_selection.selection_id if memory_selection else None,
        memory_selection_digest=memory_selection.selection_digest if memory_selection else None,
        memory_snapshot_revision=(
            memory_selection.source_memory_revision if memory_selection is not None else None
        ),
        frozen_preferences=preference_projection.entries,
        preference_projection_digest=preference_projection.digest,
        preference_omitted_count=preference_projection.omitted_count,
        preference_source_scopes=preference_projection.source_scopes,
        preference_refresh_status=(
            preference_sources.refresh_status if preference_sources is not None else "ok"
        ),
        preference_refresh_error=(
            preference_sources.refresh_error if preference_sources is not None else None
        ),
        skill_selection_ids=skill_plan.selection_ids if skill_plan is not None else (),
        skill_selection_digest=skill_plan.selection_digest if skill_plan is not None else None,
        skill_context_ids=skill_plan.context_ids if skill_plan is not None else (),
        skill_context_digest=skill_plan.context_digest if skill_plan is not None else None,
        skill_selected_count=skill_plan.selected_count if skill_plan is not None else 0,
        skill_omitted_count=skill_plan.omitted_count if skill_plan is not None else 0,
        skill_binding_digest=skill_plan.binding_digest if skill_plan is not None else None,
        skill_catalog_digest=skill_plan.catalog_digest if skill_plan is not None else None,
        provider_runtime=prepared_spec.provider_runtime if prepared_spec is not None else None,
        run_policy=prepared_spec.run_policy if prepared_spec is not None else None,
        **prompt_values,
    )


def _turn_health_error(health: SessionHealth) -> ApplicationError:
    codes = {
        SessionHealth.QUARANTINED: ApplicationErrorCode.QUARANTINED,
        SessionHealth.READ_ONLY: ApplicationErrorCode.READ_ONLY,
    }
    return ApplicationError(
        codes[health],
        f"Session health {health.value} cannot start a Turn",
    )


def _closed_turn_replay(
    journal: TurnLifecycleJournalPort,
    workspace_id: str,
    session: Session,
    receipt: TurnSubmitReceipt,
) -> tuple[FinishReason, AgentStopCode | None, str | None]:
    metrics = None
    for run in reversed(journal.list_session_agent_runs(workspace_id, session.session_id)):
        if run.turn_id != receipt.turn_id:
            continue
        metrics = journal.get_agent_run_terminal_metrics(workspace_id, run.agent_run_id)
        break
    public_turns = session.log.snapshot().public_turns(require_closed=True)
    for turn in public_turns:
        terminal = turn.terminal
        if terminal is None or terminal.turn_id != receipt.turn_id:
            continue
        stop_code = terminal.stop_code or (metrics.stop_code if metrics is not None else None)
        assistant_text = None
        if terminal.finish_reason is FinishReason.STOP and turn.final_assistant is not None:
            assistant_text = turn.final_assistant.message.content
        return terminal.finish_reason, stop_code, assistant_text
    if metrics is not None:
        return metrics.finish_reason, metrics.stop_code, None
    return FinishReason.ERROR, AgentStopCode.INTERNAL, None
