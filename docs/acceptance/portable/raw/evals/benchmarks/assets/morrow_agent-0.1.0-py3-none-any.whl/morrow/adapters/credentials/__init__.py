"""Credential storage adapters."""
