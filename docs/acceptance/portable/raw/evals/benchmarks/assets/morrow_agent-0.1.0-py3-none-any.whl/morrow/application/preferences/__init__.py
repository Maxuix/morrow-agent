"""Generic Preference application services."""
