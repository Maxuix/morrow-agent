"""Bounded Workflow payloads and exact slot/input references."""

from __future__ import annotations

from typing import Annotated, Any, Literal

from pydantic import Field, field_validator, model_validator

from morrow.core.agent_definitions import Digest
from morrow.core.domain import (
    TaskOutcomeEvidenceRef,
    canonical_json_bytes,
    refuse_secret_material,
    sha256_digest,
)
from morrow.core.models import ProtocolModel

SlotName = Annotated[str, Field(pattern=r"^[a-z][a-z0-9_-]{0,63}$")]
BoundedLine = Annotated[str, Field(min_length=1, max_length=1024)]
ArtifactId = Annotated[str, Field(pattern=r"^art_[A-Za-z0-9_-]+$")]
ToolExecutionId = Annotated[str, Field(pattern=r"^tex_[A-Za-z0-9_-]+$")]

SUBMIT_NODE_RESULT_NAME = "submit_node_result"
#: Protocol v1 is the frozen wire contract of already admitted runs. v2 adds
#: explicitly registered delivery files. A Workflow revision records the
#: version it was compiled with so recovery rebuilds the exact frozen tool
#: schema instead of silently switching an old run to v2.
SUBMIT_SCHEMA_V1 = 1
SUBMIT_SCHEMA_VERSION = 2
CAPTURE_SCHEMA_VERSION = 1
TEXT_OUTPUT_KINDS = frozenset({"TextResult"})
SUBMISSION_OUTPUT_KINDS = frozenset(
    {"EvidenceBundle", "PlanArtifact", "ReviewReport", "SynthesisReport"}
)
CAPTURE_OUTPUT_KINDS = frozenset({"ImplementationPatch", "TestReport"})
STRUCTURED_OUTPUT_KINDS = SUBMISSION_OUTPUT_KINDS | CAPTURE_OUTPUT_KINDS
RESULT_DRIVING_KIND = "ReviewReport"
MECHANISM_TOOL_NAMES = frozenset({SUBMIT_NODE_RESULT_NAME})

WorkflowContractKind = Literal[
    "TaskContract",
    "TextResult",
    "EvidenceBundle",
    "ImplementationPatch",
    "TestReport",
    "ReviewReport",
    "PlanArtifact",
    "SynthesisReport",
    "ChangeCapture",
]
NodeOutputKind = Literal[
    "TextResult",
    "EvidenceBundle",
    "ImplementationPatch",
    "TestReport",
    "ReviewReport",
    "PlanArtifact",
    "SynthesisReport",
]


class ContractRef(ProtocolModel):
    kind: WorkflowContractKind
    version: Literal[1] = 1

    @field_validator("version", mode="before")
    @classmethod
    def strict_version(cls, value):
        if type(value) is not int:
            raise ValueError("contract version must be an integer")
        return value


class TaskContractRef(ContractRef):
    kind: Literal["TaskContract"] = "TaskContract"


class NodeOutputRef(ProtocolModel):
    node_id: SlotName
    output_slot: SlotName


class WorkflowInputBinding(ProtocolModel):
    source: Literal["workflow_input"]
    input_name: SlotName
    accepts: TaskContractRef
    workflow_input: Literal["task"]


class NodeOutputBinding(ProtocolModel):
    source: Literal["node_output"]
    input_name: SlotName
    accepts: ContractRef
    node_output: NodeOutputRef


InputBinding = Annotated[WorkflowInputBinding | NodeOutputBinding, Field(discriminator="source")]


class OutputContract(ContractRef):
    kind: NodeOutputKind = "TextResult"
    slot: SlotName
    required_for_node_completion: bool = Field(default=True, strict=True)


class TaskContract(ProtocolModel):
    """Bounded input, never a permission grant or a copy of Session history."""

    objective: str = Field(min_length=1, max_length=4096)
    scope: tuple[str, ...] = Field(default=(), max_length=32)
    constraints: tuple[str, ...] = Field(default=(), max_length=32)
    source_refs: tuple[TaskOutcomeEvidenceRef, ...] = Field(default=(), max_length=32)

    @field_validator("objective")
    @classmethod
    def nonblank(cls, value):
        if not value.strip():
            raise ValueError("task objective must not be blank")
        return value

    @model_validator(mode="after")
    def safe_payload(self):
        payload = canonical_json_bytes(self.model_dump(mode="json"))
        if len(payload) > 16384:
            raise ValueError("TaskContract exceeds its payload budget")
        try:
            refuse_secret_material(
                payload, label="TaskContract", profile="workflow_value_sensitive"
            )
        except ValueError:
            raise ValueError(
                "TaskContract contains secret-shaped material that cannot be stored as a durable "
                "Workflow input; use ordinary Direct chat for this task"
            ) from None
        return self


class TextResult(ProtocolModel):
    """Reference to the owning Session's final Assistant, not a second transcript."""

    final_assistant_record_id: Annotated[str, Field(pattern=r"^rec_[A-Za-z0-9_-]+$")]
    final_assistant_sha256: Digest
    excerpt: str = Field(max_length=4096)
    content_complete: bool = Field(strict=True)

    @model_validator(mode="after")
    def safe_payload(self):
        refuse_secret_material(
            canonical_json_bytes(self.model_dump(mode="json")),
            label="TextResult",
            profile="workflow_value_sensitive",
        )
        return self


class EvidenceBundle(ProtocolModel):
    """Explorer evidence; never a permission grant or a second transcript."""

    findings: tuple[BoundedLine, ...] = Field(default=(), max_length=32)
    source_refs: tuple[BoundedLine, ...] = Field(default=(), max_length=32)
    relevant_paths: tuple[BoundedLine, ...] = Field(default=(), max_length=64)
    uncertainties: tuple[BoundedLine, ...] = Field(default=(), max_length=32)

    @model_validator(mode="after")
    def safe_payload(self):
        _refuse_workflow_payload(self, label="EvidenceBundle", budget=16384)
        return self


class PlanArtifact(ProtocolModel):
    """Planner output consumed by a Coder; bounded intent, never executable authority."""

    steps: tuple[BoundedLine, ...] = Field(min_length=1, max_length=32)
    target_paths: tuple[BoundedLine, ...] = Field(default=(), max_length=64)
    validation: tuple[BoundedLine, ...] = Field(default=(), max_length=32)
    risks: tuple[BoundedLine, ...] = Field(default=(), max_length=32)

    @model_validator(mode="after")
    def safe_payload(self):
        _refuse_workflow_payload(self, label="PlanArtifact", budget=16384)
        return self


class SynthesisReport(ProtocolModel):
    """Serial fan-in synthesis over bounded Explorer evidence bundles."""

    summary: str = Field(min_length=1, max_length=4096)
    findings: tuple[BoundedLine, ...] = Field(default=(), max_length=64)
    source_refs: tuple[BoundedLine, ...] = Field(default=(), max_length=64)
    uncertainties: tuple[BoundedLine, ...] = Field(default=(), max_length=32)

    @model_validator(mode="after")
    def safe_payload(self):
        _refuse_workflow_payload(self, label="SynthesisReport", budget=16384)
        return self


class ImplementationPatch(ProtocolModel):
    """Coder change evidence assembled from durable capture refs, never parsed text."""

    changed_paths: tuple[BoundedLine, ...] = Field(default=(), max_length=256)
    change_refs: tuple[ArtifactId, ...] = Field(default=(), max_length=64)
    content_complete: bool = Field(strict=True)
    rationale: str = Field(default="", max_length=4096)
    omission_reason: str | None = Field(default=None, max_length=256)

    @model_validator(mode="after")
    def safe_payload(self):
        _refuse_workflow_payload(self, label="ImplementationPatch", budget=16384)
        return self


class TestReportItem(ProtocolModel):
    """One ValidationFact captured at handler completion."""

    validator_kind: Annotated[str, Field(min_length=1, max_length=64)]
    scope: Annotated[str, Field(min_length=1, max_length=512)]
    status: Literal["passed", "failed", "timeout", "cancelled", "inconclusive"]
    exit_code: int | None = Field(default=None, ge=0, le=255)
    evidence_summary: Annotated[str, Field(min_length=1, max_length=80)]
    output_ref: ArtifactId | None = None
    content_complete: bool = Field(strict=True)
    omission_reason: str | None = Field(default=None, max_length=256)
    tool_execution_id: ToolExecutionId


class TestReport(ProtocolModel):
    """Per-execution or aggregate validation evidence; missing output text is not failure."""

    items: tuple[TestReportItem, ...] = Field(default=(), max_length=64)
    content_complete: bool = Field(strict=True)
    omission_reason: str | None = Field(default=None, max_length=256)

    @model_validator(mode="after")
    def safe_payload(self):
        _refuse_workflow_payload(self, label="TestReport", budget=16384)
        return self


class ReviewReport(ProtocolModel):
    """Reviewer product evidence; a blocking verdict is not an execution failure."""

    verdict: Literal["approve", "request_changes", "block"]
    findings: tuple[BoundedLine, ...] = Field(default=(), max_length=32)
    severity: Literal["info", "warning", "blocking"] = "info"
    evidence_refs: tuple[BoundedLine, ...] = Field(default=(), max_length=32)
    required_changes: tuple[BoundedLine, ...] = Field(default=(), max_length=32)
    optional_notes: tuple[BoundedLine, ...] = Field(default=(), max_length=32)

    @property
    def blocking(self) -> bool:
        return self.verdict != "approve"

    @model_validator(mode="after")
    def safe_payload(self):
        _refuse_workflow_payload(self, label="ReviewReport", budget=16384)
        return self


class ChangeCapture(ProtocolModel):
    """Per-mutation capture payload published at handler completion; not a node contract."""

    schema_version: Literal[1] = 1
    path: BoundedLine
    operation: Annotated[str, Field(min_length=1, max_length=32)]
    status: Annotated[str, Field(min_length=1, max_length=32)]
    before_sha256: Digest | None = None
    after_sha256: Digest | None = None
    before_size: int | None = Field(default=None, ge=0)
    after_size: int | None = Field(default=None, ge=0)
    unified_diff: str | None = Field(default=None, max_length=1_048_576)
    content_complete: bool = Field(strict=True)
    omission_reason: str | None = Field(default=None, max_length=256)

    @model_validator(mode="after")
    def safe_payload(self):
        _refuse_workflow_payload(self, label="ChangeCapture", budget=1_048_576 + 2048)
        return self


# Explicit delivery registration (submission protocol v2) ---------------------

#: Bounded explicit delivery registration per submission.
DELIVERY_MAX_ITEMS = 64
DELIVERY_PATH_MAX_CHARS = 512
DELIVERY_NAME_MAX_CHARS = 128
DELIVERY_MIME_MAX_CHARS = 128
#: One registered file and one submission stay inside the existing bounds.
DELIVERY_FILE_MAX_BYTES = 20 * 1024 * 1024
DELIVERY_TOTAL_MAX_BYTES = 20 * 1024 * 1024
#: Static local resources captured with one HTML deliverable.
DELIVERY_HTML_MAX_RESOURCES = 128
DELIVERY_HTML_MAX_DEPTH = 8
#: Durable descriptor/marker budgets; never a second copy of file bytes.
DELIVERY_DESCRIPTOR_MAX_BYTES = 64 * 1024
DELIVERY_MARKER_MAX_BYTES = 512 * 1024


class DeliverableRequest(ProtocolModel):
    """One model-provided registration; every other fact is server-derived."""

    path: str = Field(min_length=1, max_length=DELIVERY_PATH_MAX_CHARS)
    label: str | None = Field(default=None, max_length=DELIVERY_NAME_MAX_CHARS)

    @field_validator("path")
    @classmethod
    def relative_workspace_path(cls, value: str) -> str:
        cleaned = value.strip()
        if not cleaned:
            raise ValueError("deliverable path must not be blank")
        if "\x00" in cleaned or "\\" in cleaned:
            raise ValueError("deliverable path must be a workspace-relative POSIX path")
        if cleaned.startswith(("/", "~")):
            raise ValueError("deliverable path must be relative to the workspace")
        if len(cleaned) >= 2 and cleaned[1] == ":":
            raise ValueError("deliverable path must not carry a drive prefix")
        if any(part in {"", ".", ".."} for part in cleaned.split("/")):
            raise ValueError("deliverable path must contain only workspace components")
        return cleaned

    @field_validator("label")
    @classmethod
    def normalized_label(cls, value: str | None) -> str | None:
        if value is None:
            return None
        cleaned = " ".join(value.split())
        return cleaned or None


class DeliveryResource(ProtocolModel):
    """One static local dependency captured beside an HTML deliverable."""

    path: str = Field(min_length=1, max_length=DELIVERY_PATH_MAX_CHARS)
    artifact_id: ArtifactId
    sha256: Digest
    byte_size: int = Field(ge=0, le=DELIVERY_FILE_MAX_BYTES)


class DeliveryDescriptor(ProtocolModel):
    """Server-verified snapshot reference for one registered deliverable.

    It carries no file body: the artifact store holds the exact bytes and the
    descriptor only names the verified identity of that snapshot.
    """

    slot: SlotName
    path: str = Field(min_length=1, max_length=DELIVERY_PATH_MAX_CHARS)
    name: str = Field(min_length=1, max_length=DELIVERY_NAME_MAX_CHARS)
    #: Optional display label the model registered; the real file name stays in
    #: ``name`` and is what download uses.
    label: str | None = Field(default=None, max_length=DELIVERY_NAME_MAX_CHARS)
    mime: str = Field(min_length=1, max_length=DELIVERY_MIME_MAX_CHARS)
    artifact_id: ArtifactId
    sha256: Digest
    byte_size: int = Field(ge=0, le=DELIVERY_FILE_MAX_BYTES)
    content_complete: bool = Field(default=True, strict=True)
    resources: tuple[DeliveryResource, ...] = Field(
        default=(), max_length=DELIVERY_HTML_MAX_RESOURCES
    )
    #: Bounded limits of the captured collection (missing/remote references);
    #: a limitation is reported, never silently substituted.
    limitations: tuple[Annotated[str, Field(min_length=1, max_length=256)], ...] = Field(
        default=(), max_length=64
    )

    @model_validator(mode="after")
    def safe_descriptor(self):
        payload = canonical_json_bytes(self.model_dump(mode="json"))
        if len(payload) > DELIVERY_DESCRIPTOR_MAX_BYTES:
            raise ValueError("delivery descriptor exceeds its payload budget")
        refuse_secret_material(
            payload, label="delivery descriptor", profile="workflow_value_sensitive"
        )
        return self


class NodeSubmissionMarker(ProtocolModel):
    """Durable read model of the one completed submission of a NodeRun.

    The v1 shape (digest/slots/replan) still parses: every v2 field defaults,
    and a v1 run keeps writing exactly that shape. Slot attribution of
    ordinary delivery files lives here, never in the Artifact uniqueness
    columns.
    """

    schema_version: int = Field(default=SUBMIT_SCHEMA_V1, ge=1, strict=True)
    digest: Digest
    slots: tuple[SlotName, ...] = Field(default=(), max_length=64)
    replan: dict[str, Any] | None = None
    deliverables: tuple[DeliveryDescriptor, ...] = Field(default=(), max_length=DELIVERY_MAX_ITEMS)
    tool_execution_id: ToolExecutionId | None = None


class ArtifactBinding(ProtocolModel):
    name: SlotName
    artifact_id: ArtifactId
    contract: ContractRef


WorkflowPayload = (
    TaskContract
    | TextResult
    | EvidenceBundle
    | PlanArtifact
    | ImplementationPatch
    | TestReport
    | ReviewReport
    | SynthesisReport
)
NODE_OUTPUT_PAYLOAD_TYPES = (
    TextResult,
    EvidenceBundle,
    PlanArtifact,
    ImplementationPatch,
    TestReport,
    ReviewReport,
    SynthesisReport,
)


def _refuse_workflow_payload(model: ProtocolModel, *, label: str, budget: int) -> None:
    payload = canonical_json_bytes(model.model_dump(mode="json"))
    if len(payload) > budget:
        raise ValueError(f"{label} exceeds its payload budget")
    refuse_secret_material(payload, label=label, profile="workflow_value_sensitive")


def workflow_payload_excerpt(payload: object) -> str:
    """Bounded inspectable excerpt; never a second transcript."""

    if isinstance(payload, TaskContract):
        return payload.objective
    if isinstance(payload, TextResult):
        return payload.excerpt
    if isinstance(payload, EvidenceBundle):
        return "; ".join(payload.findings)[:4096] or "evidence"
    if isinstance(payload, PlanArtifact):
        return "; ".join(payload.steps)[:4096]
    if isinstance(payload, ImplementationPatch):
        return (payload.rationale or ",".join(payload.changed_paths) or "patch")[:4096]
    if isinstance(payload, TestReport):
        if payload.items:
            return payload.items[0].evidence_summary
        return payload.omission_reason or "tests"
    if isinstance(payload, ReviewReport):
        return (f"{payload.verdict}: " + "; ".join(payload.findings))[:4096]
    if isinstance(payload, SynthesisReport):
        return payload.summary
    if isinstance(payload, ChangeCapture):
        return f"{payload.operation} {payload.path}"[:4096]
    return type(payload).__name__


def parse_workflow_payload(kind: str, content: bytes):
    """Rehydrate one typed Workflow payload from durable bytes."""

    mapping = {
        "TaskContract": TaskContract,
        "TextResult": TextResult,
        "EvidenceBundle": EvidenceBundle,
        "PlanArtifact": PlanArtifact,
        "ImplementationPatch": ImplementationPatch,
        "TestReport": TestReport,
        "ReviewReport": ReviewReport,
        "SynthesisReport": SynthesisReport,
    }
    model = mapping.get(kind)
    if model is None:
        raise ValueError(f"unsupported Workflow contract kind {kind}")
    return model.model_validate_json(content)


def node_output_artifact_id(node_run_id: str, output_slot: str) -> str:
    """Stable byte-store identity for one NodeRun output slot."""
    return "art_" + sha256_digest(canonical_json_bytes([node_run_id, output_slot]))[:32]


def workflow_input_artifact_id(command_id: str) -> str:
    """Stable byte-store identity for the TaskContract one Start command publishes."""
    return "art_" + sha256_digest(canonical_json_bytes([command_id, "workflow_input"]))[:32]


def capture_artifact_id(
    tool_execution_id: str,
    role: str,
    schema_version: int = 1,
    *,
    path: str | None = None,
) -> str:
    """Stable byte-store identity for one ToolExecution capture role.

    ChangeCapture is per-path under one ToolExecution; pass ``path`` so two
    mutations do not collide. Validation reports omit path.
    """
    identity: list[object] = [tool_execution_id, role, schema_version]
    if path is not None:
        identity.append(path)
    return "art_" + sha256_digest(canonical_json_bytes(identity))[:32]


def node_submission_artifact_id(node_run_id: str) -> str:
    """Stable identity for the one valid structured submission of a NodeRun."""
    return (
        "art_" + sha256_digest(canonical_json_bytes([node_run_id, "node_result_submission"]))[:32]
    )
