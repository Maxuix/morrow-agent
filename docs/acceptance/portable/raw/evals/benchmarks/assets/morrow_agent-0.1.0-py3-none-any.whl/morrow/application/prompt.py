"""Reusable Direct Coding prompt profile and authority-ordered assembler."""

from __future__ import annotations

import unicodedata
from collections.abc import Sequence
from dataclasses import dataclass
from pathlib import Path

from morrow.application.project_instructions import (
    DEFAULT_PROJECT_INSTRUCTION_FILENAMES,
    PROJECT_INSTRUCTION_SOURCE_VERSION,
    ProjectInstructionError,
    ProjectInstructionResolution,
    ProjectInstructionResolver,
    render_project_instruction_block,
)
from morrow.core.domain import canonical_json_bytes, sha256_digest
from morrow.core.models import SystemMessage, ToolDefinition
from morrow.core.prompt import (
    PromptProfileEvidence,
    PromptProjection,
    project_source_reference_digest,
    project_source_selection_digest,
)

DIRECT_CODING_PROFILE_ID = "direct-coding"
DIRECT_CODING_PROFILE_VERSION = "v4"
DIRECT_CODING_ROLE_PROMPT_MAX_BYTES = 8 * 1024

DIRECT_CODING_PROTOCOL = (
    "Direct Coding 工作协议："
    "围绕用户目标主动推进，先检查相关文件、目录、现有实现和用户改动，再开始编辑。"
    "选择最小、可解释且有证据的修改面，并让实现与现有设计保持一致。"
    "保留并兼容用户已有改动，把验证强度与改动风险匹配，至少检查受影响行为。"
    "以工具返回和验证结果作为事实依据，完成修改后复查结果与工作区状态。"
    "遇到阻塞时报告具体阻塞点、已确认事实和可执行的下一步。"
    "交付时简洁说明完成内容、验证证据和仍需关注的事项。"
    "创建完成任务所需的文件；仅清理由本任务产生且确认不属于交付物的临时产物，"
    "保留任务要求的文件、服务和运行环境。"
    "进度沟通只报告新增信息：环境、任务范围和验证条件在首次确认后保持不变，仅在发生变化时更新；"
    "工具调用前如需说明，只描述紧接着的操作，更远的后续计划要明确标注；"
    "工具返回后基于新增结果继续，说明中包含新发现、已完成事项或具体阻塞，"
    "不重复已交代过的背景与工作协议；"
    "没有值得告知的新信息时，可以直接调用工具；"
    "区分计划执行、已经执行和已经验证，表述与实际工具结果一致。"
)
_LEGACY_CLEANUP_V3 = "创建完成任务所需的文件，并在交付前清理临时产物。"
_CLEANUP_V4 = (
    "创建完成任务所需的文件；仅清理由本任务产生且确认不属于交付物的临时产物，"
    "保留任务要求的文件、服务和运行环境。"
)
DIRECT_CODING_PROTOCOL_V3 = DIRECT_CODING_PROTOCOL.replace(_CLEANUP_V4, _LEGACY_CLEANUP_V3)


class PromptAssemblyError(ValueError):
    """A prompt projection cannot be admitted without changing its authority."""

    code = "prompt_assembly"


@dataclass(frozen=True, slots=True)
class DirectCodingProfile:
    """Stable built-in profile; user-editable role text is deliberately separate."""

    profile_id: str = DIRECT_CODING_PROFILE_ID
    version: str = DIRECT_CODING_PROFILE_VERSION
    coding_protocol: str = DIRECT_CODING_PROTOCOL

    @property
    def digest(self) -> str:
        return sha256_digest(
            canonical_json_bytes(
                {
                    "profile_id": self.profile_id,
                    "version": self.version,
                    "coding_protocol": self.coding_protocol,
                    "authority": "fixed-boundary-first; lower-layers-cannot-authorize",
                }
            )
        )


class DirectCodingPromptAssembler:
    """Compose the fixed Direct boundary and bounded lower-authority prompt layers."""

    def __init__(
        self,
        workspace_root: Path | None = None,
        *,
        profile: DirectCodingProfile | None = None,
        role_prompt: str | None = None,
        filenames: Sequence[str] = DEFAULT_PROJECT_INSTRUCTION_FILENAMES,
        resolver: ProjectInstructionResolver | None = None,
    ) -> None:
        self.profile = profile or DirectCodingProfile()
        self.role_prompt = _validate_role_prompt(role_prompt)
        self._provenance = object()
        if resolver is not None and workspace_root is not None:
            raise ValueError("prompt assembler accepts either resolver or workspace_root")
        self.resolver = resolver or (
            ProjectInstructionResolver(
                workspace_root,
                filenames=filenames,
            )
            if workspace_root is not None
            else None
        )

    @property
    def profile_id(self) -> str:
        return self.profile.profile_id

    @property
    def version(self) -> str:
        return self.profile.version

    @property
    def digest(self) -> str:
        return self.profile.digest

    def prepare_for_task(self) -> PromptProjection:
        resolution = (
            self.resolver.resolve() if self.resolver is not None else self._empty_resolution()
        )
        return self._projection(resolution)

    def rehydrate(self, evidence: PromptProfileEvidence) -> PromptProjection:
        """Reload current startup context without blocking on stale instruction files."""
        self._verify_profile_evidence(evidence)
        if self.resolver is None:
            if evidence.project_instruction_sources:
                raise ProjectInstructionError("workspace_unavailable")
            resolution = ProjectInstructionResolution(
                sources=(),
                resolver_version=evidence.project_instruction_resolver_version or "v1",
                selection_digest=evidence.project_instruction_selection_digest or _empty_digest(),
            )
        else:
            resolution = self.resolver.rehydrate(evidence)
        return self._projection(resolution, evidence=evidence)

    def evidence_for(
        self, resolution: ProjectInstructionResolution | None = None
    ) -> PromptProfileEvidence:
        resolution = resolution or self._empty_resolution()
        return PromptProfileEvidence(
            profile_id=self.profile.profile_id,
            profile_version=self.profile.version,
            profile_digest=self.profile.digest,
            role_prompt_digest=(sha256_digest(self.role_prompt) if self.role_prompt else None),
            project_instruction_resolver_version=(
                resolution.resolver_version if self.resolver is not None else None
            ),
            project_instruction_sources=resolution.references,
            project_instruction_selection_digest=(
                resolution.selection_digest if self.resolver is not None else None
            ),
        )

    def system_messages(
        self,
        *,
        tools: tuple[ToolDefinition, ...] = (),
        projection: PromptProjection | None = None,
    ) -> tuple[SystemMessage, ...]:
        """Return complete system-layer order, with the boundary always first."""
        projection = projection or self.prepare_for_task()
        self._verify_projection(projection)
        # Import lazily to keep the prompt layer independent of ContextBuilder import order.
        from morrow.application.context import render_system_boundary

        messages = [
            SystemMessage(content=render_system_boundary(tools)),
            SystemMessage(content=self._protocol_for(projection.evidence)),
        ]
        if projection.role_prompt:
            messages.append(
                SystemMessage(content="以下是可选角色工作指导：\n" + projection.role_prompt)
            )
        for item in projection.project_instructions:
            messages.append(SystemMessage(content=render_project_instruction_block((item,))))
        return tuple(messages)

    def verify_projection(self, projection: PromptProjection) -> None:
        """Public verification seam used by fresh admission and recovery."""
        self._verify_projection(projection)

    def _protocol_for(self, evidence: PromptProfileEvidence) -> str:
        if (
            evidence.profile_version == "v3"
            and self.profile.version == DIRECT_CODING_PROFILE_VERSION
        ):
            return DIRECT_CODING_PROTOCOL_V3
        return self.profile.coding_protocol

    def _projection(
        self,
        resolution: ProjectInstructionResolution,
        *,
        evidence: PromptProfileEvidence | None = None,
    ) -> PromptProjection:
        return PromptProjection(
            evidence=evidence or self.evidence_for(resolution),
            role_prompt=self.role_prompt,
            project_instructions=resolution.sources,
            provenance=self._provenance,
        )

    def _empty_resolution(self) -> ProjectInstructionResolution:
        return ProjectInstructionResolution(
            sources=(),
            resolver_version="v1",
            selection_digest=_empty_digest(),
        )

    def _verify_projection(self, projection: PromptProjection) -> None:
        if not isinstance(projection, PromptProjection):
            raise PromptAssemblyError("prompt projection has an invalid type")
        if projection.provenance is not self._provenance:
            raise PromptAssemblyError("prompt projection provenance is not current")
        self._verify_profile_evidence(projection.evidence)
        if projection.role_prompt != self.role_prompt:
            raise PromptAssemblyError("role prompt projection is not current")
        refs = projection.project_instruction_sources
        if tuple(item.reference for item in projection.project_instructions) != refs:
            raise PromptAssemblyError("prompt projection sources are inconsistent")
        if (
            projection.evidence.project_instruction_resolver_version is not None
            and project_source_selection_digest(list(refs))
            != projection.evidence.project_instruction_selection_digest
        ):
            raise PromptAssemblyError("project instruction selection evidence drifted")
        if self.resolver is None and refs:
            raise PromptAssemblyError("project instruction workspace is unavailable")
        total_bytes = 0
        previous_order: tuple[int, str] | None = None
        for item in projection.project_instructions:
            reference = item.reference
            if not isinstance(item.text, str):
                raise PromptAssemblyError("project instruction content evidence drifted")
            raw = item.text.encode("utf-8")
            if (
                len(raw) != reference.byte_count
                or sha256_digest(raw) != reference.content_sha256
                or project_source_reference_digest(reference) != reference.digest
                or unicodedata.normalize("NFC", item.text) != item.text
                or _has_prompt_control_text(item.text)
            ):
                raise PromptAssemblyError("project instruction content evidence drifted")
            order = (
                0 if reference.scope == "." else len(reference.scope.split("/")),
                reference.path,
            )
            if previous_order is not None and order < previous_order:
                raise PromptAssemblyError("project instruction scope order drifted")
            previous_order = order
            total_bytes += reference.byte_count
            if self.resolver is not None:
                expected_path = (
                    reference.source_id
                    if reference.scope == "."
                    else f"{reference.scope}/{reference.source_id}"
                )
                if (
                    reference.version != PROJECT_INSTRUCTION_SOURCE_VERSION
                    or reference.source_id not in self.resolver.filenames
                    or reference.path != expected_path
                    or reference.byte_count > self.resolver.max_file_bytes
                ):
                    raise PromptAssemblyError("project instruction source evidence drifted")
        max_total_bytes = self.resolver.max_total_bytes if self.resolver is not None else 64 * 1024
        if total_bytes > max_total_bytes:
            raise PromptAssemblyError("project instruction content exceeds its byte budget")
        if self.resolver is not None:
            if projection.evidence.project_instruction_resolver_version != self.resolver.version:
                raise PromptAssemblyError("project instruction resolver version drifted")
            if tuple(item.reference for item in projection.project_instructions) != tuple(
                projection.evidence.project_instruction_sources
            ):
                raise PromptAssemblyError("project instruction evidence drifted")
        elif (
            projection.evidence.project_instruction_resolver_version is not None
            or projection.evidence.project_instruction_sources
            or projection.evidence.project_instruction_selection_digest is not None
        ):
            raise PromptAssemblyError("project instruction resolver evidence is unexpected")

    def _verify_profile_evidence(self, evidence: PromptProfileEvidence) -> None:
        if not isinstance(evidence, PromptProfileEvidence):
            raise PromptAssemblyError("prompt profile evidence has an invalid type")
        if evidence.profile_id != self.profile.profile_id:
            raise PromptAssemblyError("prompt profile ID drifted")
        legacy = (
            self.profile.profile_id == DIRECT_CODING_PROFILE_ID
            and self.profile.version == DIRECT_CODING_PROFILE_VERSION
            and self.profile.coding_protocol == DIRECT_CODING_PROTOCOL
            and evidence.profile_version == "v3"
            and evidence.profile_digest
            == DirectCodingProfile(version="v3", coding_protocol=DIRECT_CODING_PROTOCOL_V3).digest
        )
        if evidence.profile_version != self.profile.version and not legacy:
            raise PromptAssemblyError("prompt profile version drifted")
        if evidence.profile_digest != self.profile.digest and not legacy:
            raise PromptAssemblyError("prompt profile digest drifted")
        expected_role_digest = sha256_digest(self.role_prompt) if self.role_prompt else None
        if evidence.role_prompt_digest != expected_role_digest:
            raise PromptAssemblyError("role prompt evidence drifted")
        expected_resolver_version = self.resolver.version if self.resolver is not None else None
        if evidence.project_instruction_resolver_version != expected_resolver_version:
            raise PromptAssemblyError("project instruction resolver evidence drifted")
        if self.resolver is None and evidence.project_instruction_sources:
            raise PromptAssemblyError("project instruction workspace is unavailable")


def _validate_role_prompt(value: str | None) -> str | None:
    if value is None:
        return None
    if not isinstance(value, str) or not value.strip():
        raise ValueError("role prompt must be a non-empty string")
    try:
        role_bytes = len(value.encode("utf-8"))
    except UnicodeEncodeError as exc:
        raise ValueError("role prompt must be valid UTF-8") from exc
    if role_bytes > DIRECT_CODING_ROLE_PROMPT_MAX_BYTES:
        raise ValueError("role prompt exceeds its byte budget")
    if unicodedata.normalize("NFC", value) != value:
        raise ValueError("role prompt must be NFC")
    if _has_prompt_control_text(value):
        raise ValueError("role prompt contains control text")
    return value


def _has_prompt_control_text(value: str) -> bool:
    return any(
        unicodedata.category(char) in {"Cc", "Cf"} and char not in {"\t", "\n", "\r"}
        for char in value
    )


def _empty_digest() -> str:
    return sha256_digest(canonical_json_bytes([]))


__all__ = [
    "DIRECT_CODING_PROFILE_ID",
    "DIRECT_CODING_PROFILE_VERSION",
    "DIRECT_CODING_PROTOCOL",
    "DirectCodingProfile",
    "DirectCodingPromptAssembler",
    "PromptAssemblyError",
]
