"""Recovery commands behind the operational application facade."""

from __future__ import annotations

from datetime import timedelta

from morrow.application.api_context import ApplicationCommandContext
from morrow.application.learning.memory_run_projection import build_run_context_projection
from morrow.core.application import (
    ApplicationCommandDisposition,
    ApplicationCommandReceipt,
    ApplicationCommandResult,
    ApplicationError,
    ApplicationErrorCode,
)
from morrow.core.domain import (
    AGENT_RUN_ID_PREFIX,
    DurableAgentRun,
    DurableSession,
    SessionHealth,
    SessionLifecycle,
    TaskOutcomeTrigger,
    TaskRunStatus,
    TurnSubmitDisposition,
)
from morrow.core.recovery import RecoveryReport, RecoveryReportStatus, RecoveryResolution
from morrow.core.store import StorageError, StorageErrorCode
from morrow.runtime.durable_log import DurableConversationWriter, restore_conversation_log


class RecoveryApplicationService:
    """Own Recovery command transactions without expanding the public facade."""

    def __init__(self, context: ApplicationCommandContext) -> None:
        self.context = context

    def resolve(
        self,
        report: RecoveryReport,
        *,
        command_id: str | None = None,
        resolution: RecoveryResolution,
        item_id: str | None = None,
        log=None,
        writer=None,
        close_all: bool = False,
    ) -> ApplicationCommandResult[RecoveryReport]:
        api = self.context
        if api.recovery is None or log is None:
            raise ApplicationError(
                ApplicationErrorCode.UNAVAILABLE, "recovery service is unavailable"
            )
        if report.workspace_id != api.workspace_id:
            raise ApplicationError(
                ApplicationErrorCode.CROSS_WORKSPACE, "recovery report is outside the workspace"
            )
        payload = {
            "report_id": report.report_id,
            "resolution": resolution.value,
            "item_id": item_id,
        }
        command_id, digest, replay = api._prepare("recovery_resolve", payload, command_id)
        if replay is not None:
            value = api._query(
                lambda: api.journal.get_report(api.workspace_id, replay.result_id or "")
            )
            if value is None:
                raise ApplicationError(
                    ApplicationErrorCode.NEEDS_RECOVERY, "recovery result is missing"
                )
            return ApplicationCommandResult(value, replay)
        if report.status is not RecoveryReportStatus.OPEN:
            raise ApplicationError(
                ApplicationErrorCode.INVALID,
                "Recovery report is already closed",
            )
        try:
            updated, recovery_receipt, planned = api.recovery.decide(
                report,
                command_id=command_id,
                resolution=resolution,
                item_id=item_id,
                log=log,
                now=api.clock(),
            )
            if recovery_receipt.kind == "conflict":
                raise ApplicationError(
                    ApplicationErrorCode.CONFLICT,
                    "recovery command ID was reused with a different request",
                )
            if recovery_receipt.kind == "replay":
                value = api._query(
                    lambda: api.journal.get_report(api.workspace_id, recovery_receipt.report_id)
                )
                if value is None:
                    raise ApplicationError(
                        ApplicationErrorCode.NEEDS_RECOVERY, "recovery result is missing"
                    )
                receipt = ApplicationCommandReceipt(
                    command_id=command_id,
                    workspace_id=api.workspace_id,
                    session_id=value.session_id,
                    operation="recovery_resolve",
                    request_digest=digest,
                    disposition=ApplicationCommandDisposition.REPLAY,
                    result_kind="recovery",
                    result_id=value.report_id,
                )
                return ApplicationCommandResult(value, receipt)

            close_all = close_all or (resolution is RecoveryResolution.ABORT and item_id is None)
            session_row = api.journal.get_session(api.workspace_id, report.session_id)
            tracked_task_id = session_row.current_task_run_id if session_row is not None else None

            def work(txn):
                resumed_agent_run_ids: list[str] = []
                existing = api._replay_in_txn(txn, command_id, digest)
                if existing is not None:
                    value = txn.get_report(api.workspace_id, existing.result_id or "")
                    if value is None:
                        raise ApplicationError(
                            ApplicationErrorCode.NEEDS_RECOVERY,
                            "recovery result is missing",
                        )
                    return ApplicationCommandResult(value, existing), None
                current = txn.get_report(api.workspace_id, report.report_id)
                if current is None:
                    raise ApplicationError(
                        ApplicationErrorCode.NOT_FOUND,
                        "Recovery report is missing",
                    )
                if current.status is not RecoveryReportStatus.OPEN:
                    raise ApplicationError(
                        ApplicationErrorCode.INVALID,
                        "Recovery report is already closed",
                    )
                value = api.recovery.commit_decision(
                    updated,
                    recovery_receipt,
                    planned=planned,
                    log=log,
                    writer=writer,
                    close_all=close_all,
                    apply_log_projection=False,
                    finalize=lambda finalize_txn, saved: self._apply_lifecycle_in_txn(
                        finalize_txn,
                        report=report,
                        saved=saved,
                        resolution=resolution,
                        resumed_agent_run_id=resumed_agent_run_ids,
                    ),
                )
                event = api._event(
                    txn,
                    event_type="recovery.resolved",
                    aggregate_kind="recovery",
                    aggregate_id=value.report_id,
                    payload={"status": value.status.value, "resolution": resolution.value},
                )
                receipt = api._receipt(
                    txn,
                    command_id=command_id,
                    operation="recovery_resolve",
                    digest=digest,
                    session_id=value.session_id,
                    result_kind="recovery",
                    result_id=value.report_id,
                    event_cursor=event.cursor,
                )
                resumed_agent_run_id = resumed_agent_run_ids[0] if resumed_agent_run_ids else None
                return ApplicationCommandResult(value, receipt), resumed_agent_run_id

            try:
                result, resumed_agent_run_id = api._translate(lambda: api.journal.transact(work))
                if planned is not None:
                    log.apply_committed(planned)
                self._sync_persistence(result.value, resumed_agent_run_id)
                if tracked_task_id:
                    if resolution is RecoveryResolution.ABORT and close_all:
                        api.tasks.release_tracked(report.session_id, tracked_task_id, "cancel")
                    elif resolution is RecoveryResolution.RESUME:
                        api.tasks.release_tracked(report.session_id, tracked_task_id, "open")
                return result
            except ApplicationError:
                api._restore_log_projection(log, report.session_id)
                raise
        except ApplicationError:
            raise
        except StorageError as exc:
            api._restore_log_projection(log, report.session_id)
            if exc.code is StorageErrorCode.NEEDS_REPAIR:
                row = api.journal.get_session(api.workspace_id, report.session_id)
                if row is not None and row.health is not SessionHealth.QUARANTINED:
                    api.journal.save_session(
                        api.workspace_id,
                        row.model_copy(update={"health": SessionHealth.QUARANTINED}),
                    )
            raise api._translate_exception(exc) from exc
        except Exception as exc:
            api._restore_log_projection(log, report.session_id)
            raise api._translate_exception(exc) from exc

    def resolve_by_id(
        self,
        report_id: str,
        *,
        command_id: str | None = None,
        resolution: RecoveryResolution,
        item_id: str | None = None,
    ) -> ApplicationCommandResult[RecoveryReport]:
        """Resolve a standalone CLI request without exposing journal internals."""

        api = self.context
        report = api.get_recovery(report_id)
        if report is None:
            raise ApplicationError(ApplicationErrorCode.NOT_FOUND, "Recovery report is missing")
        log = restore_conversation_log(api.journal, api.workspace_id, report.session_id)
        writer = DurableConversationWriter(
            log,
            api.journal,
            workspace_id=api.workspace_id,
            session_id=report.session_id,
            id_source=api.id_source,
        )
        return self.resolve(
            report,
            command_id=command_id,
            resolution=resolution,
            item_id=item_id,
            log=log,
            writer=writer,
            close_all=resolution is RecoveryResolution.ABORT and item_id is None,
        )

    def _apply_lifecycle_in_txn(
        self,
        txn,
        *,
        report: RecoveryReport,
        saved: RecoveryReport,
        resolution: RecoveryResolution,
        resumed_agent_run_id: list[str],
    ) -> None:
        """Keep Session health, turn receipts, tasks, and resume runs atomic."""

        api = self.context
        session = txn.get_session(api.workspace_id, report.session_id)
        if session is None:
            raise StorageError(StorageErrorCode.NOT_FOUND, "operational session is missing")
        if (
            resolution is RecoveryResolution.RESUME
            and session.lifecycle is not SessionLifecycle.ACTIVE
        ):
            raise ApplicationError(
                ApplicationErrorCode.INVALID,
                "only an active Session can resume recovery",
            )

        health = SessionHealth.NEEDS_RECOVERY
        current_task_run_id = session.current_task_run_id
        if saved.status is RecoveryReportStatus.QUARANTINED:
            health = SessionHealth.QUARANTINED
        elif saved.status is RecoveryReportStatus.RESOLVED:
            health = SessionHealth.OK
            if resolution is RecoveryResolution.RESUME and saved.agent_run_id is not None:
                previous = txn.get_agent_run(api.workspace_id, saved.agent_run_id)
                if previous is None:
                    raise StorageError(StorageErrorCode.NOT_FOUND, "recovery AgentRun is missing")
                build_run_context_projection(
                    txn,
                    api.workspace_id,
                    previous.snapshot,
                    prompt_assembler=getattr(api.persistence, "prompt_assembler", None),
                )
                new_id = api.id_source.new_id(AGENT_RUN_ID_PREFIX)
                runtime_instance_id = getattr(api.persistence, "runtime_instance_id", None)
                snapshot = previous.snapshot
                if runtime_instance_id is not None:
                    snapshot = snapshot.model_copy(
                        update={"runtime_instance_id": runtime_instance_id}
                    )
                txn.create_agent_run(
                    api.workspace_id,
                    DurableAgentRun(
                        agent_run_id=new_id,
                        turn_id=previous.turn_id,
                        session_id=previous.session_id,
                        resume_of_agent_run_id=previous.agent_run_id,
                        snapshot=snapshot,
                        created_at=max(
                            api.journal.now(),
                            previous.created_at + timedelta(seconds=1),
                        ),
                    ),
                )
                resumed_agent_run_id.append(new_id)
            elif resolution is RecoveryResolution.ABORT:
                current_task_run_id = self._abort_task_in_txn(txn, session, turn_id=report.turn_id)
                self._close_receipt_in_txn(txn, report)

        txn.save_session(
            api.workspace_id,
            session.model_copy(
                update={"health": health, "current_task_run_id": current_task_run_id}
            ),
        )

    def _sync_persistence(self, report: RecoveryReport, resumed_agent_run_id: str | None) -> None:
        api = self.context
        persistence = api.persistence
        if persistence is None:
            return
        persistence.synchronize_recovery_projection(
            report,
            resumed_agent_run_id=resumed_agent_run_id,
        )

    def _abort_task_in_txn(
        self, txn, session: DurableSession, *, turn_id: str | None
    ) -> str | None:
        api = self.context
        task_id = session.current_task_run_id
        if task_id is None:
            return None
        task = txn.get_task_run(api.workspace_id, task_id)
        if task is None:
            raise StorageError(StorageErrorCode.NOT_FOUND, "recovery TaskRun is missing")
        if task.status in {TaskRunStatus.OPEN, TaskRunStatus.READY_FOR_ACCEPTANCE}:
            task = api.tasks._transition_in_txn(
                txn,
                task,
                TaskRunStatus.CANCELLED,
                reason="recovery_abort",
                turn_id=turn_id,
            )
            api.tasks._outcome_in_txn(
                txn,
                task,
                trigger=TaskOutcomeTrigger.TERMINAL_CLOSE,
                summary="TaskRun cancelled during recovery abort.",
            )
            return None
        return task_id if not task.status.is_terminal else None

    def _close_receipt_in_txn(self, txn, report: RecoveryReport) -> None:
        api = self.context
        if report.turn_id is None:
            return
        turn = txn.get_turn(api.workspace_id, report.turn_id)
        if turn is None:
            return
        receipt = txn.get_receipt(api.workspace_id, report.session_id, turn.client_message_id)
        if receipt is None or receipt.disposition is TurnSubmitDisposition.ACCEPTED_CLOSED:
            return
        txn.update_receipt(
            api.workspace_id,
            receipt.model_copy(update={"disposition": TurnSubmitDisposition.ACCEPTED_CLOSED}),
        )
