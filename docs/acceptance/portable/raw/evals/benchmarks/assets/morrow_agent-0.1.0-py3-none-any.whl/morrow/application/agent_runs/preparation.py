"""Per-AgentRun preparation: frozen spec plus a composed live runtime.

This is the only cross-domain composition boundary. ``prepare_new()`` reads the
current global configuration; ``rehydrate()`` rebuilds from stored AgentRun
evidence only and never consults the current active model. Skills and MCP plug
into this seam in later subplans.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from typing import Any

from morrow.adapters.registry import AdapterRegistry
from morrow.application.context import ContextBuilder
from morrow.application.mcp.runtime import PreparedMcpRun, register_mcp_tools
from morrow.core.agent_runs import (
    ExactModelCapabilities,
    PreparedAgentRunSpec,
    ProviderRuntimeSnapshot,
    exact_model_capabilities,
)
from morrow.core.domain import AgentRunSnapshot, canonical_json_bytes, sha256_digest
from morrow.core.models import (
    CredentialRef,
    GenerationOptions,
    ModelRef,
    ProviderConfig,
    ProviderModelConfig,
    RunPolicy,
    ToolDefinition,
)
from morrow.core.preference_documents import GlobalConfig
from morrow.runtime.policy import AgentPolicy, LongHorizonPolicySettings
from morrow.runtime.tools import ToolExecutor, ToolRegistry


class AgentRunPreparationError(RuntimeError):
    """A prepared run cannot be assembled from the available evidence."""


class ProviderUnavailableError(AgentRunPreparationError):
    """A frozen CredentialRef is not resolvable; there is no silent fallback."""


@dataclass(frozen=True, slots=True)
class PreparedAgentRunRuntime:
    """Live per-run objects; never stored in Pydantic models, SQLite or events."""

    spec: PreparedAgentRunSpec
    provider: Any
    model: ModelRef
    context_builder: ContextBuilder
    tool_executor: ToolExecutor | None
    run_policy: RunPolicy
    mcp_run: PreparedMcpRun | None = None
    agent_run_id: str | None = None

    def close(self) -> None:
        """Synchronous no-op cleanup hook; async consumers call :meth:`aclose`."""
        return None

    async def aclose(self) -> None:
        """Close lazy MCP resources without changing the ordinary loop shape."""
        if self.mcp_run is not None:
            await self.mcp_run.pool.close()


def tool_schema_digest(tools: tuple[ToolDefinition, ...]) -> str:
    payload = [tool.model_dump(mode="json") for tool in tools]
    return sha256_digest(canonical_json_bytes(payload))


def run_policy_digest(run_policy: RunPolicy) -> str:
    return sha256_digest(canonical_json_bytes(run_policy.model_dump(mode="json")))


def build_prepared_spec(
    *,
    provider_config: ProviderConfig,
    model: ModelRef,
    exact_capabilities: ExactModelCapabilities,
    config_revision: int,
    run_policy: RunPolicy,
    tools: tuple[ToolDefinition, ...],
    mcp_run_snapshot_ids: tuple[str, ...] = (),
    prompt_assembler=None,
    generation: GenerationOptions | None = None,
    settings_sources=None,
    permission_preset=None,
) -> PreparedAgentRunSpec:
    """Freeze the sanitized evidence one AgentRun will be rebuilt from."""
    api_model_id = provider_config.models[model.model_id].api_model_id
    provider_runtime = ProviderRuntimeSnapshot(
        provider_id=model.provider_id,
        adapter_id=provider_config.adapter,
        model=model,
        api_model_id=api_model_id,
        endpoint=provider_config.base_url or None,
        credential_ref=provider_config.credential_ref,
        capabilities=exact_capabilities,
        config_revision=config_revision,
        generation=generation or GenerationOptions(),
        generation_digest=sha256_digest(
            canonical_json_bytes((generation or GenerationOptions()).model_dump(mode="json"))
        ),
        settings_sources=settings_sources or {},
        permission_preset=permission_preset,
        config_digest=sha256_digest(canonical_json_bytes(provider_config.model_dump(mode="json"))),
    )
    prompt_values = {}
    if prompt_assembler is not None:
        evidence = prompt_assembler.evidence_for()
        prompt_values = {
            "prompt_profile_id": evidence.profile_id,
            "prompt_profile_version": evidence.profile_version,
            "prompt_profile_digest": evidence.profile_digest,
            "role_prompt_digest": evidence.role_prompt_digest,
            "project_instruction_resolver_version": evidence.project_instruction_resolver_version,
            "project_instruction_sources": evidence.project_instruction_sources,
            "project_instruction_selection_digest": evidence.project_instruction_selection_digest,
        }
    return PreparedAgentRunSpec(
        provider_runtime=provider_runtime,
        run_policy=run_policy,
        run_policy_digest=run_policy_digest(run_policy),
        tool_schema_digest=tool_schema_digest(tools),
        tool_count=len(tools),
        mcp_run_snapshot_ids=mcp_run_snapshot_ids,
        **prompt_values,
    )


class AgentRunPreparationService:
    """Compose one Provider/Model/RunPolicy/ToolSet per AgentRun."""

    def __init__(
        self,
        *,
        global_store,
        attachment_resolver=None,
        registry: AdapterRegistry,
        agent_policy: AgentPolicy,
        credential_resolver: Callable[[str, CredentialRef | None], str | None],
        frozen_credential_resolver: Callable[[str, CredentialRef | None], str | None] | None = None,
        estimate_request_chars,
        make_estimate_request_tokens=None,
        tool_factory: Callable[[RunPolicy], ToolExecutor | None],
        injected: PreparedAgentRunRuntime | None = None,
        workspace_id: str | None = None,
        mcp_factory: Callable[[str, RunPolicy], PreparedMcpRun | None] | None = None,
        mcp_rehydrate_factory: Callable[[AgentRunSnapshot, str], PreparedMcpRun | None]
        | None = None,
        prompt_assembler=None,
        long_horizon_settings: LongHorizonPolicySettings | None = None,
        permission_configurator=None,
    ) -> None:
        self.global_store = global_store
        self.attachment_resolver = attachment_resolver
        self.registry = registry
        self.agent_policy = agent_policy
        self.credential_resolver = credential_resolver
        self.frozen_credential_resolver = frozen_credential_resolver or credential_resolver
        self.estimate_request_chars = estimate_request_chars
        self.make_estimate_request_tokens = make_estimate_request_tokens
        self.tool_factory = tool_factory
        self.injected = injected
        self.workspace_id = workspace_id
        self.mcp_factory = mcp_factory
        self.mcp_rehydrate_factory = mcp_rehydrate_factory
        self.prompt_assembler = prompt_assembler
        self.long_horizon_settings = long_horizon_settings
        self.permission_configurator = permission_configurator

    def prepare_new(
        self,
        *,
        agent_run_id: str | None = None,
        model: ModelRef | None = None,
        prompt_assembler=None,
        tool_transform=None,
        generation: GenerationOptions | None = None,
        settings_sources=None,
        permission_preset=None,
    ) -> PreparedAgentRunRuntime:
        """Prepare the next new AgentRun from the current configuration.

        Reads the active model and its ProviderConfig once per run. The
        credential value is resolved here and never frozen into evidence.
        """
        loaded = self.global_store.load()
        config: GlobalConfig | None = loaded.value
        if config is None or (model is None and config.active_model is None):
            if (
                self.injected is not None
                and model is None
                and prompt_assembler is None
                and tool_transform is None
            ):
                return self.injected
            raise ValueError("尚未配置 active_model")
        model = model or config.active_model
        prompt_assembler = prompt_assembler or self.prompt_assembler
        provider_config = config.providers.get(model.provider_id)
        if provider_config is None:
            raise ValueError(f"未知 Provider: {model.provider_id}")
        if model.model_id not in provider_config.models:
            raise ValueError(f"模型不属于 Provider: {model.model_id}")
        credential = self.credential_resolver(model.provider_id, provider_config.credential_ref)
        if not credential:
            raise ValueError("Provider 凭据不可用")
        capabilities = self.registry.capabilities(provider_config.adapter)
        model_config = provider_config.models[model.model_id]
        exact = exact_model_capabilities(
            provider_config.adapter,
            capabilities,
            model,
            model_config.capabilities,
        )
        generation = generation or GenerationOptions()
        if (
            generation.reasoning_effort is not None
            and generation.reasoning_effort not in exact.reasoning_efforts
        ):
            raise AgentRunPreparationError(
                "Selected reasoning option is unavailable for this model"
            )
        run_policy = self.agent_policy.resolve(
            model,
            tool_protocol=exact.tool_protocol,
            multiple_tool_calls=exact.multiple_tool_calls,
            context_window_tokens=exact.context_window_tokens,
            max_output_tokens=exact.max_output_tokens,
            settings=self.long_horizon_settings,
        )
        provider = self.registry.create(provider_config, credential)
        context_builder = ContextBuilder(
            run_policy=run_policy,
            estimate_request_chars=self.estimate_request_chars,
            estimate_request_tokens=self._estimate_request_tokens(model),
            attachment_resolver=self.attachment_resolver,
            input_types=exact.input_types,
            prompt_assembler=prompt_assembler,
        )
        if self.permission_configurator is not None:
            self.permission_configurator(permission_preset, credential)
        tool_executor = self.tool_factory(run_policy)
        mcp_run = None
        if self.mcp_factory is not None and agent_run_id is not None:
            if self.workspace_id is None:
                raise AgentRunPreparationError("MCP preparation workspace is unavailable")
            try:
                mcp_run = self.mcp_factory(agent_run_id, run_policy)
            except AgentRunPreparationError:
                raise
            except Exception as exc:
                raise AgentRunPreparationError("MCP preparation failed") from exc
            tool_executor = self._merge_mcp_tools(tool_executor, mcp_run, agent_run_id=agent_run_id)
        if tool_transform is not None:
            tool_executor = tool_transform(tool_executor)
        tools = tool_executor.definitions if tool_executor is not None else ()
        spec = build_prepared_spec(
            provider_config=provider_config,
            model=model,
            exact_capabilities=exact,
            config_revision=loaded.revision,
            generation=generation,
            settings_sources=settings_sources,
            permission_preset=permission_preset,
            run_policy=run_policy,
            tools=tools,
            mcp_run_snapshot_ids=mcp_run.snapshot_ids if mcp_run is not None else (),
            prompt_assembler=prompt_assembler,
        )
        return PreparedAgentRunRuntime(
            spec=spec,
            provider=provider,
            model=model,
            context_builder=context_builder,
            tool_executor=tool_executor,
            run_policy=run_policy,
            mcp_run=mcp_run,
            agent_run_id=agent_run_id,
        )

    def rehydrate(
        self,
        snapshot: AgentRunSnapshot,
        *,
        agent_run_id: str | None = None,
        prompt_assembler=None,
        tool_transform=None,
    ) -> PreparedAgentRunRuntime:
        """Rebuild a runtime from stored AgentRun evidence only.

        An unresolvable frozen CredentialRef makes the run unavailable instead of falling back.
        """
        if snapshot.definition_ref is not None and (
            prompt_assembler is None or tool_transform is None
        ):
            raise AgentRunPreparationError(
                "Agent definition recovery requires its published factory"
            )
        frozen = snapshot.provider_runtime
        if frozen is None or snapshot.run_policy is None:
            raise AgentRunPreparationError("AgentRun frozen evidence is incomplete")
        if run_policy_digest(snapshot.run_policy) != snapshot.run_policy_digest:
            raise AgentRunPreparationError("AgentRun run-policy evidence is inconsistent")
        if frozen.generation_digest is not None and frozen.generation_digest != sha256_digest(
            canonical_json_bytes(frozen.generation.model_dump(mode="json"))
        ):
            raise AgentRunPreparationError("Frozen generation options are inconsistent")
        if frozen.generation.reasoning_effort is not None and (
            frozen.generation_digest is None
            or frozen.generation.reasoning_effort not in frozen.capabilities.reasoning_efforts
            or frozen.generation.reasoning_effort
            not in self.registry.capabilities(frozen.adapter_id).reasoning_efforts
        ):
            raise AgentRunPreparationError("Frozen generation mapping is unavailable")
        credential = self.frozen_credential_resolver(frozen.provider_id, frozen.credential_ref)
        if not credential:
            raise ProviderUnavailableError(
                f"frozen credential for provider {frozen.provider_id} is unavailable"
            )
        provider_config = ProviderConfig(
            adapter=frozen.adapter_id,
            base_url=frozen.endpoint or "",
            credential_ref=frozen.credential_ref,
            models={frozen.model.model_id: ProviderModelConfig(api_model_id=frozen.api_model_id)},
        )
        provider = self.registry.create(provider_config, credential)
        context_builder = ContextBuilder(
            run_policy=snapshot.run_policy,
            estimate_request_chars=self.estimate_request_chars,
            estimate_request_tokens=self._estimate_request_tokens(frozen.model),
            attachment_resolver=self.attachment_resolver,
            input_types=frozen.capabilities.input_types,
            prompt_assembler=prompt_assembler or self.prompt_assembler,
        )
        if self.permission_configurator is not None:
            self.permission_configurator(frozen.permission_preset, credential)
        tool_executor = self.tool_factory(snapshot.run_policy)
        mcp_run = None
        if snapshot.mcp_run_snapshot_ids:
            if self.mcp_rehydrate_factory is None:
                raise AgentRunPreparationError("AgentRun MCP evidence cannot be rehydrated")
            if agent_run_id is None:
                raise AgentRunPreparationError("AgentRun MCP subject is unavailable")
            try:
                mcp_run = self.mcp_rehydrate_factory(snapshot, agent_run_id)
            except AgentRunPreparationError:
                raise
            except Exception as exc:
                raise AgentRunPreparationError("MCP rehydration failed") from exc
            if mcp_run is None or mcp_run.snapshot_ids != snapshot.mcp_run_snapshot_ids:
                raise AgentRunPreparationError("AgentRun MCP snapshot evidence is inconsistent")
            tool_executor = self._merge_mcp_tools(tool_executor, mcp_run, agent_run_id=agent_run_id)
        if tool_transform is not None:
            tool_executor = tool_transform(tool_executor)
        tools = tool_executor.definitions if tool_executor is not None else ()
        if snapshot.tool_schema_digest != tool_schema_digest(tools):
            raise AgentRunPreparationError("AgentRun tool schema drifted from frozen evidence")
        spec = PreparedAgentRunSpec(
            definition_ref=snapshot.definition_ref,
            max_agent_generation_requests=snapshot.max_agent_generation_requests,
            conversation_session_id=snapshot.conversation_session_id,
            provider_runtime=frozen,
            run_policy=snapshot.run_policy,
            run_policy_digest=snapshot.run_policy_digest,
            tool_schema_digest=snapshot.tool_schema_digest,
            tool_count=len(tools),
            skill_selection_ids=snapshot.skill_selection_ids,
            skill_context_ids=snapshot.skill_context_ids,
            skill_selection_digest=snapshot.skill_selection_digest,
            skill_context_digest=snapshot.skill_context_digest,
            mcp_run_snapshot_ids=snapshot.mcp_run_snapshot_ids,
            prompt_profile_id=snapshot.prompt_profile_id,
            prompt_profile_version=snapshot.prompt_profile_version,
            prompt_profile_digest=snapshot.prompt_profile_digest,
            role_prompt_digest=snapshot.role_prompt_digest,
            project_instruction_resolver_version=snapshot.project_instruction_resolver_version,
            project_instruction_sources=snapshot.project_instruction_sources,
            project_instruction_selection_digest=snapshot.project_instruction_selection_digest,
        )
        return PreparedAgentRunRuntime(
            spec=spec,
            provider=provider,
            model=frozen.model,
            context_builder=context_builder,
            tool_executor=tool_executor,
            run_policy=snapshot.run_policy,
            mcp_run=mcp_run,
            agent_run_id=agent_run_id,
        )

    def _estimate_request_tokens(self, model: ModelRef):
        if self.make_estimate_request_tokens is None:
            return None
        return self.make_estimate_request_tokens(model)

    def _merge_mcp_tools(
        self,
        tool_executor: ToolExecutor | None,
        mcp_run: PreparedMcpRun | None,
        *,
        agent_run_id: str,
    ) -> ToolExecutor | None:
        if mcp_run is None:
            return tool_executor
        if tool_executor is None or self.workspace_id is None:
            raise AgentRunPreparationError("MCP tools require an ordinary function-tool runtime")
        registry = ToolRegistry()
        for registered in tool_executor.tool_set.tools.values():
            registry.register(registered)
        register_mcp_tools(
            registry,
            mcp_run,
            capability_policy=tool_executor.capability_policy,
            workspace_id=self.workspace_id,
            agent_run_id=agent_run_id,
        )
        return ToolExecutor(
            registry.snapshot(),
            tool_executor.run_policy,
            approval_port=tool_executor.approval_port,
            capability_policy=tool_executor.capability_policy,
            expected_process_isolation=tool_executor.expected_process_isolation,
        )
