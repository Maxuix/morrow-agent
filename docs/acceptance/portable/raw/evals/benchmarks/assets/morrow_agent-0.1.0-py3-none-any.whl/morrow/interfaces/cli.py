"""Typer entry point and local provider/model commands."""

from __future__ import annotations

import asyncio
import getpass
import json
import sys
import warnings
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Literal

import typer
from prompt_toolkit import PromptSession

from morrow.adapters.credentials.keyring import CredentialAccessError, environment_credential
from morrow.adapters.local.sandbox import default_sandbox_backend
from morrow.adapters.registry import DEFAULT_PROVIDER_PRESET, PRESETS
from morrow.adapters.state.journal import SqliteOperationalJournal
from morrow.adapters.state.operational import OperationalStore
from morrow.adapters.state.preference_yaml import PreferenceYamlStore
from morrow.application.backup import BackupBundleError
from morrow.application.doctor import OperationalDoctor
from morrow.application.orchestrator import DispatchResult
from morrow.application.preferences.inbox import PreferenceInboxError
from morrow.application.preferences.queries import PreferenceQueries
from morrow.application.preferences.tool import (
    ManagePreferenceOperation,
    ManagePreferencesArguments,
    PreferenceManagementService,
)
from morrow.application.preferences.writer import PreferenceWriter
from morrow.bootstrap import (
    build_application,
    build_operational_api,
    build_operational_services,
    build_session_application,
)
from morrow.core.application import ApplicationError, ApplicationErrorCode
from morrow.core.capabilities import PermissionPreset, PermissionProfile
from morrow.core.learning import LearningReviewStatus
from morrow.core.models import (
    AgentEvent,
    GenerationOptions,
    ModelErrorCode,
    ModelProviderError,
    ToolApprovalDecision,
    provider_error_message,
)
from morrow.core.permissions import (
    UNCONFINED_HOST_WARNING,
    UNCONFINED_HOST_WARNING_DIGEST,
    CapabilityName,
)
from morrow.core.recovery import RecoveryResolution
from morrow.core.store import StorageError, StorageErrorCode, StoreOpenMode
from morrow.interfaces.approval_cli import approval_app
from morrow.interfaces.attach_cli import register as _register_attach
from morrow.interfaces.gui_cli import register as _register_gui
from morrow.interfaces.headless_diagnostics import HeadlessDiagnostics
from morrow.interfaces.learning_cli import learning_app, memory_app
from morrow.interfaces.management_cli import management_app
from morrow.interfaces.mcp_cli import mcp_app
from morrow.interfaces.preferences_cli import preference_inbox_app
from morrow.interfaces.serve_cli import register as _register_serve
from morrow.interfaces.skills_cli import skill_app
from morrow.interfaces.terminal import Terminal, TerminalApprovalPort, run_repl
from morrow.interfaces.workflow_cli import agent_app, workflow_app
from morrow.runtime.durable_log import restore_conversation_log
from morrow.runtime.tools import ToolExecutionError
from morrow.services.workspace import WorkspaceError, WorkspaceWriterLock

app = typer.Typer(help="Morrow（承序）工作空间终端 Agent。")
provider_app = typer.Typer(help="Provider 管理。")
model_app = typer.Typer(help="模型查看。")
workspace_app = typer.Typer(help="工作空间管理。")
session_app = typer.Typer(help="Session 生命周期与历史。")
task_app = typer.Typer(help="TaskRun 操作。")
artifact_app = typer.Typer(help="Artifact 查看与保留。")
recovery_app = typer.Typer(help="恢复报告与决策。")
grant_app = typer.Typer(help="Foreground AgentRun 的手动权限授予与撤销。")
state_app = typer.Typer(help="Operational Store 诊断、事件与备份。")
agent_run_app = typer.Typer(help="AgentRun 观测查询。")
preferences_app = typer.Typer(help="Generic Preference 查询与直接生命周期管理。")
app.add_typer(skill_app, name="skill")
app.add_typer(management_app, name="manage")
app.add_typer(provider_app, name="provider")
app.add_typer(model_app, name="model")
app.add_typer(workspace_app, name="workspace")
app.add_typer(session_app, name="session")
app.add_typer(task_app, name="task")
app.add_typer(artifact_app, name="artifact")
app.add_typer(recovery_app, name="recovery")
app.add_typer(approval_app, name="approval")
app.add_typer(grant_app, name="grant")
app.add_typer(state_app, name="state")
app.add_typer(agent_run_app, name="agent-run")
app.add_typer(preferences_app, name="preferences")
preferences_app.add_typer(preference_inbox_app, name="inbox")
app.add_typer(learning_app, name="learning")
app.add_typer(memory_app, name="memory")
app.add_typer(mcp_app, name="mcp")
app.add_typer(agent_app, name="agent")
app.add_typer(workflow_app, name="workflow")
_register_serve(app)
_register_attach(app)
_register_gui(app)


def _secret(provider_id: str = DEFAULT_PROVIDER_PRESET) -> str:
    configured = environment_credential(provider_id)
    if configured:
        return configured
    recovery_message = (
        "无法安全读取凭据；请在交互终端中重试，或通过对应 Provider 的环境变量提供凭据。"
    )
    if sys.stdin is None or not sys.stdin.isatty():
        raise CredentialAccessError("secure_input_unavailable", recovery_message)
    try:
        with warnings.catch_warnings():
            # Abort before getpass falls back to reading with echo enabled.
            warnings.simplefilter("error", getpass.GetPassWarning)
            return getpass.getpass("API Key（输入不回显）：")
    except (getpass.GetPassWarning, EOFError, OSError):
        raise CredentialAccessError("secure_input_unavailable", recovery_message) from None


def _preset_option_help() -> str:
    listed = "、".join(PRESETS)
    return f"可用预设：{listed}。完整列表见 provider presets。"


def _echo_credential_error(exc: CredentialAccessError) -> None:
    typer.echo(exc.message, err=True)


def _echo_provider_failure(prefix: str, code: ModelErrorCode) -> None:
    typer.echo(f"{prefix}（{code.value}）：{provider_error_message(code)}", err=True)


@app.callback(invoke_without_command=True)
def root(
    ctx: typer.Context,
    dir: Path = typer.Option(Path("."), "--dir", exists=True, file_okay=False),
    state_root: Path | None = typer.Option(None, "--state-root", hidden=True),
    permission_mode: PermissionPreset = typer.Option(
        PermissionPreset.MANUAL,
        "--permission-mode",
        "--mode",
        help="权限预设：manual、auto-safe、auto-sandboxed 或 full-access-manual。",
    ),
    session_id: str | None = typer.Option(
        None, "--session-id", help="恢复指定 Session；不提供时创建新的前台 Session。"
    ),
) -> None:
    if ctx.invoked_subcommand:
        return
    if permission_mode is PermissionPreset.AUTO_SANDBOXED:
        capability = default_sandbox_backend().probe()
        if not capability.supported:
            typer.echo(
                f"Auto Sandboxed 不可用（{capability.reason}）；不会启动交互 Agent，也不会回退到 Host 执行。",
                err=True,
            )
            raise typer.Exit(code=2)
    application = build_application(state_root=state_root)
    global_state = application.global_store.load()
    if global_state.status.value != "ok":
        typer.echo(
            f"全局状态不可安全加载（{global_state.status.value}），已阻止写入；请先恢复或升级。",
            err=True,
        )
        raise typer.Exit(code=2)
    resolution = application.workspace_service.resolve(dir)
    if resolution.status == "candidate":
        candidate = resolution.candidate
        typer.echo(f"发现新工作空间：{candidate.display_name} ({candidate.path})")
        if not typer.confirm("确认登记此工作空间？"):
            raise typer.Exit(code=2)
        identity = application.workspace_service.confirm(resolution)
    else:
        identity = resolution.identity
    try:
        with WorkspaceWriterLock(application.data_root, identity.workspace_id):
            code = _run_workspace(
                application,
                identity=identity,
                permission_profile=PermissionProfile.from_preset(permission_mode),
                resume_session_id=session_id,
            )
    except WorkspaceError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(code=2) from exc
    except CredentialAccessError as exc:
        _echo_credential_error(exc)
        raise typer.Exit(code=2) from None
    raise typer.Exit(code=code)


class HeadlessApprovalPort:
    """Fail-closed approval adapter for the non-interactive one-shot command."""

    async def request(self, _request) -> ToolApprovalDecision:
        return ToolApprovalDecision(approved=False)


def _headless_dump(value):
    if value is None:
        return None
    if hasattr(value, "model_dump"):
        return value.model_dump(mode="json")
    if isinstance(value, dict):
        return {str(key): _headless_dump(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_headless_dump(item) for item in value]
    return value


def _headless_echo(kind: str, **payload) -> None:
    record = {"schema_version": 1, "kind": kind, **payload}
    typer.echo(
        json.dumps(
            record,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
            allow_nan=False,
        )
    )


@dataclass(frozen=True)
class _HeadlessStreamResult:
    terminal_event: AgentEvent | None = None
    dispatch: DispatchResult | None = None
    started_turn_id: str | None = None
    started_session_id: str | None = None
    failed: bool = False
    cancelled: bool = False


def _safe_stop_reason(value) -> str | None:
    if not isinstance(value, str) or not value or len(value) > 64:
        return None
    if any(character.isspace() for character in value):
        return None
    if not value.replace("_", "").isalnum():
        return None
    return value


async def _headless_stream(
    session_app,
    prompt: str,
    *,
    reasoning_effort: str | None = None,
    run_timeout_seconds: float | None = None,
    diagnostics: HeadlessDiagnostics | None = None,
) -> _HeadlessStreamResult:
    if run_timeout_seconds is not None:
        session_app.orchestrator.run_timeout_seconds = run_timeout_seconds
    if reasoning_effort is not None:
        prepare_options = session_app.orchestrator.prepare_options

        def prepare_with_reasoning(key):
            options = dict(prepare_options(key)) if prepare_options is not None else {}
            generation = GenerationOptions.model_validate(options.get("generation") or {})
            options["generation"] = GenerationOptions.model_validate(
                {**generation.model_dump(), "reasoning_effort": reasoning_effort}
            )
            return options

        session_app.orchestrator.prepare_options = prepare_with_reasoning
    terminal_event = None
    dispatch = None
    started_turn_id = None
    started_session_id = None
    try:
        async for item in session_app.orchestrator.stream(prompt):
            if isinstance(item, AgentEvent):
                _headless_echo("agent_event", event=_headless_dump(item))
                if diagnostics is not None:
                    try:
                        diagnostics.record_event(item)
                    except Exception as exc:
                        typer.echo(f"headless diagnostics stopped: {type(exc).__name__}", err=True)
                        diagnostics = None
                if item.type == "turn.started":
                    started_turn_id = item.turn_id
                    started_session_id = item.session_id
                if item.type == "turn.completed":
                    terminal_event = item
            elif isinstance(item, DispatchResult):
                dispatch = item
    except asyncio.CancelledError:
        if diagnostics is not None:
            try:
                diagnostics.snapshot()
            except Exception:
                pass
        return _HeadlessStreamResult(
            terminal_event=terminal_event,
            dispatch=dispatch,
            started_turn_id=started_turn_id,
            started_session_id=started_session_id,
            failed=terminal_event is None,
            cancelled=True,
        )
    except Exception as exc:
        if diagnostics is not None:
            try:
                diagnostics.record_error(exc, "headless_stream")
                diagnostics.snapshot()
            except Exception:
                pass
        return _HeadlessStreamResult(
            terminal_event=terminal_event,
            dispatch=dispatch,
            started_turn_id=started_turn_id,
            started_session_id=started_session_id,
            # A committed Turn can still be followed by failed dispatch or
            # outcome finalization. Its metrics remain valid, but the headless
            # invocation must not report success for the whole operation.
            failed=True,
            cancelled=False,
        )
    return _HeadlessStreamResult(
        terminal_event=terminal_event,
        dispatch=dispatch,
        started_turn_id=started_turn_id,
        started_session_id=started_session_id,
    )


def _headless_ids(session_app, terminal_event):
    if terminal_event is None:
        # Slash commands, preflight failures and stream failures do not admit a
        # new AgentRun. Never attribute their terminal record to a previous one.
        return None, None, None, None
    session = getattr(session_app, "session", None)
    persistence = getattr(session_app, "persistence", None)
    committer = getattr(session, "committer", None)
    session_id = getattr(session, "session_id", None)
    agent_run_id = getattr(persistence, "current_agent_run_id", None) or getattr(
        committer, "current_agent_run_id", None
    )
    task_run_id = getattr(persistence, "current_task_run_id", None) or getattr(
        committer, "current_task_run_id", None
    )
    turn_id = getattr(persistence, "current_turn_id", None) or getattr(
        committer, "current_turn_id", None
    )
    if terminal_event is not None:
        session_id = session_id or terminal_event.session_id
        turn_id = turn_id or terminal_event.turn_id
    return session_id, task_run_id, agent_run_id, turn_id


def _headless_terminal_record(
    session_app,
    terminal_event,
    dispatch: DispatchResult | None,
    *,
    stream_failed: bool = False,
    cancelled: bool = False,
    started_turn_id: str | None = None,
    started_session_id: str | None = None,
) -> bool:
    # A stream that never started a turn must not inherit the previous run.
    if terminal_event is None and started_turn_id is None:
        session_id = task_run_id = agent_run_id = turn_id = None
    elif terminal_event is not None:
        session_id, task_run_id, agent_run_id, turn_id = _headless_ids(session_app, terminal_event)
    else:
        session_id = started_session_id
        turn_id = started_turn_id
        task_run_id = None
        persistence = getattr(session_app, "persistence", None)
        committer = getattr(getattr(session_app, "session", None), "committer", None)
        candidate = getattr(persistence, "current_agent_run_id", None) or getattr(
            committer, "current_agent_run_id", None
        )
        agent_run_id = candidate if isinstance(candidate, str) else None
    observation = None
    observation_failed = False
    api = getattr(session_app, "api", None)
    if agent_run_id is not None and api is not None:
        getter = getattr(api, "get_agent_run_observation", None)
        if callable(getter):
            try:
                observation = getter(agent_run_id)
            except Exception:
                observation_failed = True
                observation = None
    observation_payload = _headless_dump(observation) or {}
    expected_turn_id = started_turn_id or (terminal_event.turn_id if terminal_event else None)
    expected_session_id = started_session_id or (
        terminal_event.session_id if terminal_event else None
    )
    unconfirmed_run = expected_turn_id is not None and (
        observation_payload.get("turn_id") != expected_turn_id
        or observation_payload.get("session_id") != expected_session_id
        or observation_payload.get("agent_run_id") != agent_run_id
    )
    if unconfirmed_run:
        # A stale or unavailable observation cannot confirm an AgentRun ID.
        observation_payload = {}
        agent_run_id = None
        task_run_id = None
        session_id = expected_session_id
        turn_id = expected_turn_id
    elif observation_payload:
        session_id = observation_payload.get("session_id", session_id)
        task_run_id = observation_payload.get("task_run_id", task_run_id)
        agent_run_id = observation_payload.get("agent_run_id", agent_run_id)
        turn_id = observation_payload.get("turn_id", turn_id)
    metrics = observation_payload.get("terminal_metrics")
    if not isinstance(metrics, dict):
        metrics = None
    requests = observation_payload.get("requests")
    if isinstance(requests, list):
        request_count = len(requests)
    elif isinstance(metrics, dict) and isinstance(metrics.get("model_attempts"), int):
        request_count = metrics.get("model_attempts")
    else:
        request_count = None
    finish_reason = terminal_event.payload.get("finish_reason") if terminal_event else None
    stop_reason = None
    if isinstance(metrics, dict):
        stop_reason = _safe_stop_reason(metrics.get("stop_code")) or _safe_stop_reason(
            metrics.get("finish_reason")
        )
    if stop_reason is None and terminal_event is not None:
        stop_reason = _safe_stop_reason(
            terminal_event.payload.get("stop_code")
        ) or _safe_stop_reason(finish_reason)
    if stop_reason is None and (stream_failed or cancelled):
        stop_reason = "cancelled" if cancelled else "error"
    if terminal_event is not None:
        if cancelled:
            stop_reason = "post_turn_cancelled"
        elif stream_failed:
            stop_reason = "post_turn_error"
    dispatch_degraded = bool(getattr(dispatch, "degraded", False))
    successful = (
        not stream_failed
        and not cancelled
        and not observation_failed
        and not dispatch_degraded
        and terminal_event is not None
        and finish_reason == "stop"
        and metrics is not None
        and metrics.get("finish_reason") == "stop"
    )
    fingerprint = None
    if agent_run_id is not None and api is not None and not unconfirmed_run:
        getter = getattr(api, "get_agent_run_fingerprint", None)
        if callable(getter):
            try:
                fingerprint = getter(agent_run_id)
            except Exception:
                pass
    _headless_echo(
        "run.completed",
        agent_run_id=agent_run_id,
        session_id=session_id,
        task_run_id=task_run_id,
        turn_id=turn_id,
        metrics=metrics,
        request_count=request_count,
        stop_reason=stop_reason,
        fingerprint=fingerprint,
    )
    return successful


@app.command("run")
def run_headless(
    prompt_arg: str | None = typer.Argument(None, metavar="[PROMPT]"),
    prompt_option: str | None = typer.Option(None, "--prompt"),
    workspace: Path | None = typer.Option(None, "--workspace"),
    state_root: Path | None = typer.Option(None, "--state-root"),
    permission_mode: PermissionPreset = typer.Option(
        PermissionPreset.MANUAL,
        "--permission-mode",
        "--mode",
        help="权限预设；需要审批的工具在 headless 模式下默认拒绝。",
    ),
    resume_session_id: str | None = typer.Option(
        None, "--resume-session-id", "--session-id", help="恢复指定 Session。"
    ),
    reasoning_effort: str | None = typer.Option(
        None,
        "--reasoning-effort",
        help="模型思考强度：none、minimal、low、medium、high、xhigh 或 max。",
    ),
    run_timeout_seconds: float | None = typer.Option(
        None, "--run-timeout-seconds", help="宿主提供的本次运行总时限（秒）。"
    ),
    diagnostic_log: Path | None = typer.Option(
        None, "--diagnostic-log", help="将脱敏运行诊断持续写入 JSONL 文件。"
    ),
) -> None:
    """Run one ordinary prompt and emit versioned JSONL records only."""

    if workspace is None:
        typer.echo("headless run requires an explicit --workspace", err=True)
        raise typer.Exit(code=2)
    if prompt_arg is not None and prompt_option is not None:
        typer.echo("provide the prompt either as an argument or with --prompt", err=True)
        raise typer.Exit(code=2)
    prompt = prompt_option if prompt_option is not None else prompt_arg
    if prompt is None or not prompt.strip():
        typer.echo("headless run requires an explicit prompt", err=True)
        raise typer.Exit(code=2)
    if reasoning_effort is not None:
        try:
            GenerationOptions(reasoning_effort=reasoning_effort)
        except ValueError:
            typer.echo("invalid --reasoning-effort", err=True)
            raise typer.Exit(code=2) from None
    if run_timeout_seconds is not None:
        from morrow.runtime.deadline import RunDeadline

        try:
            RunDeadline.from_seconds(run_timeout_seconds)
        except ValueError:
            typer.echo("invalid --run-timeout-seconds", err=True)
            raise typer.Exit(code=2) from None
    if permission_mode is PermissionPreset.AUTO_SANDBOXED:
        capability = default_sandbox_backend().probe()
        if not capability.supported:
            typer.echo(
                f"Auto Sandboxed 不可用（{capability.reason}）；不会回退到 Host 执行。", err=True
            )
            raise typer.Exit(code=2)

    try:
        application = build_application(state_root=state_root)
        resolution = application.workspace_service.resolve(workspace)
        if resolution.status != "existing" or resolution.identity is None:
            typer.echo(
                "headless run requires an already registered workspace; interactive confirmation is disabled",
                err=True,
            )
            raise typer.Exit(code=2)
        identity = resolution.identity
        with WorkspaceWriterLock(application.data_root, identity.workspace_id):
            session_app = build_session_application(
                app=application,
                identity=identity,
                approval_port=HeadlessApprovalPort(),
                permission_profile=PermissionProfile.from_preset(permission_mode),
                resume_session_id=resume_session_id,
                headless=True,
            )
            try:
                diagnostics = (
                    HeadlessDiagnostics(diagnostic_log, session_app) if diagnostic_log else None
                )
            except OSError as exc:
                typer.echo(f"headless diagnostics unavailable: {type(exc).__name__}", err=True)
                diagnostics = None
            try:
                streamed = asyncio.run(
                    _headless_stream(
                        session_app,
                        prompt,
                        reasoning_effort=reasoning_effort,
                        run_timeout_seconds=run_timeout_seconds,
                        diagnostics=diagnostics,
                    )
                )
            except KeyboardInterrupt:
                streamed = _HeadlessStreamResult(failed=True, cancelled=True)
            except Exception as exc:
                if diagnostics is not None:
                    try:
                        diagnostics.record_error(exc, "headless_runner")
                    except Exception:
                        pass
                streamed = _HeadlessStreamResult(failed=True)
            if streamed.failed or streamed.cancelled:
                if diagnostics is not None:
                    try:
                        diagnostics.record_headless_failure("stream_incomplete")
                    except OSError:
                        pass
                typer.echo("headless run ended before a normal stop", err=True)
            try:
                success = _headless_terminal_record(
                    session_app,
                    streamed.terminal_event,
                    streamed.dispatch,
                    stream_failed=streamed.failed,
                    cancelled=streamed.cancelled,
                    started_turn_id=streamed.started_turn_id,
                    started_session_id=streamed.started_session_id,
                )
            except Exception as exc:
                if diagnostics is not None:
                    try:
                        diagnostics.record_error(exc, "headless_terminal")
                        diagnostics.record_headless_failure("terminal_observation_unavailable")
                    except Exception:
                        pass
                typer.echo("headless run observation is unavailable", err=True)
                success = False
            finally:
                if diagnostics is not None:
                    try:
                        diagnostics.close()
                    except OSError:
                        pass
    except typer.Exit:
        raise
    except (CredentialAccessError, StorageError, WorkspaceError, ApplicationError, ValueError):
        typer.echo("headless run could not start safely", err=True)
        raise typer.Exit(code=2) from None
    except Exception:
        typer.echo("headless run could not start safely", err=True)
        raise typer.Exit(code=2) from None
    raise typer.Exit(code=0 if success else 2)


def _run_workspace(
    application,
    identity,
    *,
    permission_profile: PermissionProfile,
    resume_session_id: str | None = None,
) -> int:
    if not application.provider_service.current_model():
        typer.echo("尚未配置模型，开始 Provider 引导。")
        secret = _secret()
        try:
            application.provider_service.add(DEFAULT_PROVIDER_PRESET, secret)
        except CredentialAccessError as exc:
            _echo_credential_error(exc)
            raise typer.Exit(code=2) from None
        except Exception as exc:
            typer.echo(f"Provider 配置失败：{type(exc).__name__}", err=True)
            raise typer.Exit(code=2) from exc
    inspection = application.workspace_state_service.inspect(identity.workspace_id)
    profile_result = inspection.profile
    read_only_workspace = inspection.read_only
    if read_only_workspace:
        typer.echo("Profile 无法安全加载；本次仅进入只读对话。")
    elif inspection.preferences_read_only:
        typer.echo("工作空间 Preferences 无法安全加载；本次将该层隔离为空且禁止覆盖。")
    if not read_only_workspace and not profile_result.value:
        summary = typer.prompt("项目要达成什么？（可跳过）", default="", show_default=False)
        try:
            application.workspace_state_service.onboard(
                identity.workspace_id,
                display_name=identity.display_name,
                summary=summary,
            )
        except WorkspaceError as exc:
            typer.echo(str(exc), err=True)
            raise typer.Exit(code=2) from exc
    if resume_session_id is None:
        candidates = _resume_candidates(application, identity.workspace_id)
        if candidates:
            listed = ", ".join(candidates)
            typer.echo(
                f"检测到可恢复 Session：{listed}；如需继续，请使用 --session-id SESSION_ID。"
            )
    terminal = Terminal()
    prompt_session = PromptSession()
    approval_port = TerminalApprovalPort(terminal, prompt_session)
    try:
        session_app = build_session_application(
            application,
            identity,
            approval_port=approval_port,
            permission_profile=permission_profile,
            resume_session_id=resume_session_id,
        )
    except CredentialAccessError as exc:
        _echo_credential_error(exc)
        raise typer.Exit(code=2) from None
    except ValueError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(code=2) from None
    session_app.session.read_only = read_only_workspace
    return asyncio.run(
        run_repl(
            session_app.orchestrator,
            session=session_app.session,
            terminal=terminal,
            prompt_session=prompt_session,
            resume_current_turn=session_app.persistence.pending_resume,
            review_worker=session_app.review_worker,
        )
    )


def _resume_candidates(application, workspace_id: str) -> tuple[str, ...]:
    """Find resumable Sessions without making the default REPL choose for the user."""

    store = OperationalStore(application.data_root.root)
    try:
        handle = store.open(StoreOpenMode.READ_ONLY)
    except StorageError as exc:
        if exc.code is StorageErrorCode.NOT_FOUND:
            return ()
        return ()
    try:
        journal = SqliteOperationalJournal(handle)
        candidates: list[str] = []
        for session in journal.list_sessions(workspace_id):
            if session.health.value == "needs_recovery":
                candidates.append(session.session_id)
                continue
            active = restore_conversation_log(journal, workspace_id, session.session_id)
            executions = journal.list_session_executions(workspace_id, session.session_id)
            if active.has_active_turn or any(item.state.value != "closed" for item in executions):
                candidates.append(session.session_id)
        return tuple(candidates)
    except (RuntimeError, StorageError, ValueError):
        return ()
    finally:
        handle.close()


@provider_app.command("list")
def provider_list(
    state_root: Path | None = typer.Option(None, "--state-root", hidden=True),
) -> None:
    service = build_application(state_root=state_root).provider_service
    try:
        config = service.list()
    except ValueError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(code=2) from exc
    for provider_id, provider in config.providers.items():
        typer.echo(f"{provider_id}\t{provider.adapter}\t{provider.base_url}")


@provider_app.command("show")
def provider_show(
    provider_id: str, state_root: Path | None = typer.Option(None, "--state-root", hidden=True)
) -> None:
    service = build_application(state_root=state_root).provider_service
    try:
        provider = service.provider(provider_id)
    except ValueError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(code=2) from exc
    typer.echo(f"adapter: {provider.adapter}")
    typer.echo(f"base_url: {provider.base_url}")
    inspection = service.inspect_credential(provider_id)
    if inspection.available:
        typer.echo("credential: 可用")
    elif inspection.code == "missing":
        typer.echo("credential: 不可用")
    else:
        typer.echo(f"credential: 不可用（{inspection.code}）")
    typer.echo("models: " + ", ".join(provider.models))
    if provider.last_test:
        typer.echo(
            "last_test: "
            + ("ok" if provider.last_test.ok else provider.last_test.message or "failed")
        )
    if not inspection.available and inspection.code != "missing":
        typer.echo(inspection.message, err=True)
        raise typer.Exit(code=2)


@provider_app.command("presets")
def provider_presets() -> None:
    for preset_id, preset in PRESETS.items():
        typer.echo(f"{preset_id}\t{preset['provider_id']}/{preset['model_id']}")


@provider_app.command("add")
def provider_add(
    provider_id: str | None = typer.Argument(None),
    preset: str = typer.Option(DEFAULT_PROVIDER_PRESET, "--preset", help=_preset_option_help()),
    provider_name: str | None = typer.Option(None, "--name"),
    adapter: str | None = typer.Option(None, "--adapter"),
    base_url: str | None = typer.Option(None, "--base-url"),
    state_root: Path | None = typer.Option(None, "--state-root", hidden=True),
) -> None:
    application = build_application(state_root=state_root)
    service = application.provider_service
    provider_id = provider_name or provider_id
    if provider_id is not None or adapter is not None or base_url is not None:
        if not provider_id or not adapter or not base_url:
            typer.echo("Provider 添加需要 --name、--adapter 和 --base-url", err=True)
            raise typer.Exit(code=2)
        try:
            service.add_provider(
                provider_id,
                adapter_id=adapter,
                base_url=base_url,
                secret=_secret(provider_id),
            )
        except CredentialAccessError as exc:
            _echo_credential_error(exc)
            raise typer.Exit(code=2) from None
        except ValueError as exc:
            typer.echo(f"Provider 添加失败：{exc}", err=True)
            raise typer.Exit(code=2) from None
        typer.echo(f"已添加 Provider：{provider_id}")
        return
    try:
        model = service.add(preset, _secret())
    except CredentialAccessError as exc:
        _echo_credential_error(exc)
        raise typer.Exit(code=2) from None
    except ModelProviderError as exc:
        _echo_provider_failure("Provider 添加失败", exc.code)
        raise typer.Exit(code=2) from None
    except Exception as exc:
        typer.echo(f"Provider 添加失败：{type(exc).__name__}", err=True)
        raise typer.Exit(code=2) from exc
    current = service.current_model()
    typer.echo(f"已配置 {model}")
    if current == model:
        typer.echo(f"当前模型：{current}")
    else:
        typer.echo(f"当前模型未切换：{current}")


@provider_app.command("remove")
def provider_remove(
    provider_id: str,
    state_root: Path | None = typer.Option(None, "--state-root", hidden=True),
) -> None:
    try:
        build_application(state_root=state_root).provider_service.remove_provider(provider_id)
    except ValueError as exc:
        typer.echo(f"Provider 移除失败：{exc}", err=True)
        raise typer.Exit(code=2) from None
    typer.echo(f"已移除 Provider：{provider_id}")


@provider_app.command("test")
def provider_test(
    provider_id: str, state_root: Path | None = typer.Option(None, "--state-root", hidden=True)
) -> None:
    typer.echo("正在测试模型连接…")
    try:
        result = build_application(state_root=state_root).provider_service.test(provider_id)
    except CredentialAccessError as exc:
        _echo_credential_error(exc)
        raise typer.Exit(code=2) from None
    except ValueError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(code=2) from exc
    except ModelProviderError as exc:
        _echo_provider_failure("连接失败", exc.code)
        raise typer.Exit(code=2) from None
    except Exception as exc:
        typer.echo(f"连接失败：{type(exc).__name__}", err=True)
        raise typer.Exit(code=2) from exc
    if not result.ok:
        code = result.error_code or ModelErrorCode.INTERNAL
        _echo_provider_failure("连接失败", code)
        raise typer.Exit(code=2)
    typer.echo("连接成功")


@provider_app.command("configure")
def provider_configure(
    provider_id: str,
    base_url: str | None = typer.Option(None, "--base-url"),
    replace_credential: bool = typer.Option(False, "--replace-credential"),
    state_root: Path | None = typer.Option(None, "--state-root", hidden=True),
) -> None:
    application = build_application(state_root=state_root)
    try:
        secret = None
        if replace_credential or not application.provider_service.credential_available(provider_id):
            secret = _secret(provider_id)
        application.provider_service.configure(
            provider_id,
            secret=secret,
            base_url=base_url,
            replace_credential=replace_credential,
        )
    except CredentialAccessError as exc:
        _echo_credential_error(exc)
        raise typer.Exit(code=2) from None
    except ModelProviderError as exc:
        _echo_provider_failure("Provider 更新失败", exc.code)
        raise typer.Exit(code=2) from None
    except Exception as exc:
        typer.echo(f"Provider 更新失败：{type(exc).__name__}", err=True)
        raise typer.Exit(code=2) from exc
    typer.echo("Provider 已更新并通过连接测试")


@model_app.command("list")
def model_list(
    provider: str | None = typer.Option(None, "--provider"),
    state_root: Path | None = typer.Option(None, "--state-root", hidden=True),
) -> None:
    try:
        config = build_application(state_root=state_root).provider_service.list()
    except ValueError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(code=2) from exc
    for provider_id, value in config.providers.items():
        if provider and provider != provider_id:
            continue
        for model_id in value.models:
            typer.echo(f"{provider_id}/{model_id}")


def _split_model_target(target: str, model_id: str | None) -> tuple[str, str]:
    if model_id is not None:
        return target, model_id
    provider_id, separator, parsed_model_id = target.partition("/")
    if not separator or not provider_id or not parsed_model_id:
        raise ValueError("模型目标必须是 provider_id/model_id")
    return provider_id, parsed_model_id


@model_app.command("show")
def model_show(
    model_target: str,
    model_id: str | None = typer.Argument(None),
    state_root: Path | None = typer.Option(None, "--state-root", hidden=True),
) -> None:
    try:
        provider_id, model_id = _split_model_target(model_target, model_id)
    except ValueError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(code=2) from None
    try:
        service = build_application(state_root=state_root).provider_service
        provider = service.provider(provider_id)
        model = provider.models[model_id]
    except ValueError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(code=2) from None
    except KeyError:
        typer.echo(f"未知模型: {provider_id}/{model_id}", err=True)
        raise typer.Exit(code=2) from None
    typer.echo(f"provider: {provider_id}")
    typer.echo(f"model: {model_id}")
    typer.echo(f"api_model_id: {model.api_model_id}")
    if model.capabilities is not None:
        typer.echo("capabilities: " + json.dumps(model.capabilities.model_dump(mode="json")))


@model_app.command("add")
def model_add(
    provider_id: str | None = typer.Argument(None),
    model_id: str | None = typer.Argument(None),
    provider_option: str | None = typer.Option(None, "--provider"),
    model_option: str | None = typer.Option(None, "--model-id", "--model"),
    api_model_id: str | None = typer.Option(None, "--api-model-id"),
    state_root: Path | None = typer.Option(None, "--state-root", hidden=True),
) -> None:
    provider_id = provider_option or provider_id
    model_id = model_option or model_id
    if not provider_id or not model_id:
        typer.echo("模型添加需要 --provider 和 model_id", err=True)
        raise typer.Exit(code=2)
    try:
        model = build_application(state_root=state_root).provider_service.add_model(
            provider_id,
            model_id,
            api_model_id=api_model_id,
        )
    except ValueError as exc:
        typer.echo(f"模型添加失败：{exc}", err=True)
        raise typer.Exit(code=2) from None
    typer.echo(f"已添加模型：{model}")


@model_app.command("sync")
def model_sync(
    provider_id: str | None = typer.Argument(None),
    provider_option: str | None = typer.Option(None, "--provider"),
    state_root: Path | None = typer.Option(None, "--state-root", hidden=True),
) -> None:
    provider_id = provider_option or provider_id
    if not provider_id:
        typer.echo("模型同步需要 provider_id 或 --provider", err=True)
        raise typer.Exit(code=2)
    try:
        models = build_application(state_root=state_root).provider_service.sync_models(provider_id)
    except ValueError as exc:
        typer.echo(f"模型同步失败：{exc}", err=True)
        raise typer.Exit(code=2) from None
    for model in models:
        typer.echo(str(model))


@model_app.command("use")
def model_use(
    model_target: str,
    model_id: str | None = typer.Argument(None),
    state_root: Path | None = typer.Option(None, "--state-root", hidden=True),
) -> None:
    try:
        provider_id, model_id = _split_model_target(model_target, model_id)
        model = build_application(state_root=state_root).provider_service.use_model(
            provider_id, model_id
        )
    except ValueError as exc:
        typer.echo(f"模型切换失败：{exc}", err=True)
        raise typer.Exit(code=2) from None
    typer.echo(f"当前模型：{model}")


@model_app.command("remove")
def model_remove(
    model_target: str,
    model_id: str | None = typer.Argument(None),
    state_root: Path | None = typer.Option(None, "--state-root", hidden=True),
) -> None:
    try:
        provider_id, model_id = _split_model_target(model_target, model_id)
        build_application(state_root=state_root).provider_service.remove_model(
            provider_id, model_id
        )
    except ValueError as exc:
        typer.echo(f"模型移除失败：{exc}", err=True)
        raise typer.Exit(code=2) from None
    typer.echo(f"已移除模型：{provider_id}/{model_id}")


@model_app.command("current")
def model_current(
    state_root: Path | None = typer.Option(None, "--state-root", hidden=True),
) -> None:
    try:
        current = build_application(state_root=state_root).provider_service.current_model()
    except ValueError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(code=2) from exc
    typer.echo(str(current) if current else "未配置 active_model")


@workspace_app.command("relink")
def workspace_relink(
    workspace_id: str,
    dir: Path = typer.Option(..., "--dir", exists=True, file_okay=False),
    state_root: Path | None = typer.Option(None, "--state-root", hidden=True),
) -> None:
    application = build_application(state_root=state_root)
    typer.echo(f"将把 {workspace_id} 指向 {dir.resolve()}")
    if not typer.confirm("确认重连？"):
        raise typer.Exit(code=2)
    try:
        identity = application.workspace_service.relink(workspace_id, dir)
    except WorkspaceError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(code=2) from exc
    typer.echo(f"已重连：{identity.path}")


def _state_services(
    *,
    state_root: Path | None,
    workspace_id: str | None,
    directory: Path,
    write: bool,
    with_reviewer: bool = False,
):
    """Build the shared state boundary, optionally with the active no-tool Reviewer."""

    application = build_application(state_root=state_root)
    if workspace_id is None:
        resolution = application.workspace_service.resolve(directory)
        if resolution.status == "candidate":
            raise WorkspaceError("工作空间尚未登记；请先用主命令确认，或提供 --workspace-id。")
        workspace_id = resolution.identity.workspace_id
    learning_provider = learning_model = None
    if with_reviewer:
        learning_provider, learning_model = application.provider_service.build_active()
    store = OperationalStore(application.data_root.root)
    mode = StoreOpenMode.READ_WRITE if write else StoreOpenMode.READ_ONLY
    try:
        handle = store.open(mode)
    except StorageError as exc:
        if write and exc.code is StorageErrorCode.NOT_FOUND:
            handle = store.initialize()
        else:
            raise
    operational = build_operational_services(
        application,
        workspace_id,
        handle=handle,
        write=write,
    )
    preference_writer = PreferenceWriter(
        PreferenceYamlStore(application.data_root.root),
        operational.journal,
        workspace_id,
        id_source=application.id_source,
        clock=operational.journal.now,
    )
    api = build_operational_api(
        application,
        workspace_id,
        operational,
        preference_writer=preference_writer,
        learning_provider=learning_provider,
        learning_model=learning_model,
    )
    return (
        application,
        handle,
        api,
        operational.doctor,
        operational.backup,
    )


@agent_run_app.command("show")
def agent_run_show(
    agent_run_id: str,
    workspace_id: str | None = typer.Option(None, "--workspace-id", "--workspace"),
    directory: Path = typer.Option(Path("."), "--dir", exists=True, file_okay=False),
    as_json: bool = typer.Option(False, "--json"),
    state_root: Path | None = typer.Option(None, "--state-root", hidden=True),
) -> None:
    """Inspect safe AgentRun metrics and ordered model-request observations."""

    handle = None
    try:
        _application, handle, api, _doctor, _backup = _state_services(
            state_root=state_root,
            workspace_id=workspace_id,
            directory=directory,
            write=False,
        )
        observation = api.get_agent_run_observation(agent_run_id)
        if observation is None:
            typer.echo("AgentRun observation not found", err=True)
            raise typer.Exit(code=2)
        _emit_model(observation, as_json=as_json)
    except typer.Exit:
        raise
    except Exception:
        typer.echo("AgentRun observation is unavailable", err=True)
        raise typer.Exit(code=2) from None
    finally:
        _close_state(handle)


def _close_state(handle) -> None:
    if handle is not None:
        handle.close()


def _preference_service(
    *,
    state_root: Path | None,
    workspace_id: str | None,
    directory: Path,
    write: bool,
):
    application, handle, api, _doctor, _backup = _state_services(
        state_root=state_root,
        workspace_id=workspace_id,
        directory=directory,
        write=write,
    )
    yaml_store = PreferenceYamlStore(application.data_root.root)
    journal = SqliteOperationalJournal(handle)
    writer = PreferenceWriter(
        yaml_store,
        journal,
        api.workspace_id,
        id_source=application.id_source,
        clock=journal.now,
    )
    queries = PreferenceQueries(yaml_store, api.workspace_id)
    return application, handle, writer, queries, PreferenceManagementService(writer, queries)


def _emit_model(value, *, as_json: bool = False) -> None:
    payload = value.model_dump(mode="json") if hasattr(value, "model_dump") else value
    if as_json:
        typer.echo(json.dumps(payload, ensure_ascii=False, sort_keys=True))
        return
    if isinstance(payload, dict):
        for key, item in payload.items():
            if isinstance(item, (dict, list, tuple)):
                item = json.dumps(item, ensure_ascii=False, sort_keys=True)
            typer.echo(f"{key}: {item}")
    else:
        typer.echo(str(payload))


def _emit_learning_review_result(result) -> None:
    _emit_model(result)
    if result.review.status is not LearningReviewStatus.COMPLETED:
        raise typer.Exit(code=2)


def _emit_page(page, *, render, as_json: bool = False) -> None:
    if as_json:
        typer.echo(
            json.dumps(
                {
                    "items": [
                        item.model_dump(mode="json") if hasattr(item, "model_dump") else item
                        for item in page.items
                    ],
                    "next_cursor": page.next_cursor,
                },
                ensure_ascii=False,
                sort_keys=True,
            )
        )
        return
    for item in page.items:
        typer.echo(render(item))
    if page.next_cursor is not None:
        typer.echo(f"next_cursor: {page.next_cursor}")


@preferences_app.command("status")
def preferences_status(
    session_id: str | None = typer.Option(None, "--session-id"),
    workspace_id: str | None = typer.Option(None, "--workspace-id"),
    directory: Path = typer.Option(Path("."), "--dir", exists=True, file_okay=False),
    as_json: bool = typer.Option(False, "--json"),
    state_root: Path | None = typer.Option(None, "--state-root", hidden=True),
) -> None:
    handle = None
    try:
        _application, handle, api, _doctor, _backup = _state_services(
            state_root=state_root,
            workspace_id=workspace_id,
            directory=directory,
            write=False,
        )
        _emit_model(api.preference_context_status(session_id=session_id), as_json=as_json)
    except Exception as exc:
        _cli_error(exc)
        raise typer.Exit(code=2) from None
    finally:
        _close_state(handle)


@preferences_app.command("list")
def preferences_list(
    scope: Literal["global", "workspace"] = typer.Option("workspace", "--scope"),
    status: Literal["active", "disabled", "deleted"] | None = typer.Option(None, "--status"),
    include_deleted: bool = typer.Option(False, "--include-deleted"),
    workspace_id: str | None = typer.Option(None, "--workspace-id"),
    directory: Path = typer.Option(Path("."), "--dir", exists=True, file_okay=False),
    as_json: bool = typer.Option(False, "--json"),
    state_root: Path | None = typer.Option(None, "--state-root", hidden=True),
) -> None:
    handle = None
    try:
        _application, handle, _writer, queries, _service = _preference_service(
            state_root=state_root,
            workspace_id=workspace_id,
            directory=directory,
            write=False,
        )
        values = queries.list(scope, status=status, include_deleted=include_deleted)
        if as_json:
            typer.echo(
                json.dumps(
                    [entry.model_dump(mode="json") for entry in values],
                    ensure_ascii=False,
                    sort_keys=True,
                )
            )
        else:
            for entry in values:
                typer.echo(f"{entry.preference_id}\t{entry.status.value}\t{entry.statement}")
    except Exception as exc:
        _cli_error(exc)
        raise typer.Exit(code=2) from None
    finally:
        _close_state(handle)


@preferences_app.command("write")
def preferences_write(
    operation: Literal["add", "replace", "remove", "enable", "disable"],
    statement: str | None = typer.Option(None, "--statement"),
    preference_id: str | None = typer.Option(None, "--preference-id"),
    scope: Literal["global", "workspace"] = typer.Option("workspace", "--scope"),
    expected_revision: int | None = typer.Option(None, "--expected-revision", min=0),
    command_id: str | None = typer.Option(None, "--command-id"),
    workspace_id: str | None = typer.Option(None, "--workspace-id"),
    directory: Path = typer.Option(Path("."), "--dir", exists=True, file_okay=False),
    as_json: bool = typer.Option(False, "--json"),
    state_root: Path | None = typer.Option(None, "--state-root", hidden=True),
) -> None:
    _preference_write_command(
        operation=operation,
        statement=statement,
        preference_id=preference_id,
        scope=scope,
        expected_revision=expected_revision,
        command_id=command_id,
        workspace_id=workspace_id,
        directory=directory,
        as_json=as_json,
        state_root=state_root,
    )


@preferences_app.command("show")
def preferences_show(
    preference_id: str,
    scope: Literal["global", "workspace"] = typer.Option("workspace", "--scope"),
    include_deleted: bool = typer.Option(False, "--include-deleted"),
    workspace_id: str | None = typer.Option(None, "--workspace-id"),
    directory: Path = typer.Option(Path("."), "--dir", exists=True, file_okay=False),
    as_json: bool = typer.Option(False, "--json"),
    state_root: Path | None = typer.Option(None, "--state-root", hidden=True),
) -> None:
    handle = None
    try:
        _application, handle, _writer, queries, _service = _preference_service(
            state_root=state_root,
            workspace_id=workspace_id,
            directory=directory,
            write=False,
        )
        value = queries.get(scope, preference_id, include_deleted=include_deleted)
        if value is None:
            raise ValueError("Preference 不存在")
        _emit_model(value, as_json=as_json)
    except Exception as exc:
        _cli_error(exc)
        raise typer.Exit(code=2) from None
    finally:
        _close_state(handle)


def _preference_write_command(
    *,
    operation: Literal["add", "replace", "remove", "enable", "disable"],
    statement: str | None,
    preference_id: str | None,
    scope: Literal["global", "workspace"],
    expected_revision: int | None,
    command_id: str | None,
    workspace_id: str | None,
    directory: Path,
    as_json: bool,
    state_root: Path | None,
) -> None:
    handle = None
    try:
        _application, handle, _writer, _queries, service = _preference_service(
            state_root=state_root,
            workspace_id=workspace_id,
            directory=directory,
            write=True,
        )
        arguments = ManagePreferencesArguments(
            scope=scope,
            operations=(
                ManagePreferenceOperation(
                    operation=operation,
                    statement=statement,
                    preference_id=preference_id,
                ),
            ),
            expected_revision=expected_revision,
        )
        value = service.apply(arguments, command_id=command_id)
        if as_json:
            typer.echo(json.dumps(value, ensure_ascii=False, sort_keys=True))
        else:
            typer.echo(
                f"Preference 已{operation}：scope={value['scope']}；revision={value['revision']}。"
            )
    except ToolExecutionError as exc:
        typer.echo(f"preference_{exc.code.value}: {exc}", err=True)
        raise typer.Exit(code=2) from None
    except Exception as exc:
        _cli_error(exc)
        raise typer.Exit(code=2) from None
    finally:
        _close_state(handle)


@preferences_app.command("add")
def preferences_add(
    statement: str,
    scope: Literal["global", "workspace"] = typer.Option("workspace", "--scope"),
    expected_revision: int | None = typer.Option(None, "--expected-revision", min=0),
    command_id: str | None = typer.Option(None, "--command-id"),
    workspace_id: str | None = typer.Option(None, "--workspace-id"),
    directory: Path = typer.Option(Path("."), "--dir", exists=True, file_okay=False),
    as_json: bool = typer.Option(False, "--json"),
    state_root: Path | None = typer.Option(None, "--state-root", hidden=True),
) -> None:
    _preference_write_command(
        operation="add",
        statement=statement,
        preference_id=None,
        scope=scope,
        expected_revision=expected_revision,
        command_id=command_id,
        workspace_id=workspace_id,
        directory=directory,
        as_json=as_json,
        state_root=state_root,
    )


@preferences_app.command("replace")
def preferences_replace(
    preference_id: str,
    statement: str,
    scope: Literal["global", "workspace"] = typer.Option("workspace", "--scope"),
    expected_revision: int | None = typer.Option(None, "--expected-revision", min=0),
    command_id: str | None = typer.Option(None, "--command-id"),
    workspace_id: str | None = typer.Option(None, "--workspace-id"),
    directory: Path = typer.Option(Path("."), "--dir", exists=True, file_okay=False),
    as_json: bool = typer.Option(False, "--json"),
    state_root: Path | None = typer.Option(None, "--state-root", hidden=True),
) -> None:
    _preference_write_command(
        operation="replace",
        statement=statement,
        preference_id=preference_id,
        scope=scope,
        expected_revision=expected_revision,
        command_id=command_id,
        workspace_id=workspace_id,
        directory=directory,
        as_json=as_json,
        state_root=state_root,
    )


def _preference_lifecycle_command(
    operation: Literal["remove", "enable", "disable"],
    preference_id: str,
    scope: Literal["global", "workspace"],
    expected_revision: int | None,
    command_id: str | None,
    workspace_id: str | None,
    directory: Path,
    as_json: bool,
    state_root: Path | None,
) -> None:
    _preference_write_command(
        operation=operation,
        statement=None,
        preference_id=preference_id,
        scope=scope,
        expected_revision=expected_revision,
        command_id=command_id,
        workspace_id=workspace_id,
        directory=directory,
        as_json=as_json,
        state_root=state_root,
    )


@preferences_app.command("remove")
def preferences_remove(
    preference_id: str,
    scope: Literal["global", "workspace"] = typer.Option("workspace", "--scope"),
    expected_revision: int | None = typer.Option(None, "--expected-revision", min=0),
    command_id: str | None = typer.Option(None, "--command-id"),
    workspace_id: str | None = typer.Option(None, "--workspace-id"),
    directory: Path = typer.Option(Path("."), "--dir", exists=True, file_okay=False),
    as_json: bool = typer.Option(False, "--json"),
    state_root: Path | None = typer.Option(None, "--state-root", hidden=True),
) -> None:
    _preference_lifecycle_command(
        "remove",
        preference_id,
        scope,
        expected_revision,
        command_id,
        workspace_id,
        directory,
        as_json,
        state_root,
    )


@preferences_app.command("enable")
def preferences_enable(
    preference_id: str,
    scope: Literal["global", "workspace"] = typer.Option("workspace", "--scope"),
    expected_revision: int | None = typer.Option(None, "--expected-revision", min=0),
    command_id: str | None = typer.Option(None, "--command-id"),
    workspace_id: str | None = typer.Option(None, "--workspace-id"),
    directory: Path = typer.Option(Path("."), "--dir", exists=True, file_okay=False),
    as_json: bool = typer.Option(False, "--json"),
    state_root: Path | None = typer.Option(None, "--state-root", hidden=True),
) -> None:
    _preference_lifecycle_command(
        "enable",
        preference_id,
        scope,
        expected_revision,
        command_id,
        workspace_id,
        directory,
        as_json,
        state_root,
    )


@preferences_app.command("disable")
def preferences_disable(
    preference_id: str,
    scope: Literal["global", "workspace"] = typer.Option("workspace", "--scope"),
    expected_revision: int | None = typer.Option(None, "--expected-revision", min=0),
    command_id: str | None = typer.Option(None, "--command-id"),
    workspace_id: str | None = typer.Option(None, "--workspace-id"),
    directory: Path = typer.Option(Path("."), "--dir", exists=True, file_okay=False),
    as_json: bool = typer.Option(False, "--json"),
    state_root: Path | None = typer.Option(None, "--state-root", hidden=True),
) -> None:
    _preference_lifecycle_command(
        "disable",
        preference_id,
        scope,
        expected_revision,
        command_id,
        workspace_id,
        directory,
        as_json,
        state_root,
    )


def _cli_error(exc: Exception) -> None:
    if isinstance(exc, ApplicationError):
        typer.echo(f"{exc.code.value}: {exc.message}", err=True)
    elif isinstance(exc, PreferenceInboxError):
        typer.echo(f"preference_{exc.code}: {exc}", err=True)
    elif isinstance(exc, (WorkspaceError, StorageError, BackupBundleError, ValueError)):
        typer.echo(str(exc), err=True)
    else:
        typer.echo("application command failed", err=True)


@session_app.command("list")
def session_list(
    workspace_id: str | None = typer.Option(None, "--workspace-id"),
    directory: Path = typer.Option(Path("."), "--dir", exists=True, file_okay=False),
    cursor: str | None = typer.Option(None, "--cursor"),
    limit: int = typer.Option(50, "--limit", min=1, max=100),
    as_json: bool = typer.Option(False, "--json"),
    state_root: Path | None = typer.Option(None, "--state-root", hidden=True),
) -> None:
    handle = None
    try:
        _application, handle, api, _doctor, _backup = _state_services(
            state_root=state_root, workspace_id=workspace_id, directory=directory, write=False
        )
        page = api.list_sessions(cursor=cursor, limit=limit)
        _emit_page(
            page,
            as_json=as_json,
            render=lambda session: (
                f"{session.session_id}\t{session.lifecycle.value}\t{session.health.value}\t"
                f"position={session.conversation_position}"
            ),
        )
    except Exception as exc:
        _cli_error(exc)
        raise typer.Exit(code=2) from None
    finally:
        _close_state(handle)


@session_app.command("create")
def session_create(
    session_id: str | None = typer.Option(None, "--session-id"),
    command_id: str | None = typer.Option(None, "--command-id"),
    workspace_id: str | None = typer.Option(None, "--workspace-id"),
    directory: Path = typer.Option(Path("."), "--dir", exists=True, file_okay=False),
    state_root: Path | None = typer.Option(None, "--state-root", hidden=True),
) -> None:
    handle = None
    try:
        _application, handle, api, _doctor, _backup = _state_services(
            state_root=state_root, workspace_id=workspace_id, directory=directory, write=True
        )
        result = api.create_session(session_id=session_id, command_id=command_id)
        _emit_model(result.value)
    except Exception as exc:
        _cli_error(exc)
        raise typer.Exit(code=2) from None
    finally:
        _close_state(handle)


@session_app.command("status")
def session_status(
    session_id: str,
    workspace_id: str | None = typer.Option(None, "--workspace-id"),
    directory: Path = typer.Option(Path("."), "--dir", exists=True, file_okay=False),
    state_root: Path | None = typer.Option(None, "--state-root", hidden=True),
) -> None:
    handle = None
    try:
        _application, handle, api, _doctor, _backup = _state_services(
            state_root=state_root, workspace_id=workspace_id, directory=directory, write=False
        )
        value = api.get_session(session_id)
        if value is None:
            raise ApplicationError(ApplicationErrorCode.NOT_FOUND, "Session is missing")
        _emit_model(value)
    except Exception as exc:
        _cli_error(exc)
        raise typer.Exit(code=2) from None
    finally:
        _close_state(handle)


@session_app.command("resume")
def session_resume(
    session_id: str,
    workspace_id: str | None = typer.Option(None, "--workspace-id"),
    directory: Path = typer.Option(Path("."), "--dir", exists=True, file_okay=False),
    permission_mode: PermissionPreset = typer.Option(
        PermissionPreset.MANUAL,
        "--permission-mode",
        "--mode",
        help="权限预设：manual、auto-safe、auto-sandboxed 或 full-access-manual。",
    ),
    state_root: Path | None = typer.Option(None, "--state-root", hidden=True),
) -> None:
    try:
        application = build_application(state_root=state_root)
        global_state = application.global_store.load()
        if global_state.status.value != "ok":
            raise WorkspaceError(
                f"全局状态不可安全加载（{global_state.status.value}），已阻止恢复。"
            )
        resolution = application.workspace_service.resolve(directory)
        if resolution.status != "existing" or resolution.identity is None:
            raise WorkspaceError("工作空间尚未登记；请先用主命令确认工作空间。")
        identity = resolution.identity
        if workspace_id is not None and workspace_id != identity.workspace_id:
            raise WorkspaceError("--workspace-id 与 --dir 不属于同一工作空间。")
        with WorkspaceWriterLock(application.data_root, identity.workspace_id):
            code = _run_workspace(
                application,
                identity,
                permission_profile=PermissionProfile.from_preset(permission_mode),
                resume_session_id=session_id,
            )
    except (WorkspaceError, CredentialAccessError) as exc:
        if isinstance(exc, CredentialAccessError):
            _echo_credential_error(exc)
        else:
            typer.echo(str(exc), err=True)
        raise typer.Exit(code=2) from None
    except ValueError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(code=2) from None
    raise typer.Exit(code=code)


@session_app.command("archive")
def session_archive(
    session_id: str,
    command_id: str | None = typer.Option(None, "--command-id"),
    workspace_id: str | None = typer.Option(None, "--workspace-id"),
    directory: Path = typer.Option(Path("."), "--dir", exists=True, file_okay=False),
    state_root: Path | None = typer.Option(None, "--state-root", hidden=True),
) -> None:
    handle = None
    try:
        _application, handle, api, _doctor, _backup = _state_services(
            state_root=state_root, workspace_id=workspace_id, directory=directory, write=True
        )
        _emit_model(api.archive_session(session_id, command_id=command_id).value)
    except Exception as exc:
        _cli_error(exc)
        raise typer.Exit(code=2) from None
    finally:
        _close_state(handle)


@session_app.command("fork")
def session_fork(
    parent_session_id: str,
    checkpoint_id: str | None = typer.Option(None, "--checkpoint-id"),
    cut_position: int | None = typer.Option(None, "--cut-position", min=1),
    reason: str = typer.Option("context fork", "--reason"),
    command_id: str | None = typer.Option(None, "--command-id"),
    workspace_id: str | None = typer.Option(None, "--workspace-id"),
    directory: Path = typer.Option(Path("."), "--dir", exists=True, file_okay=False),
    state_root: Path | None = typer.Option(None, "--state-root", hidden=True),
) -> None:
    handle = None
    try:
        _application, handle, api, _doctor, _backup = _state_services(
            state_root=state_root, workspace_id=workspace_id, directory=directory, write=True
        )
        _emit_model(
            api.fork_session(
                parent_session_id,
                checkpoint_id=checkpoint_id,
                cut_position=cut_position,
                reason=reason,
                command_id=command_id,
            ).value
        )
    except Exception as exc:
        _cli_error(exc)
        raise typer.Exit(code=2) from None
    finally:
        _close_state(handle)


@task_app.command("show")
def task_show(
    task_run_id: str,
    workspace_id: str | None = typer.Option(None, "--workspace-id"),
    directory: Path = typer.Option(Path("."), "--dir", exists=True, file_okay=False),
    state_root: Path | None = typer.Option(None, "--state-root", hidden=True),
) -> None:
    handle = None
    try:
        _application, handle, api, _doctor, _backup = _state_services(
            state_root=state_root, workspace_id=workspace_id, directory=directory, write=False
        )
        task = api.get_task(task_run_id)
        if task is None:
            raise ApplicationError(ApplicationErrorCode.NOT_FOUND, "TaskRun is missing")
        _emit_model(task)
    except Exception as exc:
        _cli_error(exc)
        raise typer.Exit(code=2) from None
    finally:
        _close_state(handle)


@task_app.command("list")
def task_list(
    session_id: str,
    workspace_id: str | None = typer.Option(None, "--workspace-id"),
    cursor: str | None = typer.Option(None, "--cursor"),
    limit: int = typer.Option(50, "--limit", min=1, max=100),
    as_json: bool = typer.Option(False, "--json"),
    directory: Path = typer.Option(Path("."), "--dir", exists=True, file_okay=False),
    state_root: Path | None = typer.Option(None, "--state-root", hidden=True),
) -> None:
    handle = None
    try:
        _application, handle, api, _doctor, _backup = _state_services(
            state_root=state_root, workspace_id=workspace_id, directory=directory, write=False
        )
        page = api.list_tasks(session_id, cursor=cursor, limit=limit)
        _emit_page(
            page,
            as_json=as_json,
            render=lambda task: (
                f"{task.task_run_id}\t{task.status.value}\t{task.row_version}\t"
                f"attempt={task.attempt}"
            ),
        )
    except Exception as exc:
        _cli_error(exc)
        raise typer.Exit(code=2) from None
    finally:
        _close_state(handle)


def _task_command(
    command,
    task_run_id,
    command_id,
    workspace_id,
    directory,
    state_root,
    expected_row_version,
    *,
    show_learning_review: bool = False,
):
    handle = None
    try:
        _application, handle, api, _doctor, _backup = _state_services(
            state_root=state_root, workspace_id=workspace_id, directory=directory, write=True
        )
        result = command(api, task_run_id, command_id, expected_row_version)
        if show_learning_review:
            outcomes = api.list_outcomes(result.value.task_run_id)
            latest = outcomes[-1] if outcomes else None
            reviews = (
                api.list_learning_reviews(task_outcome_id=latest.outcome_id).items
                if latest is not None
                else ()
            )
            review = reviews[0] if reviews else None
            if review is not None and review.status.value == "pending":
                typer.echo(f"已排入 Learning Review：{review.review_id}")
        _emit_model(result.value)
    except Exception as exc:
        _cli_error(exc)
        raise typer.Exit(code=2) from None
    finally:
        _close_state(handle)


@task_app.command("new")
def task_new(
    session_id: str,
    command_id: str | None = typer.Option(None, "--command-id"),
    expected_row_version: int | None = typer.Option(None, "--expected-row-version", min=1),
    workspace_id: str | None = typer.Option(None, "--workspace-id"),
    directory: Path = typer.Option(Path("."), "--dir", exists=True, file_okay=False),
    state_root: Path | None = typer.Option(None, "--state-root", hidden=True),
) -> None:
    handle = None
    try:
        _application, handle, api, _doctor, _backup = _state_services(
            state_root=state_root, workspace_id=workspace_id, directory=directory, write=True
        )
        _emit_model(
            api.task_new(
                session_id, command_id=command_id, expected_row_version=expected_row_version
            ).value
        )
    except Exception as exc:
        _cli_error(exc)
        raise typer.Exit(code=2) from None
    finally:
        _close_state(handle)


@task_app.command("accept")
def task_accept(
    task_run_id: str,
    command_id: str | None = typer.Option(None, "--command-id"),
    expected_row_version: int | None = typer.Option(None, "--expected-row-version", min=1),
    workspace_id: str | None = typer.Option(None, "--workspace-id"),
    directory: Path = typer.Option(Path("."), "--dir", exists=True, file_okay=False),
    state_root: Path | None = typer.Option(None, "--state-root", hidden=True),
) -> None:
    _task_command(
        lambda api, task, cmd, ver: api.task_accept(task, command_id=cmd, expected_row_version=ver),
        task_run_id,
        command_id,
        workspace_id,
        directory,
        state_root,
        expected_row_version,
        show_learning_review=True,
    )


@task_app.command("cancel")
def task_cancel(
    task_run_id: str,
    command_id: str | None = typer.Option(None, "--command-id"),
    expected_row_version: int | None = typer.Option(None, "--expected-row-version", min=1),
    workspace_id: str | None = typer.Option(None, "--workspace-id"),
    directory: Path = typer.Option(Path("."), "--dir", exists=True, file_okay=False),
    state_root: Path | None = typer.Option(None, "--state-root", hidden=True),
) -> None:
    _task_command(
        lambda api, task, cmd, ver: api.task_cancel(task, command_id=cmd, expected_row_version=ver),
        task_run_id,
        command_id,
        workspace_id,
        directory,
        state_root,
        expected_row_version,
    )


@task_app.command("resume")
def task_resume(
    task_run_id: str,
    command_id: str | None = typer.Option(None, "--command-id"),
    expected_row_version: int | None = typer.Option(None, "--expected-row-version", min=1),
    workspace_id: str | None = typer.Option(None, "--workspace-id"),
    directory: Path = typer.Option(Path("."), "--dir", exists=True, file_okay=False),
    state_root: Path | None = typer.Option(None, "--state-root", hidden=True),
) -> None:
    _task_command(
        lambda api, task, cmd, ver: api.task_resume(task, command_id=cmd, expected_row_version=ver),
        task_run_id,
        command_id,
        workspace_id,
        directory,
        state_root,
        expected_row_version,
    )


@learning_app.command("review")
def learning_review(
    review_id: str,
    expected_row_version: int | None = typer.Option(None, "--expected-row-version", min=1),
    workspace_id: str | None = typer.Option(None, "--workspace-id"),
    directory: Path = typer.Option(Path("."), "--dir", exists=True, file_okay=False),
    state_root: Path | None = typer.Option(None, "--state-root", hidden=True),
) -> None:
    """Run exactly one identified Review; no worker or scheduler is started."""

    handle = None
    try:
        _application, handle, api, _doctor, _backup = _state_services(
            state_root=state_root,
            workspace_id=workspace_id,
            directory=directory,
            write=True,
            with_reviewer=True,
        )
        _emit_learning_review_result(
            asyncio.run(
                api.run_learning_review(review_id, expected_row_version=expected_row_version)
            )
        )
    except Exception as exc:
        _cli_error(exc)
        raise typer.Exit(code=2) from None
    finally:
        _close_state(handle)


@learning_app.command("retry")
def learning_retry(
    review_id: str,
    expected_row_version: int | None = typer.Option(None, "--expected-row-version", min=1),
    workspace_id: str | None = typer.Option(None, "--workspace-id"),
    directory: Path = typer.Option(Path("."), "--dir", exists=True, file_okay=False),
    state_root: Path | None = typer.Option(None, "--state-root", hidden=True),
) -> None:
    """Retry one failed Review through the active no-tool Provider."""

    handle = None
    try:
        _application, handle, api, _doctor, _backup = _state_services(
            state_root=state_root,
            workspace_id=workspace_id,
            directory=directory,
            write=True,
            with_reviewer=True,
        )
        _emit_learning_review_result(
            asyncio.run(
                api.retry_learning_review(review_id, expected_row_version=expected_row_version)
            )
        )
    except Exception as exc:
        _cli_error(exc)
        raise typer.Exit(code=2) from None
    finally:
        _close_state(handle)


@learning_app.command("request")
def learning_request(
    outcome_id: str,
    expected_latest_version: int | None = typer.Option(None, "--expected-latest-version", min=0),
    command_id: str | None = typer.Option(None, "--command-id"),
    workspace_id: str | None = typer.Option(None, "--workspace-id"),
    directory: Path = typer.Option(Path("."), "--dir", exists=True, file_okay=False),
    state_root: Path | None = typer.Option(None, "--state-root", hidden=True),
) -> None:
    handle = None
    try:
        _application, handle, api, _doctor, _backup = _state_services(
            state_root=state_root, workspace_id=workspace_id, directory=directory, write=True
        )
        _emit_model(
            api.request_learning_review(
                outcome_id,
                expected_latest_version=expected_latest_version,
                command_id=command_id,
            ).value
        )
    except Exception as exc:
        _cli_error(exc)
        raise typer.Exit(code=2) from None
    finally:
        _close_state(handle)


@learning_app.command("list")
def learning_list(
    status: LearningReviewStatus | None = typer.Option(None, "--status"),
    outcome_id: str | None = typer.Option(None, "--outcome-id"),
    workspace_id: str | None = typer.Option(None, "--workspace-id"),
    directory: Path = typer.Option(Path("."), "--dir", exists=True, file_okay=False),
    state_root: Path | None = typer.Option(None, "--state-root", hidden=True),
) -> None:
    handle = None
    try:
        _application, handle, api, _doctor, _backup = _state_services(
            state_root=state_root, workspace_id=workspace_id, directory=directory, write=False
        )
        _emit_page(
            api.list_learning_reviews(status=status, task_outcome_id=outcome_id),
            render=lambda review: (
                f"{review.review_id}\t{review.status.value}\t"
                f"outcome={review.task_outcome_id}\tversion={review.review_version}"
            ),
        )
    except Exception as exc:
        _cli_error(exc)
        raise typer.Exit(code=2) from None
    finally:
        _close_state(handle)


@grant_app.command("list")
def grant_list(
    agent_run_id: str | None = typer.Option(None, "--agent-run-id"),
    workspace_id: str | None = typer.Option(None, "--workspace-id"),
    directory: Path = typer.Option(Path("."), "--dir", exists=True, file_okay=False),
    state_root: Path | None = typer.Option(None, "--state-root", hidden=True),
) -> None:
    handle = None
    try:
        _application, handle, api, _doctor, _backup = _state_services(
            state_root=state_root, workspace_id=workspace_id, directory=directory, write=False
        )
        for grant in api.list_grants(agent_run_id=agent_run_id).items:
            typer.echo(
                f"{grant.grant_id}\t{grant.agent_run_id}\t"
                f"{','.join(value.value for value in grant.capabilities)}\t"
                f"expires={grant.expires_at.isoformat()}\t"
                f"revoked={grant.revoked_at.isoformat() if grant.revoked_at else '-'}"
            )
    except Exception as exc:
        _cli_error(exc)
        raise typer.Exit(code=2) from None
    finally:
        _close_state(handle)


@grant_app.command("show")
def grant_show(
    grant_id: str,
    workspace_id: str | None = typer.Option(None, "--workspace-id"),
    directory: Path = typer.Option(Path("."), "--dir", exists=True, file_okay=False),
    state_root: Path | None = typer.Option(None, "--state-root", hidden=True),
) -> None:
    handle = None
    try:
        _application, handle, api, _doctor, _backup = _state_services(
            state_root=state_root, workspace_id=workspace_id, directory=directory, write=False
        )
        value = api.get_grant(grant_id)
        if value is None:
            raise ApplicationError(ApplicationErrorCode.NOT_FOUND, "CapabilityGrant is missing")
        _emit_model(value)
    except Exception as exc:
        _cli_error(exc)
        raise typer.Exit(code=2) from None
    finally:
        _close_state(handle)


@grant_app.command("create")
def grant_create(
    task_run_id: str,
    agent_run_id: str,
    reason: str = typer.Option(..., "--reason"),
    expires_minutes: int = typer.Option(15, "--expires-minutes", min=1, max=1_440),
    preview_digest: str | None = typer.Option(None, "--preview-digest"),
    command_id: str | None = typer.Option(None, "--command-id"),
    workspace_id: str | None = typer.Option(None, "--workspace-id"),
    directory: Path = typer.Option(Path("."), "--dir", exists=True, file_okay=False),
    state_root: Path | None = typer.Option(None, "--state-root", hidden=True),
) -> None:
    """Explicitly grant only unconfined_host_process to one foreground AgentRun."""

    typer.echo(UNCONFINED_HOST_WARNING, err=True)
    if not typer.confirm("确认授予该 AgentRun 一次手动 Host 执行权限？"):
        raise typer.Exit(code=2)
    handle = None
    try:
        if preview_digest is not None and preview_digest != UNCONFINED_HOST_WARNING_DIGEST:
            raise typer.BadParameter(
                "--preview-digest must match the canonical digest of the displayed Host warning"
            )
        _application, handle, api, _doctor, _backup = _state_services(
            state_root=state_root, workspace_id=workspace_id, directory=directory, write=True
        )
        result = api.create_grant(
            task_run_id=task_run_id,
            agent_run_id=agent_run_id,
            capabilities=(CapabilityName.UNCONFINED_HOST_PROCESS,),
            reason=reason,
            preview_digest=UNCONFINED_HOST_WARNING_DIGEST,
            expires_at=datetime.now(UTC) + timedelta(minutes=expires_minutes),
            command_id=command_id,
        )
        _emit_model(result.value)
    except Exception as exc:
        _cli_error(exc)
        raise typer.Exit(code=2) from None
    finally:
        _close_state(handle)


@grant_app.command("revoke")
def grant_revoke(
    grant_id: str,
    reason: str = typer.Option("revoked by local interface", "--reason"),
    expected_row_version: int | None = typer.Option(None, "--expected-row-version", min=1),
    command_id: str | None = typer.Option(None, "--command-id"),
    workspace_id: str | None = typer.Option(None, "--workspace-id"),
    directory: Path = typer.Option(Path("."), "--dir", exists=True, file_okay=False),
    state_root: Path | None = typer.Option(None, "--state-root", hidden=True),
) -> None:
    handle = None
    try:
        _application, handle, api, _doctor, _backup = _state_services(
            state_root=state_root, workspace_id=workspace_id, directory=directory, write=True
        )
        _emit_model(
            api.revoke_grant(
                grant_id,
                reason=reason,
                expected_row_version=expected_row_version,
                command_id=command_id,
            ).value
        )
    except Exception as exc:
        _cli_error(exc)
        raise typer.Exit(code=2) from None
    finally:
        _close_state(handle)


@artifact_app.command("list")
def artifact_list(
    session_id: str | None = typer.Option(None, "--session-id"),
    task_run_id: str | None = typer.Option(None, "--task-run-id"),
    workspace_id: str | None = typer.Option(None, "--workspace-id"),
    cursor: str | None = typer.Option(None, "--cursor"),
    limit: int = typer.Option(50, "--limit", min=1, max=100),
    as_json: bool = typer.Option(False, "--json"),
    directory: Path = typer.Option(Path("."), "--dir", exists=True, file_okay=False),
    state_root: Path | None = typer.Option(None, "--state-root", hidden=True),
) -> None:
    handle = None
    try:
        _application, handle, api, _doctor, _backup = _state_services(
            state_root=state_root, workspace_id=workspace_id, directory=directory, write=False
        )
        page = api.list_artifacts(
            session_id=session_id,
            task_run_id=task_run_id,
            cursor=cursor,
            limit=limit,
        )
        _emit_page(
            page,
            as_json=as_json,
            render=lambda item: (
                f"{item.artifact_id}\t{item.state.value}\t{item.byte_size} bytes\t"
                f"{item.retention.value}"
            ),
        )
    except Exception as exc:
        _cli_error(exc)
        raise typer.Exit(code=2) from None
    finally:
        _close_state(handle)


@artifact_app.command("show")
def artifact_show(
    artifact_id: str,
    workspace_id: str | None = typer.Option(None, "--workspace-id"),
    directory: Path = typer.Option(Path("."), "--dir", exists=True, file_okay=False),
    state_root: Path | None = typer.Option(None, "--state-root", hidden=True),
) -> None:
    handle = None
    try:
        _application, handle, api, _doctor, _backup = _state_services(
            state_root=state_root, workspace_id=workspace_id, directory=directory, write=False
        )
        item = api.get_artifact(artifact_id)
        if item is None:
            raise ApplicationError(ApplicationErrorCode.NOT_FOUND, "Artifact is missing")
        _emit_model(item)
    except Exception as exc:
        _cli_error(exc)
        raise typer.Exit(code=2) from None
    finally:
        _close_state(handle)


@artifact_app.command("pin")
def artifact_pin(
    artifact_id: str,
    command_id: str | None = typer.Option(None, "--command-id"),
    expected_row_version: int | None = typer.Option(None, "--expected-row-version", min=1),
    workspace_id: str | None = typer.Option(None, "--workspace-id"),
    directory: Path = typer.Option(Path("."), "--dir", exists=True, file_okay=False),
    state_root: Path | None = typer.Option(None, "--state-root", hidden=True),
) -> None:
    handle = None
    try:
        _application, handle, api, _doctor, _backup = _state_services(
            state_root=state_root, workspace_id=workspace_id, directory=directory, write=True
        )
        _emit_model(
            api.pin_artifact(
                artifact_id, command_id=command_id, expected_row_version=expected_row_version
            ).value
        )
    except Exception as exc:
        _cli_error(exc)
        raise typer.Exit(code=2) from None
    finally:
        _close_state(handle)


@artifact_app.command("release")
def artifact_release(
    artifact_id: str,
    command_id: str | None = typer.Option(None, "--command-id"),
    expected_row_version: int | None = typer.Option(None, "--expected-row-version", min=1),
    workspace_id: str | None = typer.Option(None, "--workspace-id"),
    directory: Path = typer.Option(Path("."), "--dir", exists=True, file_okay=False),
    state_root: Path | None = typer.Option(None, "--state-root", hidden=True),
) -> None:
    handle = None
    try:
        _application, handle, api, _doctor, _backup = _state_services(
            state_root=state_root, workspace_id=workspace_id, directory=directory, write=True
        )
        _emit_model(
            api.release_artifact(
                artifact_id, command_id=command_id, expected_row_version=expected_row_version
            ).value
        )
    except Exception as exc:
        _cli_error(exc)
        raise typer.Exit(code=2) from None
    finally:
        _close_state(handle)


@recovery_app.command("show")
def recovery_show(
    session_id: str,
    workspace_id: str | None = typer.Option(None, "--workspace-id"),
    directory: Path = typer.Option(Path("."), "--dir", exists=True, file_okay=False),
    state_root: Path | None = typer.Option(None, "--state-root", hidden=True),
) -> None:
    handle = None
    try:
        _application, handle, api, _doctor, _backup = _state_services(
            state_root=state_root, workspace_id=workspace_id, directory=directory, write=False
        )
        for report in api.list_recovery(session_id):
            _emit_model(report)
    except Exception as exc:
        _cli_error(exc)
        raise typer.Exit(code=2) from None
    finally:
        _close_state(handle)


@recovery_app.command("resolve")
def recovery_resolve(
    report_id: str,
    resolution: RecoveryResolution,
    command_id: str | None = typer.Option(
        None,
        "--command-id",
        help="可选幂等键；省略时自动生成，重试同一请求时可显式复用。",
    ),
    item_id: str | None = typer.Option(None, "--item-id"),
    workspace_id: str | None = typer.Option(None, "--workspace-id"),
    directory: Path = typer.Option(Path("."), "--dir", exists=True, file_okay=False),
    state_root: Path | None = typer.Option(None, "--state-root", hidden=True),
) -> None:
    """持久化 Recovery 决策；resume 只准备 AgentRun，不调用 Provider。"""
    handle = None
    try:
        _application, handle, api, _doctor, _backup = _state_services(
            state_root=state_root, workspace_id=workspace_id, directory=directory, write=True
        )
        result = api.resolve_recovery_by_id(
            report_id,
            command_id=command_id,
            resolution=resolution,
            item_id=item_id,
        )
        _emit_model(result.value)
    except Exception as exc:
        _cli_error(exc)
        raise typer.Exit(code=2) from None
    finally:
        _close_state(handle)


@state_app.command("doctor")
def state_doctor(
    workspace_id: str = typer.Option(..., "--workspace-id"),
    as_json: bool = typer.Option(False, "--json"),
    state_root: Path | None = typer.Option(None, "--state-root", hidden=True),
) -> None:
    try:
        application = build_application(state_root=state_root)
        doctor = OperationalDoctor(OperationalStore(application.data_root.root))
        report = doctor.inspect(workspace_id)
        if as_json:
            typer.echo(report.json_bytes().decode("utf-8"))
        else:
            typer.echo(f"health: {report.health.value}")
            typer.echo(f"schema_version: {report.schema_version}")
            for issue in report.issues:
                typer.echo(f"{issue.severity.value}: {issue.code} ({issue.count}) {issue.summary}")
        if report.health.value != "ok":
            raise typer.Exit(code=2)
    except typer.Exit:
        raise
    except Exception as exc:
        _cli_error(exc)
        raise typer.Exit(code=2) from None


@state_app.command("events")
def state_events(
    workspace_id: str = typer.Option(..., "--workspace-id"),
    after_cursor: int = typer.Option(0, "--after", min=0),
    limit: int = typer.Option(100, "--limit", min=1, max=100),
    state_root: Path | None = typer.Option(None, "--state-root", hidden=True),
) -> None:
    handle = None
    try:
        _application, handle, api, _doctor, _backup = _state_services(
            state_root=state_root, workspace_id=workspace_id, directory=Path("."), write=False
        )
        for event in api.list_events(after_cursor=after_cursor, limit=limit).items:
            typer.echo(
                f"{event.cursor}\t{event.event_type}\t{event.aggregate_kind}\t{event.aggregate_id}"
            )
    except Exception as exc:
        _cli_error(exc)
        raise typer.Exit(code=2) from None
    finally:
        _close_state(handle)


@state_app.command("backup")
def state_backup(
    name: str | None = typer.Option(None, "--name"),
    state_root: Path | None = typer.Option(None, "--state-root", hidden=True),
) -> None:
    handle = None
    try:
        _application, handle, _api, _doctor, backup = _state_services(
            state_root=state_root, workspace_id="ws_cli", directory=Path("."), write=True
        )
        _emit_model(backup.create(name))
    except Exception as exc:
        _cli_error(exc)
        raise typer.Exit(code=2) from None
    finally:
        _close_state(handle)


@state_app.command("verify-backup")
def state_verify_backup(
    bundle: Path,
    state_root: Path | None = typer.Option(None, "--state-root", hidden=True),
) -> None:
    handle = None
    try:
        _application, handle, _api, _doctor, backup = _state_services(
            state_root=state_root, workspace_id="ws_cli", directory=Path("."), write=False
        )
        report = backup.verify(bundle)
        _emit_model(report)
        if not report.ok:
            raise typer.Exit(code=2)
    except typer.Exit:
        raise
    except Exception as exc:
        _cli_error(exc)
        raise typer.Exit(code=2) from None
    finally:
        _close_state(handle)


@state_app.command("cleanup")
def state_cleanup(
    workspace_id: str = typer.Option(..., "--workspace-id"),
    apply: bool = typer.Option(
        False,
        "--apply",
        help="将已验证的非托管孤儿文件移入私有隔离区；不销毁原字节。",
    ),
    state_root: Path | None = typer.Option(None, "--state-root", hidden=True),
) -> None:
    handle = None
    try:
        _application, handle, api, _doctor, _backup = _state_services(
            state_root=state_root, workspace_id=workspace_id, directory=Path("."), write=apply
        )
        _emit_model(api.cleanup_orphans(dry_run=not apply))
    except Exception as exc:
        _cli_error(exc)
        raise typer.Exit(code=2) from None
    finally:
        _close_state(handle)


def main() -> None:
    app()
