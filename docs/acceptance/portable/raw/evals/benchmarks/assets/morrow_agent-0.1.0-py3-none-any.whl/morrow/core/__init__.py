"""Framework-independent domain contracts."""
