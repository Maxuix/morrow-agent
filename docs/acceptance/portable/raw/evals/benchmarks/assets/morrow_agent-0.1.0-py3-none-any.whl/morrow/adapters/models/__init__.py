"""Model provider adapters."""
