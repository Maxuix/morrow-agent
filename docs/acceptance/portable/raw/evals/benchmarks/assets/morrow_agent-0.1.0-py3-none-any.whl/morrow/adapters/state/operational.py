"""SQLite adapter for the current Operational Store schema."""

from __future__ import annotations

import os
import random
import sqlite3
import stat
import threading
import time
import uuid
from collections.abc import Callable, Sequence
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from urllib.parse import quote

from filelock import FileLock, Timeout

from morrow.adapters.state.schema import CURRENT_SCHEMA_STATEMENTS, CURRENT_SCHEMA_VERSION
from morrow.adapters.state.schema_reconcile import reconcile_schema
from morrow.core.store import (
    APPLICATION_ID,
    APPLICATION_NAME,
    BUSY_TIMEOUT_MS,
    DIRECTORY_MODE,
    FILE_MODE,
    WRITE_RETRY_ATTEMPTS,
    BackupReport,
    OperationalStoreLayout,
    StorageError,
    StorageErrorCode,
    StoreClassification,
    StoreClock,
    StoreHealth,
    StoreIdentity,
    StoreOpenMode,
)

SQLITE_HEADER = b"SQLite format 3\x00"
_BUSY_CODES = {
    getattr(sqlite3, "SQLITE_BUSY", 5),
    getattr(sqlite3, "SQLITE_LOCKED", 6),
}

# Versions that still have a bounded data-migration path.  Older or unknown
# catalogs remain diagnosable and require an explicit restore/rebuild choice.
_UPGRADEABLE_SCHEMA_VERSIONS = tuple(range(42, CURRENT_SCHEMA_VERSION))


class SystemStoreClock:
    def now(self) -> datetime:
        return datetime.now(UTC)


@dataclass
class BusyRetryPolicy:
    attempts: int = WRITE_RETRY_ATTEMPTS
    busy_timeout_ms: int = BUSY_TIMEOUT_MS
    sleep: Callable[[float], None] = field(default=time.sleep)
    rng: random.Random = field(default_factory=random.Random)

    def delay_seconds(self, failed_attempt_index: int) -> float:
        cap = 0.032
        ceiling = min(cap, 0.001 * (2**failed_attempt_index))
        return self.rng.uniform(0.0, ceiling)


def is_busy_or_locked(exc: BaseException) -> bool:
    if not isinstance(exc, sqlite3.OperationalError):
        return False
    code = getattr(exc, "sqlite_errorcode", None)
    if code is not None:
        return code in _BUSY_CODES
    message = str(exc).lower()
    return "database is locked" in message or "database is busy" in message


def translate_sqlite_error(exc: sqlite3.Error) -> StorageError:
    if is_busy_or_locked(exc):
        return StorageError(StorageErrorCode.BUSY, "operational store write contended")
    message = str(exc).lower()
    if "readonly" in message:
        return StorageError(StorageErrorCode.UNAVAILABLE, "operational store is not writable")
    if "full" in message or "disk" in message or "no space" in message:
        return StorageError(StorageErrorCode.UNAVAILABLE, "operational store could not be written")
    if isinstance(exc, sqlite3.IntegrityError):
        return StorageError(
            StorageErrorCode.UNAVAILABLE, "operational store rejected the statement"
        )
    return StorageError(StorageErrorCode.UNAVAILABLE, "operational store statement failed")


def run_with_busy_retry[T](work: Callable[[], T], policy: BusyRetryPolicy) -> T:
    last_error: BaseException | None = None
    for index in range(policy.attempts):
        try:
            return work()
        except StorageError as exc:
            last_error = exc
            if exc.code != StorageErrorCode.BUSY or index == policy.attempts - 1:
                raise
        except sqlite3.Error as exc:
            last_error = exc
            if not is_busy_or_locked(exc) or index == policy.attempts - 1:
                if is_busy_or_locked(exc):
                    raise StorageError(
                        StorageErrorCode.BUSY, "operational store write contended"
                    ) from exc
                raise translate_sqlite_error(exc) from exc
        policy.sleep(policy.delay_seconds(index))
    if isinstance(last_error, StorageError):
        raise last_error
    raise StorageError(StorageErrorCode.BUSY, "operational store write contended") from last_error


def rollback_quietly(connection: sqlite3.Connection) -> None:
    try:
        connection.execute("ROLLBACK")
    except sqlite3.Error:
        pass


def posix_mode(path: Path) -> int:
    return stat.S_IMODE(path.stat().st_mode)


def restrict_path(path: Path, mode: int) -> None:
    try:
        path.chmod(mode)
        if posix_mode(path) != mode:
            raise StorageError(
                StorageErrorCode.UNAVAILABLE, "operational path mode could not be verified"
            )
    except OSError as exc:
        raise StorageError(
            StorageErrorCode.UNAVAILABLE, "operational path mode could not be verified"
        ) from exc


def _sqlite_uri(path: Path, *, immutable: bool = False) -> str:
    query = "mode=ro&immutable=1" if immutable else "mode=ro"
    return f"file:{quote(path.as_posix(), safe='/')}?{query}"


def _is_readonly_write_error(exc: BaseException) -> bool:
    return isinstance(exc, sqlite3.OperationalError) and "readonly" in str(exc).lower()


class SqliteExecutor:
    def __init__(self, connection: sqlite3.Connection) -> None:
        self._connection = connection

    def execute(
        self, sql: str, parameters: Sequence[object] = ()
    ) -> tuple[tuple[object, ...], ...]:
        try:
            cursor = self._connection.execute(sql, tuple(parameters))
            rows = cursor.fetchall()
        except sqlite3.Error as exc:
            raise translate_sqlite_error(exc) from exc
        return tuple(tuple(row) for row in rows)


class OperationalMaintenanceLock:
    def __init__(self, layout: OperationalStoreLayout, *, timeout: float = 0.1) -> None:
        self.path = layout.maintenance_lock
        self.timeout = timeout
        self._lock = FileLock(str(self.path), timeout=timeout)

    def acquire(self) -> None:
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            raise StorageError(
                StorageErrorCode.UNAVAILABLE, "operational store could not be written"
            ) from exc
        try:
            self._lock.acquire()
        except Timeout as exc:
            raise StorageError(
                StorageErrorCode.BUSY, "operational store maintenance is already running"
            ) from exc
        if self.path.exists():
            try:
                restrict_path(self.path, FILE_MODE)
            except StorageError:
                self._lock.release()
                raise

    def release(self) -> None:
        self._lock.release()

    def __enter__(self) -> OperationalMaintenanceLock:
        self.acquire()
        return self

    def __exit__(self, exc_type, exc, traceback) -> None:
        self.release()


class OperationalStoreSession:
    def __init__(
        self,
        connection: sqlite3.Connection,
        *,
        mode: StoreOpenMode,
        health: StoreHealth,
        schema_version: int,
        retry_policy: BusyRetryPolicy,
        clock: StoreClock,
        failure_injector: Callable[[str], None] | None = None,
    ) -> None:
        self.mode = mode
        self.health = health
        self.schema_version = schema_version
        self._connection = connection
        self._retry_policy = retry_policy
        self._clock = clock
        self._failure_injector = failure_injector
        self._owner_thread_id = threading.get_ident()
        self._closed = False

    def now(self) -> datetime:
        """Return the store-scoped wall clock shared by transactional adapters."""

        return self._clock.now()

    def _fail(self, point: str) -> None:
        if self._failure_injector:
            self._failure_injector(point)

    def _assert_open_owner(self) -> None:
        if self._closed:
            raise StorageError(StorageErrorCode.UNAVAILABLE, "operational store is closed")
        if threading.get_ident() != self._owner_thread_id:
            raise StorageError(
                StorageErrorCode.UNAVAILABLE,
                "operational store connection is bound to its owner thread",
            )

    def run_read[T](self, work: Callable[[SqliteExecutor], T]) -> T:
        self._assert_open_owner()
        try:
            self._connection.execute("PRAGMA query_only = ON")
            try:
                return work(SqliteExecutor(self._connection))
            finally:
                if self.mode in {StoreOpenMode.READ_WRITE, StoreOpenMode.CREATE}:
                    self._connection.execute("PRAGMA query_only = OFF")
        except sqlite3.Error as exc:
            raise translate_sqlite_error(exc) from exc

    def run_write[T](self, work: Callable[[SqliteExecutor], T]) -> T:
        self._assert_open_owner()
        if self.mode not in {StoreOpenMode.READ_WRITE, StoreOpenMode.CREATE}:
            raise StorageError(StorageErrorCode.UNAVAILABLE, "operational store is not writable")

        return run_with_busy_retry(lambda: self._write_attempt(work), self._retry_policy)

    def run_write_once[T](self, work: Callable[[SqliteExecutor], T]) -> T:
        """Run a non-replayable write attempt, translating BUSY without retrying the body."""

        self._assert_open_owner()
        if self.mode not in {StoreOpenMode.READ_WRITE, StoreOpenMode.CREATE}:
            raise StorageError(StorageErrorCode.UNAVAILABLE, "operational store is not writable")
        try:
            return self._write_attempt(work)
        except StorageError:
            raise
        except sqlite3.Error as exc:
            raise translate_sqlite_error(exc) from exc

    def _write_attempt[T](self, work: Callable[[SqliteExecutor], T]) -> T:
        try:
            self._connection.execute("BEGIN IMMEDIATE")
        except sqlite3.Error as exc:
            raise translate_sqlite_error(exc) from exc
        try:
            self._fail("begin")
            result = work(SqliteExecutor(self._connection))
            self._fail("before_commit")
            self._connection.execute("COMMIT")
            self._fail("after_commit")
            return result
        except BaseException:
            rollback_quietly(self._connection)
            raise

    def close(self) -> None:
        if self._closed:
            return
        if threading.get_ident() != self._owner_thread_id:
            raise StorageError(
                StorageErrorCode.UNAVAILABLE,
                "operational store connection is bound to its owner thread",
            )
        rollback_quietly(self._connection)
        self._connection.close()
        self._closed = True

    def __enter__(self) -> OperationalStoreSession:
        return self

    def __exit__(self, exc_type, exc, traceback) -> None:
        self.close()


class OperationalStore:
    def __init__(
        self,
        data_root: Path,
        *,
        clock: StoreClock | None = None,
        retry_policy: BusyRetryPolicy | None = None,
        maintenance_timeout: float = 0.1,
        failure_injector: Callable[[str], None] | None = None,
    ) -> None:
        self.layout = OperationalStoreLayout.from_root(data_root)
        self.clock = clock or SystemStoreClock()
        self.retry_policy = retry_policy or BusyRetryPolicy()
        self.maintenance_timeout = maintenance_timeout
        self.failure_injector = failure_injector

    def _fail(self, point: str) -> None:
        if self.failure_injector:
            self.failure_injector(point)

    def maintenance_lock(self) -> OperationalMaintenanceLock:
        return OperationalMaintenanceLock(self.layout, timeout=self.maintenance_timeout)

    def classify(self) -> StoreClassification:
        database = self.layout.database
        if not database.exists():
            return StoreClassification(
                present=False, health=None, error_code=StorageErrorCode.NOT_FOUND
            )
        try:
            header = _read_header(database)
        except OSError as exc:
            raise StorageError(
                StorageErrorCode.UNAVAILABLE, "operational store could not be read"
            ) from exc
        if header != SQLITE_HEADER:
            return StoreClassification(
                present=True,
                health=StoreHealth.NEEDS_REPAIR,
                error_code=StorageErrorCode.NEEDS_REPAIR,
            )
        connection = None
        try:
            connection = self._connect(read_only=True)
            return self._classify_connection(connection, full_integrity=False)
        except StorageError:
            raise
        except sqlite3.Error as exc:
            if is_busy_or_locked(exc):
                raise StorageError(
                    StorageErrorCode.BUSY, "operational store write contended"
                ) from exc
            return StoreClassification(
                present=True,
                health=StoreHealth.NEEDS_REPAIR,
                error_code=StorageErrorCode.NEEDS_REPAIR,
            )
        finally:
            if connection is not None:
                connection.close()

    def open(self, mode: StoreOpenMode) -> OperationalStoreSession:
        if mode is StoreOpenMode.CREATE:
            with self.maintenance_lock():
                return self._initialize_locked()
        if mode is StoreOpenMode.READ_WRITE:
            if self.classify().schema_version in _UPGRADEABLE_SCHEMA_VERSIONS:
                with self.maintenance_lock():
                    self._upgrade_locked()
            with self.maintenance_lock():
                self._reconcile_locked()
            return self._open_read_write()
        if mode is StoreOpenMode.READ_ONLY:
            return self._open_inspect(mode, full_integrity=False)
        return self._open_inspect(StoreOpenMode.DIAGNOSE, full_integrity=True)

    def initialize(self) -> OperationalStoreSession:
        return self.open(StoreOpenMode.CREATE)

    def backup(self, destination_name: str | None = None) -> BackupReport:
        with self.maintenance_lock():
            return self._backup_locked(destination_name)

    def ensure_layout(self) -> None:
        directories = (
            self.layout.store_dir,
            self.layout.artifacts_dir,
            self.layout.artifacts_tmp,
            self.layout.backups_dir,
        )
        try:
            for directory in directories:
                directory.mkdir(parents=True, exist_ok=True)
                restrict_path(directory, DIRECTORY_MODE)
        except OSError as exc:
            raise StorageError(
                StorageErrorCode.UNAVAILABLE, "operational store could not be written"
            ) from exc
        self._fail("layout")

    def _open_read_write(self) -> OperationalStoreSession:
        self._require_present_header()
        if not os.access(self.layout.database, os.W_OK) or not os.access(
            self.layout.store_dir, os.W_OK
        ):
            raise StorageError(StorageErrorCode.UNAVAILABLE, "operational store is not writable")
        connection = None
        try:
            connection = self._connect(read_only=False)
            _apply_session_pragmas(connection, self.retry_policy.busy_timeout_ms)
            classified = self._classify_connection(connection, full_integrity=False)
            _raise_if_unhealthy(classified, allow_read_only=False)
            _enable_wal(connection)
            _restrict_sidecars(self.layout)
            restrict_path(self.layout.database, FILE_MODE)
            return OperationalStoreSession(
                connection,
                mode=StoreOpenMode.READ_WRITE,
                health=StoreHealth.OK,
                schema_version=classified.schema_version or 0,
                retry_policy=self.retry_policy,
                clock=self.clock,
                failure_injector=self.failure_injector,
            )
        except StorageError:
            if connection is not None:
                connection.close()
            raise
        except sqlite3.Error as exc:
            if connection is not None:
                connection.close()
            raise translate_sqlite_error(exc) from exc
        except OSError as exc:
            if connection is not None:
                connection.close()
            raise StorageError(
                StorageErrorCode.UNAVAILABLE, "operational store could not be written"
            ) from exc

    def _open_inspect(
        self, mode: StoreOpenMode, *, full_integrity: bool
    ) -> OperationalStoreSession:
        self._require_present_header()
        connection = None
        try:
            connection = self._connect(read_only=True)
            _apply_session_pragmas(connection, self.retry_policy.busy_timeout_ms, writable=False)
            classified = self._classify_connection(connection, full_integrity=full_integrity)
            if mode is StoreOpenMode.READ_ONLY:
                _raise_if_unhealthy(classified, allow_read_only=True)
                health = (
                    classified.health
                    if classified.health is StoreHealth.FUTURE_SCHEMA
                    else (
                        StoreHealth.READ_ONLY
                        if not os.access(self.layout.database, os.W_OK)
                        else StoreHealth.OK
                    )
                )
                if not _header_is_wal(self.layout.database):
                    raise StorageError(
                        StorageErrorCode.UNAVAILABLE, "operational store is not in WAL mode"
                    )
                return OperationalStoreSession(
                    connection,
                    mode=mode,
                    health=health,
                    schema_version=classified.schema_version or 0,
                    retry_policy=self.retry_policy,
                    clock=self.clock,
                    failure_injector=self.failure_injector,
                )
            health = classified.health or StoreHealth.NEEDS_REPAIR
            return OperationalStoreSession(
                connection,
                mode=mode,
                health=health,
                schema_version=classified.schema_version or 0,
                retry_policy=self.retry_policy,
                clock=self.clock,
                failure_injector=self.failure_injector,
            )
        except StorageError:
            if connection is not None:
                connection.close()
            raise
        except sqlite3.Error as exc:
            if connection is not None:
                connection.close()
            if is_busy_or_locked(exc):
                raise StorageError(
                    StorageErrorCode.BUSY, "operational store write contended"
                ) from exc
            raise StorageError(
                StorageErrorCode.NEEDS_REPAIR, _message_for(StorageErrorCode.NEEDS_REPAIR)
            ) from exc

    def _initialize_locked(self) -> OperationalStoreSession:
        database = self.layout.database
        if database.exists():
            classification = self.classify()
            if classification.schema_version in _UPGRADEABLE_SCHEMA_VERSIONS:
                self._upgrade_locked()
                classification = self.classify()
            if classification.ok:
                self._reconcile_locked()
                return self._open_read_write()
            code = classification.error_code or StorageErrorCode.NEEDS_REPAIR
            raise StorageError(code, _message_for(code))
        self.ensure_layout()
        connection = None
        try:
            connection = self._connect(read_only=False, missing_ok=True)
            _apply_session_pragmas(connection, self.retry_policy.busy_timeout_ms)
            _enable_wal(connection)
            try:
                # The catalog is created once at the current schema version. DDL
                # containing JSON functions must be parsed while trusted_schema
                # is enabled; it is restored before the session is returned.
                connection.execute("PRAGMA trusted_schema = ON")
                self._fail("begin")
                connection.execute("BEGIN IMMEDIATE")
                for statement in CURRENT_SCHEMA_STATEMENTS:
                    connection.execute(statement)
                connection.execute(f"PRAGMA application_id = {APPLICATION_ID}")
                connection.execute(f"PRAGMA user_version = {CURRENT_SCHEMA_VERSION}")
                self._fail("before_commit")
                connection.execute("COMMIT")
            except Exception:
                rollback_quietly(connection)
                raise
            finally:
                try:
                    connection.execute("PRAGMA trusted_schema = OFF")
                except sqlite3.Error:
                    pass
            self._fail("after_commit")
            _full_integrity(connection)
            restrict_path(database, FILE_MODE)
            _restrict_sidecars(self.layout)
            return OperationalStoreSession(
                connection,
                mode=StoreOpenMode.CREATE,
                health=StoreHealth.OK,
                schema_version=CURRENT_SCHEMA_VERSION,
                retry_policy=self.retry_policy,
                clock=self.clock,
                failure_injector=self.failure_injector,
            )
        except StorageError:
            if connection is not None:
                connection.close()
            raise
        except sqlite3.Error as exc:
            if connection is not None:
                connection.close()
            raise translate_sqlite_error(exc) from exc
        except OSError as exc:
            if connection is not None:
                connection.close()
            raise StorageError(
                StorageErrorCode.UNAVAILABLE, "operational store could not be written"
            ) from exc

    def _upgrade_locked(self) -> None:
        from morrow.adapters.state.schema_upgrade import DATA_MIGRATIONS, upgrade_v42, upgrade_v43

        classification = self.classify()
        if classification.ok:
            return
        if (
            classification.schema_version not in _UPGRADEABLE_SCHEMA_VERSIONS
            or classification.error_code is not StorageErrorCode.UNSUPPORTED_SCHEMA
        ):
            raise StorageError(
                classification.error_code or StorageErrorCode.NEEDS_REPAIR,
                "operational store cannot be upgraded",
            )
        version = classification.schema_version
        if version is None:
            raise StorageError(
                StorageErrorCode.NEEDS_REPAIR, "operational store cannot be upgraded"
            )
        while version < CURRENT_SCHEMA_VERSION:
            if version == 42:
                upgrade = upgrade_v42
            elif version == 43:
                upgrade = upgrade_v43
            else:
                upgrade = DATA_MIGRATIONS.get(version)
            if upgrade is None:
                raise StorageError(
                    StorageErrorCode.UNSUPPORTED_SCHEMA,
                    "operational store cannot be upgraded",
                )
            next_version = version + 1
            # The source backup includes committed WAL content, not only the DB file.
            self._backup_locked(
                f"pre-v{next_version}-{uuid.uuid4().hex}.sqlite", allow_upgrade=True
            )
            connection = self._connect(read_only=False)
            try:
                _apply_session_pragmas(connection, self.retry_policy.busy_timeout_ms)
                identity = _read_identity(connection)
                if identity.user_version != version:
                    raise StorageError(
                        StorageErrorCode.BUSY, "store version changed during upgrade"
                    )
                upgrade(connection, before_commit=lambda: self._fail("upgrade_before_commit"))
            except sqlite3.Error as exc:
                raise translate_sqlite_error(exc) from exc
            finally:
                connection.close()
            version = next_version
        if not classification.ok:
            classification = self.classify()
        if not classification.ok:
            raise StorageError(
                classification.error_code or StorageErrorCode.NEEDS_REPAIR,
                "operational store cannot be upgraded",
            )

    def _reconcile_locked(self) -> None:
        """Apply safe additive schema changes while holding the maintenance lock."""

        classification = self.classify()
        if not classification.present or classification.health is StoreHealth.FUTURE_SCHEMA:
            return
        if classification.error_code not in {None, StorageErrorCode.UNSUPPORTED_SCHEMA}:
            return
        if classification.schema_version is None or classification.schema_version < min(
            _UPGRADEABLE_SCHEMA_VERSIONS
        ):
            return
        connection = None
        try:
            # Most opens are already at the desired shape.  Diff those stores
            # through a read-only connection so an unrelated writer does not
            # turn a no-op open into a write-lock contention.
            connection = self._connect(read_only=True)
            _apply_session_pragmas(connection, self.retry_policy.busy_timeout_ms, writable=False)
            preview = reconcile_schema(connection, apply=False)
            connection.close()
            connection = None
            if not preview.pending_changes:
                return

            connection = self._connect(read_only=False)
            _apply_session_pragmas(connection, self.retry_policy.busy_timeout_ms)
            connection.execute("PRAGMA trusted_schema = ON")
            connection.execute("BEGIN IMMEDIATE")
            report = reconcile_schema(connection, apply=True)
            if report.pending_changes:
                raise StorageError(
                    StorageErrorCode.UNSUPPORTED_SCHEMA,
                    "operational store requires an explicit schema migration",
                )
            if connection.execute("PRAGMA foreign_key_check").fetchall():
                raise StorageError(
                    StorageErrorCode.NEEDS_REPAIR,
                    "operational store foreign-key validation failed",
                )
            connection.execute("COMMIT")
        except StorageError:
            if connection is not None:
                rollback_quietly(connection)
            raise
        except sqlite3.Error as exc:
            if connection is not None:
                rollback_quietly(connection)
            raise translate_sqlite_error(exc) from exc
        finally:
            if connection is not None:
                try:
                    connection.execute("PRAGMA trusted_schema = OFF")
                except sqlite3.Error:
                    pass
                connection.close()

    def _backup_locked(
        self, destination_name: str | None = None, *, allow_upgrade: bool = False
    ) -> BackupReport:
        classification = self._require_present_header()
        upgrading = (
            allow_upgrade
            and classification.schema_version in _UPGRADEABLE_SCHEMA_VERSIONS
            and classification.error_code is StorageErrorCode.UNSUPPORTED_SCHEMA
        )
        if (
            not upgrading
            and classification.error_code is not None
            and classification.error_code
            not in {
                StorageErrorCode.FUTURE_SCHEMA,
            }
        ):
            # Backup of a future schema is allowed as a safe copy; corrupt files are not.
            if classification.error_code is not StorageErrorCode.FUTURE_SCHEMA:
                raise StorageError(
                    classification.error_code, _message_for(classification.error_code)
                )
        self.ensure_layout()
        name = _backup_name(destination_name, self.clock)
        destination = self.layout.backups_dir / name
        if destination.exists():
            raise StorageError(StorageErrorCode.UNAVAILABLE, "operational backup already exists")
        source = None
        target = None
        try:
            source = self._connect(read_only=True)
            _apply_session_pragmas(source, self.retry_policy.busy_timeout_ms, writable=False)
            classified = self._classify_connection(source, full_integrity=False)
            if classified.error_code in {
                StorageErrorCode.NEEDS_REPAIR,
                StorageErrorCode.IDENTITY_MISMATCH,
            }:
                raise StorageError(classified.error_code, _message_for(classified.error_code))
            target = sqlite3.connect(
                destination,
                isolation_level=None,
                timeout=0,
                check_same_thread=True,
            )
            source.backup(target)
            self._fail("after_backup_copy")
            _apply_session_pragmas(target, self.retry_policy.busy_timeout_ms)
            _full_integrity(target)
            identity = _read_identity(target)
            target.close()
            target = None
            restrict_path(destination, FILE_MODE)
            return BackupReport(
                health=StoreHealth.OK,
                schema_version=identity.user_version,
                destination_name=name,
                integrity_ok=True,
            )
        except StorageError:
            if destination.exists():
                destination.unlink(missing_ok=True)
            raise
        except sqlite3.Error as exc:
            if destination.exists():
                destination.unlink(missing_ok=True)
            raise translate_sqlite_error(exc) from exc
        except OSError as exc:
            if destination.exists():
                destination.unlink(missing_ok=True)
            raise StorageError(
                StorageErrorCode.UNAVAILABLE, "operational store could not be written"
            ) from exc
        finally:
            if target is not None:
                target.close()
            if source is not None:
                source.close()

    def _require_present_header(self) -> StoreClassification:
        database = self.layout.database
        if not database.exists():
            raise StorageError(StorageErrorCode.NOT_FOUND, _message_for(StorageErrorCode.NOT_FOUND))
        try:
            header = _read_header(database)
        except OSError as exc:
            raise StorageError(
                StorageErrorCode.UNAVAILABLE, "operational store could not be read"
            ) from exc
        if header != SQLITE_HEADER:
            raise StorageError(
                StorageErrorCode.NEEDS_REPAIR, _message_for(StorageErrorCode.NEEDS_REPAIR)
            )
        return self.classify()

    def _connect(self, *, read_only: bool, missing_ok: bool = False) -> sqlite3.Connection:
        database = self.layout.database
        existed = database.exists()
        if not existed and (read_only or not missing_ok):
            raise StorageError(StorageErrorCode.NOT_FOUND, _message_for(StorageErrorCode.NOT_FOUND))
        if existed:
            try:
                header = _read_header(database)
            except OSError as exc:
                raise StorageError(
                    StorageErrorCode.UNAVAILABLE, "operational store could not be read"
                ) from exc
            if header != SQLITE_HEADER:
                raise StorageError(
                    StorageErrorCode.NEEDS_REPAIR, _message_for(StorageErrorCode.NEEDS_REPAIR)
                )
        self._fail("connect")
        try:
            if read_only:
                immutable = not os.access(database.parent, os.W_OK) and not (
                    self.layout.wal.exists() and os.access(self.layout.wal, os.R_OK)
                )
                connection = sqlite3.connect(
                    _sqlite_uri(database, immutable=immutable),
                    uri=True,
                    isolation_level=None,
                    timeout=0,
                    check_same_thread=True,
                )
            else:
                connection = sqlite3.connect(
                    database,
                    isolation_level=None,
                    timeout=0,
                    check_same_thread=True,
                )
        except sqlite3.Error as exc:
            if is_busy_or_locked(exc):
                raise StorageError(
                    StorageErrorCode.BUSY, "operational store write contended"
                ) from exc
            if _is_readonly_write_error(exc):
                raise StorageError(
                    StorageErrorCode.UNAVAILABLE, "operational store is not writable"
                ) from exc
            raise StorageError(
                StorageErrorCode.NEEDS_REPAIR, _message_for(StorageErrorCode.NEEDS_REPAIR)
            ) from exc
        connection.row_factory = None
        return connection

    def _classify_connection(
        self, connection: sqlite3.Connection, *, full_integrity: bool
    ) -> StoreClassification:
        if full_integrity:
            try:
                _full_integrity(connection)
            except StorageError as exc:
                if exc.code is StorageErrorCode.NEEDS_REPAIR:
                    return StoreClassification(
                        present=True,
                        health=StoreHealth.NEEDS_REPAIR,
                        error_code=StorageErrorCode.NEEDS_REPAIR,
                    )
                raise
        try:
            identity = _read_identity(connection)
        except sqlite3.Error as exc:
            if is_busy_or_locked(exc):
                raise StorageError(
                    StorageErrorCode.BUSY, "operational store write contended"
                ) from exc
            return StoreClassification(
                present=True,
                health=StoreHealth.NEEDS_REPAIR,
                error_code=StorageErrorCode.NEEDS_REPAIR,
            )
        classified = _classify_identity(identity)
        return classified


def _read_header(database: Path) -> bytes:
    with database.open("rb") as handle:
        return handle.read(len(SQLITE_HEADER))


def _pragma_int(connection: sqlite3.Connection, name: str) -> int:
    row = connection.execute(f"PRAGMA {name}").fetchone()
    if row is None or row[0] is None:
        return 0
    return int(row[0])


def _read_identity(connection: sqlite3.Connection) -> StoreIdentity:
    application_id = _pragma_int(connection, "application_id")
    user_version = _pragma_int(connection, "user_version")
    fallback_name = APPLICATION_NAME if application_id == APPLICATION_ID else None
    try:
        row = connection.execute(
            "SELECT application_name, schema_version FROM store_identity WHERE singleton = 1"
        ).fetchone()
    except sqlite3.DatabaseError as exc:
        if is_busy_or_locked(exc):
            raise
        if "no such table: store_identity" not in str(exc).lower():
            raise
        return StoreIdentity(
            application_id=application_id,
            user_version=user_version,
            application_name=fallback_name,
            schema_version=user_version if fallback_name is not None else None,
        )
    if row is None:
        return StoreIdentity(
            application_id=application_id,
            user_version=user_version,
            application_name=fallback_name,
            schema_version=user_version if fallback_name is not None else None,
        )
    return StoreIdentity(
        application_id=application_id,
        user_version=user_version,
        application_name=str(row[0]),
        schema_version=int(row[1]),
    )


def _classify_identity(identity: StoreIdentity) -> StoreClassification:
    if (
        identity.application_id == 0
        and identity.application_name is None
        and identity.user_version == 0
        and identity.schema_version is None
    ):
        return StoreClassification(
            present=True,
            health=StoreHealth.NEEDS_REPAIR,
            error_code=StorageErrorCode.NEEDS_REPAIR,
        )
    if identity.application_id != APPLICATION_ID or identity.application_name != APPLICATION_NAME:
        return StoreClassification(
            present=True,
            health=StoreHealth.NEEDS_REPAIR,
            error_code=StorageErrorCode.IDENTITY_MISMATCH,
            schema_version=identity.schema_version,
            application_name=identity.application_name,
        )
    if identity.schema_version is None or identity.user_version != identity.schema_version:
        return StoreClassification(
            present=True,
            health=StoreHealth.NEEDS_REPAIR,
            error_code=StorageErrorCode.NEEDS_REPAIR,
            schema_version=identity.schema_version,
            application_name=identity.application_name,
        )
    if identity.user_version > CURRENT_SCHEMA_VERSION:
        return StoreClassification(
            present=True,
            health=StoreHealth.FUTURE_SCHEMA,
            error_code=StorageErrorCode.FUTURE_SCHEMA,
            schema_version=identity.user_version,
            application_name=identity.application_name,
        )
    if identity.user_version != CURRENT_SCHEMA_VERSION:
        return StoreClassification(
            present=True,
            health=StoreHealth.UNSUPPORTED_SCHEMA,
            error_code=StorageErrorCode.UNSUPPORTED_SCHEMA,
            schema_version=identity.user_version,
            application_name=identity.application_name,
        )
    return StoreClassification(
        present=True,
        health=StoreHealth.OK,
        error_code=None,
        schema_version=identity.user_version,
        application_name=identity.application_name,
    )


def _apply_session_pragmas(
    connection: sqlite3.Connection, busy_timeout_ms: int, *, writable: bool = True
) -> None:
    try:
        connection.execute(f"PRAGMA busy_timeout = {int(busy_timeout_ms)}")
        connection.execute("PRAGMA foreign_keys = ON")
        # SQLite 3.40 parses persistent schema lazily. Load the catalog while
        # trusted_schema is still ON: the application-owned schema contains
        # json_valid()/json_extract() in indexes, and parsing it for the first
        # time after trusted_schema=OFF is rejected as unsafe.
        schema_primed = True
        try:
            connection.execute("SELECT name FROM sqlite_master").fetchall()
        except sqlite3.Error as exc:
            # Leave malformed catalogs for the classifier/integrity checker so
            # diagnose still reports NEEDS_REPAIR instead of UNAVAILABLE.
            if is_busy_or_locked(exc):
                raise
            schema_primed = False
        if writable and schema_primed:
            connection.execute("PRAGMA synchronous = FULL")
        connection.execute("PRAGMA trusted_schema = OFF")
    except sqlite3.Error as exc:
        raise translate_sqlite_error(exc) from exc


def _enable_wal(connection: sqlite3.Connection) -> None:
    try:
        journal_mode = connection.execute("PRAGMA journal_mode = WAL").fetchone()[0]
    except sqlite3.Error as exc:
        raise translate_sqlite_error(exc) from exc
    if str(journal_mode).lower() != "wal":
        raise StorageError(StorageErrorCode.UNAVAILABLE, "operational store did not enter WAL mode")


def _header_is_wal(database: Path) -> bool:
    try:
        with database.open("rb") as handle:
            handle.seek(18)
            write_version = handle.read(1)
    except OSError:
        return False
    return write_version == b"\x02"


def _full_integrity(connection: sqlite3.Connection) -> None:
    integrity = None
    foreign_keys: tuple[tuple[object, ...], ...] | None = None
    try:
        # integrity_check walks partial indexes that call json_extract();
        # Debian SQLite 3.40 treats that as unsafe when trusted_schema is OFF.
        connection.execute("PRAGMA trusted_schema = ON")
        integrity = connection.execute("PRAGMA integrity_check").fetchone()[0]
        foreign_keys = tuple(connection.execute("PRAGMA foreign_key_check").fetchall())
    except sqlite3.Error as exc:
        raise StorageError(
            StorageErrorCode.NEEDS_REPAIR, _message_for(StorageErrorCode.NEEDS_REPAIR)
        ) from exc
    finally:
        try:
            connection.execute("PRAGMA trusted_schema = OFF")
        except sqlite3.Error:
            pass
    if integrity != "ok" or foreign_keys:
        raise StorageError(
            StorageErrorCode.NEEDS_REPAIR, _message_for(StorageErrorCode.NEEDS_REPAIR)
        )


def _restrict_sidecars(layout: OperationalStoreLayout) -> None:
    for path in (layout.wal, layout.shm):
        if path.exists():
            restrict_path(path, FILE_MODE)


def _raise_if_unhealthy(classification: StoreClassification, *, allow_read_only: bool) -> None:
    if classification.error_code is None:
        return
    if allow_read_only and classification.error_code is StorageErrorCode.FUTURE_SCHEMA:
        return
    raise StorageError(classification.error_code, _message_for(classification.error_code))


def _message_for(code: StorageErrorCode) -> str:
    return {
        StorageErrorCode.BUSY: "operational store write contended",
        StorageErrorCode.UNSUPPORTED_SCHEMA: (
            "operational store uses an older schema; create a new store with this version"
        ),
        StorageErrorCode.FUTURE_SCHEMA: (
            "operational store is newer than this binary; restore a backup from "
            "a matching Morrow version"
        ),
        StorageErrorCode.IDENTITY_MISMATCH: "file is not a Morrow operational store",
        StorageErrorCode.NEEDS_REPAIR: "operational store is not a usable SQLite file",
        StorageErrorCode.NOT_FOUND: "operational store is missing",
        StorageErrorCode.UNAVAILABLE: "operational store is unavailable",
    }[code]


def _backup_name(destination_name: str | None, clock: StoreClock) -> str:
    if destination_name is None:
        return f"operational-{int(clock.now().timestamp())}.sqlite"
    candidate = Path(destination_name)
    if candidate.name != destination_name or candidate.suffix != ".sqlite":
        raise StorageError(StorageErrorCode.UNAVAILABLE, "operational backup name is invalid")
    if destination_name in {".", ".."} or "/" in destination_name or "\\" in destination_name:
        raise StorageError(StorageErrorCode.UNAVAILABLE, "operational backup name is invalid")
    return destination_name
