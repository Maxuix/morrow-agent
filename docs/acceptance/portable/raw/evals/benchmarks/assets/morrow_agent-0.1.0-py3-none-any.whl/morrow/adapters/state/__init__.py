"""Local state adapters."""
