"""Application service for durable Artifact publication and inspection."""

from __future__ import annotations

import asyncio
import re
from collections.abc import Callable
from contextlib import contextmanager
from datetime import datetime

from morrow.adapters.state.artifacts import FilesystemArtifactStore
from morrow.core.artifacts import (
    ARTIFACT_EXCERPT_MAX_BYTES,
    ARTIFACT_MAX_BYTES,
    TASK_ARTIFACT_MAX_BYTES,
    ArtifactBudgetError,
    ArtifactError,
    ArtifactErrorCode,
    ArtifactIntegrityError,
    ArtifactKind,
    ArtifactMetadata,
    ArtifactOrphanCandidate,
    ArtifactOrphanReport,
    ArtifactProvenanceKind,
    ArtifactProvenanceRef,
    ArtifactRead,
    ArtifactRetention,
    ArtifactRetentionReport,
    ArtifactSensitivity,
    ArtifactState,
)
from morrow.core.domain import (
    ARTIFACT_ID_PREFIX,
    TextSafetyProfile,
    canonical_json_bytes,
    refuse_secret_material,
    sha256_digest,
    utc_now,
)
from morrow.core.journal import ArtifactJournalPort
from morrow.core.ports import IdSource
from morrow.core.store import StorageError
from morrow.core.workflows.contracts import (
    NODE_OUTPUT_PAYLOAD_TYPES,
    ContractRef,
    TaskContract,
    WorkflowPayload,
    node_output_artifact_id,
    workflow_payload_excerpt,
)

_REDACTED_SECRET_ASSIGNMENT = re.compile(
    r"(?i)\b(?:api[_-]?key|authorization|credential|password|passwd|secret|token)\b"
    r'["\']?\s*[:=]\s*(?:"(?:Bearer\s+)?<redacted>"?|'
    r"'(?:Bearer\s+)?<redacted>'?|(?:Bearer\s+)?<redacted>)(?=$|[\s,;}\]])"
)
_REDACTED_SECRET_TOKEN = re.compile(r'(?i)\bsk-"?<redacted>"?(?=$|[\s,;}\]])')


def bounded_utf8_excerpt(content: bytes, *, limit: int = ARTIFACT_EXCERPT_MAX_BYTES) -> str:
    """Return a text excerpt whose encoded UTF-8 bytes never exceed ``limit``."""

    if limit < 0 or limit > ARTIFACT_EXCERPT_MAX_BYTES:
        raise ArtifactError(ArtifactErrorCode.BUDGET, "artifact excerpt limit is invalid")
    if not content or limit == 0:
        return ""
    return content[:limit].decode("utf-8", errors="ignore")


class ArtifactService:
    """Coordinate SQLite metadata with the managed Artifact filesystem."""

    def __init__(
        self,
        *,
        journal: ArtifactJournalPort,
        filesystem: FilesystemArtifactStore,
        workspace_id: str,
        id_source: IdSource,
        clock: Callable[[], datetime] = utc_now,
        faults=None,
    ) -> None:
        self.journal = journal
        self.filesystem = filesystem
        self.workspace_id = workspace_id
        self.id_source = id_source
        self.clock = clock
        self.faults = faults

    def publish_bytes(
        self,
        content: bytes,
        *,
        kind: ArtifactKind,
        session_id: str | None = None,
        task_run_id: str | None = None,
        sensitivity: ArtifactSensitivity = ArtifactSensitivity.REDACTED,
        retention: ArtifactRetention = ArtifactRetention.STANDARD,
        provenance_refs: tuple[ArtifactProvenanceRef, ...] = (),
        excerpt: str | None = None,
        artifact_id: str | None = None,
        already_redacted: bool = False,
    ) -> ArtifactMetadata:
        return self._publish_bytes(
            content,
            kind=kind,
            session_id=session_id,
            task_run_id=task_run_id,
            sensitivity=sensitivity,
            retention=retention,
            provenance_refs=provenance_refs,
            excerpt=excerpt,
            artifact_id=artifact_id,
            already_redacted=already_redacted,
        )

    def publish_attachment_bytes(
        self, content: bytes, *, session_id: str, artifact_id: str, role: str
    ):
        """User-input bytes have value-sensitive refusal; metadata keeps strict redaction.

        This seam is owned by AttachmentService. It cannot select a Workflow contract or
        expose the input in an Artifact excerpt, event, or command receipt.
        """
        refuse_secret_material(
            content.decode("utf-8", errors="replace"),
            label="attachment",
            profile="workflow_value_sensitive",
        )
        return self._publish_bytes(
            content,
            kind=ArtifactKind.CONTEXT_SUMMARY,
            session_id=session_id,
            artifact_id=artifact_id,
            excerpt="Attachment " + role,
            attachment_input=True,
        )

    def publish_workflow_payload(
        self,
        payload: WorkflowPayload,
        *,
        session_id: str,
        task_run_id: str,
        artifact_id: str | None = None,
        producer_node_run_id: str | None = None,
        output_slot: str | None = None,
    ) -> ArtifactMetadata:
        if type(payload) is not TaskContract and type(payload) not in NODE_OUTPUT_PAYLOAD_TYPES:
            raise ValueError("Workflow publication requires a typed payload")
        if isinstance(payload, TaskContract) and producer_node_run_id is not None:
            raise ValueError("TaskContract is Workflow input, not node output")
        if type(payload) in NODE_OUTPUT_PAYLOAD_TYPES and producer_node_run_id is None:
            raise ValueError(f"{type(payload).__name__} requires a NodeRun producer")
        content = canonical_json_bytes(payload.model_dump(mode="json"))
        if type(payload) in NODE_OUTPUT_PAYLOAD_TYPES:
            if output_slot is None:
                raise ValueError(f"{type(payload).__name__} requires a declared output slot")
            deterministic_id = node_output_artifact_id(producer_node_run_id, output_slot)
            if artifact_id not in {None, deterministic_id}:
                raise ValueError("Workflow output identity is fixed by NodeRun and slot")
            artifact_id = deterministic_id
        if artifact_id is not None:
            prior = self.journal.get_artifact(self.workspace_id, artifact_id)
            if prior is not None:
                if (
                    prior.sha256,
                    prior.session_id,
                    prior.task_run_id,
                    prior.producer_node_run_id,
                    prior.output_slot,
                    prior.text_safety_profile,
                    prior.contract,
                ) != (
                    sha256_digest(content),
                    session_id,
                    task_run_id,
                    producer_node_run_id,
                    output_slot,
                    TextSafetyProfile.WORKFLOW_VALUE_SENSITIVE,
                    ContractRef(kind=type(payload).__name__),
                ):
                    raise ArtifactError(
                        ArtifactErrorCode.CONFLICT, "Workflow output already has different content"
                    )
                if prior.state == ArtifactState.AVAILABLE:
                    self.filesystem.read(prior, max_bytes=prior.byte_size)
                    return prior
                raise ArtifactError(
                    ArtifactErrorCode.UNAVAILABLE, "Workflow Artifact requires staging recovery"
                )
        return self._publish_bytes(
            content,
            kind=ArtifactKind.TASK_SUMMARY,
            session_id=session_id,
            task_run_id=task_run_id,
            artifact_id=artifact_id,
            excerpt=workflow_payload_excerpt(payload),
            text_safety_profile=TextSafetyProfile.WORKFLOW_VALUE_SENSITIVE,
            contract=ContractRef(kind=type(payload).__name__),
            producer_node_run_id=producer_node_run_id,
            output_slot=output_slot,
        )

    def publish_workflow_capture(
        self,
        content: bytes,
        *,
        kind: ArtifactKind,
        session_id: str,
        task_run_id: str,
        artifact_id: str,
        excerpt: str,
        contract: ContractRef,
        provenance_refs: tuple[ArtifactProvenanceRef, ...] = (),
    ) -> ArtifactMetadata:
        """Typed Workflow capture seam; public publish_bytes cannot select this profile."""

        return self._publish_bytes(
            content,
            kind=kind,
            session_id=session_id,
            task_run_id=task_run_id,
            artifact_id=artifact_id,
            excerpt=excerpt,
            provenance_refs=provenance_refs,
            text_safety_profile=TextSafetyProfile.WORKFLOW_VALUE_SENSITIVE,
            contract=contract,
        )

    def _publish_bytes(
        self,
        content: bytes,
        *,
        kind: ArtifactKind,
        session_id: str | None = None,
        task_run_id: str | None = None,
        sensitivity: ArtifactSensitivity = ArtifactSensitivity.REDACTED,
        retention: ArtifactRetention = ArtifactRetention.STANDARD,
        provenance_refs: tuple[ArtifactProvenanceRef, ...] = (),
        excerpt: str | None = None,
        artifact_id: str | None = None,
        already_redacted: bool = False,
        text_safety_profile: TextSafetyProfile = TextSafetyProfile.LEGACY_STRICT,
        contract: ContractRef | None = None,
        producer_node_run_id: str | None = None,
        output_slot: str | None = None,
        attachment_input: bool = False,
    ) -> ArtifactMetadata:
        if not isinstance(content, bytes):
            raise ArtifactError(ArtifactErrorCode.INVALID, "artifact content must be bytes")
        if len(content) > ARTIFACT_MAX_BYTES:
            raise ArtifactBudgetError()
        if task_run_id is not None:
            current = self.journal.artifact_bytes_for_task(self.workspace_id, task_run_id)
            if current + len(content) > TASK_ARTIFACT_MAX_BYTES:
                raise ArtifactBudgetError("TaskRun artifact byte budget exceeded")
        selected_excerpt = bounded_utf8_excerpt(content) if excerpt is None else excerpt
        if already_redacted:
            selected_excerpt = self._remove_redacted_secret_assignments(selected_excerpt)
        if len(selected_excerpt.encode("utf-8")) > ARTIFACT_EXCERPT_MAX_BYTES:
            raise ArtifactBudgetError("artifact excerpt budget exceeded")
        try:
            if attachment_input:
                refuse_secret_material(
                    content.decode("utf-8", errors="replace"),
                    label="attachment",
                    profile="workflow_value_sensitive",
                )
            elif text_safety_profile == TextSafetyProfile.WORKFLOW_VALUE_SENSITIVE:
                refuse_secret_material(content, label="Artifact", profile=text_safety_profile)
            elif already_redacted:
                self._refuse_unredacted_secrets(content)
            else:
                self._refuse_secrets(content)
        except ValueError as exc:
            raise ArtifactError(
                ArtifactErrorCode.INVALID, "artifact content is not redacted"
            ) from exc
        try:
            metadata = ArtifactMetadata(
                artifact_id=artifact_id or self.id_source.new_id(ARTIFACT_ID_PREFIX),
                text_safety_profile=text_safety_profile,
                contract=contract,
                producer_node_run_id=producer_node_run_id,
                output_slot=output_slot,
                workspace_id=self.workspace_id,
                session_id=session_id,
                task_run_id=task_run_id,
                kind=kind,
                sensitivity=sensitivity,
                state=ArtifactState.STAGING,
                retention=retention,
                sha256=sha256_digest(content),
                byte_size=len(content),
                excerpt=selected_excerpt,
                provenance_refs=provenance_refs,
                created_at=self.clock(),
                updated_at=self.clock(),
            )
        except ValueError as exc:
            raise ArtifactError(ArtifactErrorCode.INVALID, "artifact metadata is invalid") from exc

        reserved = self.journal.reserve_artifact(self.workspace_id, metadata)
        self._check_fault("artifact.after_reserve")
        try:
            self.filesystem.publish(reserved, content, faults=self.faults)
        except ArtifactIntegrityError:
            self._try_mark(reserved, ArtifactState.CORRUPT)
            raise
        self._check_fault("artifact.before_mark_available")
        available = reserved.model_copy(
            update={
                "state": ArtifactState.AVAILABLE,
                "row_version": reserved.row_version + 1,
                "updated_at": self.clock(),
            }
        )
        published = self.journal.save_artifact(
            self.workspace_id,
            available,
            expected_row_version=reserved.row_version,
        )
        self._check_fault("artifact.after_mark_available")
        return published

    def publish_command_output(
        self,
        content: str | bytes,
        *,
        session_id: str,
        task_run_id: str,
        tool_execution_id: str,
    ) -> ArtifactMetadata:
        payload = content.encode("utf-8") if isinstance(content, str) else content
        return self.publish_bytes(
            payload,
            kind=ArtifactKind.COMMAND_OUTPUT,
            session_id=session_id,
            task_run_id=task_run_id,
            provenance_refs=(
                ArtifactProvenanceRef(
                    kind=ArtifactProvenanceKind.TOOL_EXECUTION,
                    reference_id=tool_execution_id,
                    role="command_output",
                ),
            ),
            excerpt=bounded_utf8_excerpt(payload),
            already_redacted=True,
        )

    def get(self, artifact_id: str) -> ArtifactMetadata | None:
        return self.journal.get_artifact(self.workspace_id, artifact_id)

    def read(self, artifact_id: str, *, max_bytes: int, start_byte: int = 0) -> ArtifactRead:
        with self._read_scope(artifact_id, start_byte) as metadata:
            content = self.filesystem.read(metadata, max_bytes=max_bytes, start_byte=start_byte)
        return ArtifactRead(metadata=metadata, content=content)

    async def read_async(
        self, artifact_id: str, *, max_bytes: int, start_byte: int = 0
    ) -> ArtifactRead:
        """Keep metadata checks/repair on the owner; offload only file verification/read."""
        with self._read_scope(artifact_id, start_byte) as metadata:
            content = await asyncio.to_thread(
                self.filesystem.read, metadata, max_bytes=max_bytes, start_byte=start_byte
            )
        return ArtifactRead(metadata=metadata, content=content)

    @contextmanager
    def _read_scope(self, artifact_id: str, start_byte: int):
        metadata = self.journal.get_artifact(self.workspace_id, artifact_id)
        if metadata is None:
            raise ArtifactError(ArtifactErrorCode.MISSING, "artifact metadata is missing")
        if metadata.state is not ArtifactState.AVAILABLE:
            code = (
                ArtifactErrorCode.MISSING
                if metadata.state is ArtifactState.MISSING
                else ArtifactErrorCode.INTEGRITY
            )
            raise ArtifactError(code, "artifact is not available")
        if start_byte < 0 or start_byte > metadata.byte_size:
            raise ArtifactError(ArtifactErrorCode.INVALID, "artifact read offset is invalid")
        try:
            yield metadata
        except ArtifactIntegrityError as exc:
            target = (
                ArtifactState.MISSING
                if exc.code is ArtifactErrorCode.MISSING
                else ArtifactState.CORRUPT
            )
            self._try_mark(metadata, target)
            raise

    def finalize_staging(self, artifact_id: str) -> ArtifactMetadata:
        """Finish only a staging row whose already-published final bytes verify."""

        metadata = self.journal.get_artifact(self.workspace_id, artifact_id)
        if metadata is None:
            raise ArtifactError(ArtifactErrorCode.MISSING, "artifact metadata is missing")
        if metadata.state is not ArtifactState.STAGING:
            return metadata
        try:
            self.filesystem.verify(metadata)
        except ArtifactIntegrityError as exc:
            if exc.code is not ArtifactErrorCode.MISSING:
                self._try_mark(metadata, ArtifactState.CORRUPT)
            return self.journal.get_artifact(self.workspace_id, artifact_id) or metadata
        updated = metadata.model_copy(
            update={
                "state": ArtifactState.AVAILABLE,
                "row_version": metadata.row_version + 1,
                "updated_at": self.clock(),
            }
        )
        return self.journal.save_artifact(
            self.workspace_id, updated, expected_row_version=metadata.row_version
        )

    def restore_staging_bytes(self, content: bytes, *, artifact_id: str) -> ArtifactMetadata:
        """Republish the already-known expected bytes for a staging row, then finalize.

        Only the deterministic Workflow replay path knows the expected bytes for a
        reserved identity; conflicting bytes or metadata are reported, never overwritten.
        """

        metadata = self.journal.get_artifact(self.workspace_id, artifact_id)
        if metadata is None:
            raise ArtifactError(ArtifactErrorCode.MISSING, "artifact metadata is missing")
        if metadata.state is not ArtifactState.STAGING:
            return metadata
        if (
            not isinstance(content, bytes)
            or len(content) != metadata.byte_size
            or sha256_digest(content) != metadata.sha256
        ):
            raise ArtifactError(
                ArtifactErrorCode.CONFLICT, "staging recovery bytes do not match the reservation"
            )
        try:
            self.filesystem.republish_staging(metadata, content)
        except ArtifactIntegrityError:
            self._try_mark(metadata, ArtifactState.CORRUPT)
            raise
        return self.finalize_staging(artifact_id)

    recover_staging = finalize_staging

    def pin(self, artifact_id: str) -> ArtifactMetadata:
        return self._change_retention(artifact_id, ArtifactRetention.PINNED)

    def unpin(self, artifact_id: str) -> ArtifactMetadata:
        return self._change_retention(artifact_id, ArtifactRetention.STANDARD)

    def orphan_report(self) -> ArtifactOrphanReport:
        metadata = self.journal.list_artifacts(self.workspace_id)
        references = frozenset(
            item[0] for item in self.journal.list_artifact_references(self.workspace_id)
        )
        report = self.filesystem.orphan_report(metadata, referenced_ids=references)
        missing_or_corrupt = []
        for item in metadata:
            if item.state is not ArtifactState.AVAILABLE:
                continue
            try:
                self.filesystem.verify(item)
            except ArtifactIntegrityError as exc:
                missing_or_corrupt.append(
                    ArtifactOrphanCandidate(
                        item.artifact_id,
                        self.filesystem.existing_final_path(item.artifact_id),
                        exc.code.value,
                    )
                )
        if not missing_or_corrupt:
            return report
        return ArtifactOrphanReport((*report.candidates, *missing_or_corrupt))

    def retention_report(self) -> ArtifactRetentionReport:
        metadata = self.journal.list_artifacts(self.workspace_id)
        referenced = frozenset(
            item[0] for item in self.journal.list_artifact_references(self.workspace_id)
        )
        pinned = tuple(
            sorted(
                item.artifact_id for item in metadata if item.retention is ArtifactRetention.PINNED
            )
        )
        candidates = tuple(
            sorted(
                item.artifact_id
                for item in metadata
                if item.artifact_id not in referenced
                and item.retention is ArtifactRetention.STANDARD
            )
        )
        return ArtifactRetentionReport(
            referenced=tuple(sorted(referenced)), pinned=pinned, candidates=candidates
        )

    def _change_retention(self, artifact_id: str, retention: ArtifactRetention) -> ArtifactMetadata:
        current = self.journal.get_artifact(self.workspace_id, artifact_id)
        if current is None:
            raise ArtifactError(ArtifactErrorCode.MISSING, "artifact metadata is missing")
        if current.retention is retention:
            return current
        updated = current.model_copy(
            update={
                "retention": retention,
                "row_version": current.row_version + 1,
                "updated_at": self.clock(),
            }
        )
        return self.journal.save_artifact(
            self.workspace_id, updated, expected_row_version=current.row_version
        )

    def _try_mark(self, metadata: ArtifactMetadata, state: ArtifactState) -> None:
        current = self.journal.get_artifact(self.workspace_id, metadata.artifact_id)
        if (
            current is None
            or current.state is not ArtifactState.AVAILABLE
            and state is not ArtifactState.CORRUPT
        ):
            return
        if current.state is state:
            return
        try:
            updated = current.model_copy(
                update={
                    "state": state,
                    "row_version": current.row_version + 1,
                    "updated_at": self.clock(),
                }
            )
            self.journal.save_artifact(
                self.workspace_id, updated, expected_row_version=current.row_version
            )
        except (StorageError, ArtifactError):
            return

    def _check_fault(self, point: str) -> None:
        if self.faults is not None:
            self.faults.check(point)

    @staticmethod
    def _refuse_secrets(content: bytes) -> None:
        text = content.decode("utf-8", errors="replace")
        refuse_secret_material(text, label="artifact content")

    @classmethod
    def _refuse_unredacted_secrets(cls, content: bytes) -> None:
        text = content.decode("utf-8", errors="replace")
        text = cls._remove_redacted_secret_assignments(text)
        refuse_secret_material(text, label="artifact content")

    @staticmethod
    def _remove_redacted_secret_assignments(text: str) -> str:
        text = _REDACTED_SECRET_ASSIGNMENT.sub("", text)
        return _REDACTED_SECRET_TOKEN.sub("", text)
