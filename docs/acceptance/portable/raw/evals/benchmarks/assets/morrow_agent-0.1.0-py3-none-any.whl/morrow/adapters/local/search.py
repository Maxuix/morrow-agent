"""Installed-rg and deterministic stdlib search adapters."""

from __future__ import annotations

import fnmatch
import json
import os
import re
import select
import shutil
import stat
import subprocess
import time
from dataclasses import dataclass
from pathlib import Path

from morrow.core.local_tools import (
    SearchCase,
    SearchEngine,
    SearchMatch,
    SearchQuery,
)
from morrow.runtime.truncation import PI_GREP_MAX_LINE_CHARS, truncate_line

SEARCH_TIMEOUT_SECONDS = 10.0
PYTHON_MAX_ENTRIES = 20_000
PYTHON_MAX_DEPTH = 64
PYTHON_MAX_FILES = 10_000
PYTHON_MAX_BYTES = 32 * 1024 * 1024
MAX_SNIPPET_CHARS = 512


def _snippet(value: str, max_line_chars: int | None) -> str:
    if max_line_chars is None:
        return value[:MAX_SNIPPET_CHARS]
    bounded, _truncated = truncate_line(value, max_line_chars)
    return bounded


class SearchAdapterError(RuntimeError):
    def __init__(self, code: str, message: str) -> None:
        super().__init__(message)
        self.code = code
        self.message = message


@dataclass(frozen=True)
class SearchScan:
    engine: SearchEngine
    matches: tuple[SearchMatch, ...]
    truncated: bool = False
    budget_reason: str | None = None


class LocalSearchAdapter:
    """Run only fixed-argv local searches; never downloads or invokes a shell."""

    def __init__(self, *, rg_path: str | None = None, monotonic=None) -> None:
        self.rg_path = rg_path
        self.monotonic = monotonic or time.monotonic

    def search(
        self,
        *,
        workspace_root: Path,
        search_root: Path,
        relative_root: str,
        query: SearchQuery,
        max_line_chars: int | None = None,
    ) -> SearchScan:
        if max_line_chars is not None and (
            isinstance(max_line_chars, bool)
            or not isinstance(max_line_chars, int)
            or not 1 <= max_line_chars <= PI_GREP_MAX_LINE_CHARS
        ):
            raise SearchAdapterError("invalid_limit", "搜索行长度限制超出边界")
        effective_case = _effective_case(query.case, query.pattern)
        if not query.literal:
            try:
                re.compile(query.pattern, _regex_flags(effective_case))
            except re.error as exc:
                raise SearchAdapterError("invalid_pattern", "正则表达式无效") from exc
        if query.glob is not None:
            _validate_glob(query.glob)
        rg_path = self.rg_path or shutil.which("rg")
        if rg_path:
            try:
                return self._search_rg(
                    workspace_root=workspace_root,
                    relative_root=relative_root,
                    query=query,
                    rg_path=rg_path,
                    max_line_chars=max_line_chars,
                )
            except SearchAdapterError as exc:
                if exc.code != "rg_unavailable":
                    raise
        return self._search_python(
            workspace_root=workspace_root,
            search_root=search_root,
            relative_root=relative_root,
            query=query,
            max_line_chars=max_line_chars,
        )

    def _search_rg(
        self,
        *,
        workspace_root: Path,
        relative_root: str,
        query: SearchQuery,
        rg_path: str,
        max_line_chars: int | None,
    ) -> SearchScan:
        argv = [
            rg_path,
            "--json",
            "--hidden",
            "--no-config",
            "--color=never",
            "--glob",
            "!**/.git/**",
            "--glob",
            "!**/.morrow/**",
            "--glob",
            "!**/.venv/**",
            "--glob",
            "!**/node_modules/**",
            "--glob",
            "!**/{build,dist}/**",
        ]
        if query.literal:
            argv.append("--fixed-strings")
        if query.case is SearchCase.INSENSITIVE:
            argv.append("--ignore-case")
        elif query.case is SearchCase.SENSITIVE:
            argv.append("--case-sensitive")
        else:
            argv.append("--smart-case")
        if query.glob:
            argv.extend(("--glob", query.glob))
        if query.context_lines:
            argv.extend(("--context", str(query.context_lines)))
        # Bind the pattern as the value of --regexp before ending option parsing.
        # The previous ``--regexp -- pattern path`` shape made ripgrep consume
        # ``--`` as the regex and interpret the real pattern as a filesystem path.
        argv.extend(("--regexp", query.pattern, "--", relative_root))
        env = {"PATH": str(Path(rg_path).parent), "LC_ALL": "C.UTF-8", "LANG": "C.UTF-8"}
        deadline = self.monotonic() + SEARCH_TIMEOUT_SECONDS
        try:
            proc = subprocess.Popen(
                argv,
                cwd=workspace_root,
                env=env,
                shell=False,
                stdout=subprocess.PIPE,
                stderr=subprocess.DEVNULL,
            )
        except FileNotFoundError as exc:
            raise SearchAdapterError("rg_unavailable", "rg 不可用") from exc
        except OSError as exc:
            raise SearchAdapterError("search_failed", "本地搜索启动失败") from exc
        try:
            scan, complete = self._parse_rg_output(
                self._rg_output_lines(proc, deadline),
                query=query,
                relative_root=relative_root,
                max_line_chars=max_line_chars,
            )
        except BaseException:
            proc.kill()
            proc.wait()
            raise
        if not complete:
            # Enough matches were collected before rg finished emitting; stop
            # the scan instead of letting a high-match tree fill memory.
            proc.terminate()
            try:
                proc.wait(timeout=1)
            except subprocess.TimeoutExpired:
                proc.kill()
                proc.wait()
        else:
            proc.wait()
            if proc.returncode not in (0, 1):
                raise SearchAdapterError("search_failed", "本地搜索失败")
        return scan

    def _rg_output_lines(self, proc: subprocess.Popen, deadline: float):
        """Yield rg stdout lines, bounding the wait by the search deadline.

        Chunks are read with ``read1`` after a ``select`` so the deadline is
        enforced even when ripgrep keeps emitting matches.
        """

        buffer = b""
        while True:
            remaining = deadline - self.monotonic()
            if remaining <= 0:
                raise SearchAdapterError("rg_timeout", "搜索超过本地时间上限")
            ready, _, _ = select.select([proc.stdout], [], [], remaining)
            if not ready:
                raise SearchAdapterError("rg_timeout", "搜索超过本地时间上限")
            chunk = proc.stdout.read1(65536)
            if not chunk:
                if buffer:
                    yield buffer
                return
            buffer += chunk
            while b"\n" in buffer:
                line, buffer = buffer.split(b"\n", 1)
                yield line + b"\n"

    def _parse_rg_output(
        self,
        lines,
        *,
        query: SearchQuery,
        relative_root: str,
        max_line_chars: int | None,
    ) -> tuple[SearchScan, bool]:
        contexts: dict[tuple[str, int], str] = {}
        match_records: list[tuple[str, int, int, str]] = []
        last_match: tuple[str, int] | None = None
        after_lines: set[int] = set()
        complete = True
        for raw_line in lines:
            try:
                event = json.loads(raw_line.decode("utf-8", errors="replace"))
            except (TypeError, ValueError, json.JSONDecodeError):
                continue
            if event.get("type") not in {"match", "context"}:
                if match_records and len(match_records) >= query.max_results:
                    complete = False
                    break
                continue
            data = event.get("data") or {}
            path_data = data.get("path") or {}
            path_text = path_data.get("text")
            line_number = data.get("line_number")
            lines_data = data.get("lines") or {}
            if not isinstance(path_text, str) or not isinstance(line_number, int):
                continue
            relative = _normalize_rg_path(path_text, relative_root)
            snippet = str(lines_data.get("text", "")).rstrip("\r\n")
            contexts[(relative, line_number)] = _snippet(snippet, max_line_chars)
            cap_reached = len(match_records) >= query.max_results
            if event.get("type") != "match":
                # Past the cap only the trailing match's after-context window
                # still matters; anything else ends the scan early.
                if cap_reached and last_match is not None:
                    if (
                        relative == last_match[0]
                        and last_match[1] < line_number <= last_match[1] + query.context_lines
                    ):
                        after_lines.add(line_number)
                        if len(after_lines) >= query.context_lines:
                            complete = False
                            break
                    else:
                        complete = False
                        break
                continue
            if cap_reached:
                complete = False
                break
            submatches = data.get("submatches") or []
            column = int(submatches[0].get("start", 0)) + 1 if submatches else 1
            match_records.append(
                (relative, line_number, column, _snippet(snippet, max_line_chars) or " ")
            )
            last_match = (relative, line_number)
            after_lines = set()
        matches: list[SearchMatch] = []
        for relative, line_number, column, snippet in match_records:
            before = tuple(
                contexts[(relative, number)]
                for number in range(max(1, line_number - query.context_lines), line_number)
                if (relative, number) in contexts
            )
            after = tuple(
                contexts[(relative, number)]
                for number in range(line_number + 1, line_number + query.context_lines + 1)
                if (relative, number) in contexts
            )
            matches.append(
                SearchMatch(
                    path=relative,
                    line=line_number,
                    column=column,
                    snippet=_snippet(snippet, max_line_chars) or " ",
                    before=before,
                    after=after,
                )
            )
            if len(matches) >= query.max_results:
                break
        return SearchScan(
            engine=SearchEngine.RG,
            matches=tuple(matches),
            truncated=len(matches) >= query.max_results,
            budget_reason="max_matches" if len(matches) >= query.max_results else None,
        ), complete

    def _search_python(
        self,
        *,
        workspace_root: Path,
        search_root: Path,
        relative_root: str,
        query: SearchQuery,
        max_line_chars: int | None,
    ) -> SearchScan:
        effective_case = _effective_case(query.case, query.pattern)
        regex = None if query.literal else re.compile(query.pattern, _regex_flags(effective_case))
        needle = (
            query.pattern if effective_case is SearchCase.SENSITIVE else query.pattern.casefold()
        )
        matches: list[SearchMatch] = []
        stack = [(search_root, 0)]
        scanned_entries = 0
        scanned_files = 0
        scanned_bytes = 0
        deadline = self.monotonic() + SEARCH_TIMEOUT_SECONDS
        truncated = False
        reason = None
        while stack:
            if self.monotonic() >= deadline:
                truncated, reason = True, "timeout"
                break
            directory, depth = stack.pop()
            try:
                entries = []
                with os.scandir(directory) as iterator:
                    for entry in iterator:
                        scanned_entries += 1
                        if scanned_entries > PYTHON_MAX_ENTRIES:
                            truncated, reason = True, "max_entries"
                            break
                        if self.monotonic() >= deadline:
                            truncated, reason = True, "timeout"
                            break
                        entries.append(entry)
                if truncated:
                    break
                entries.sort(key=lambda item: (item.name.casefold(), item.name))
            except OSError:
                continue
            for entry in entries:
                if self.monotonic() >= deadline:
                    truncated, reason = True, "timeout"
                    break
                relative = _relative_path(workspace_root, Path(entry.path))
                if _ignored(relative, workspace_root):
                    continue
                try:
                    metadata = entry.stat(follow_symlinks=False)
                except OSError:
                    continue
                if stat.S_ISDIR(metadata.st_mode):
                    if entry.name not in {".git", ".morrow"}:
                        if depth >= PYTHON_MAX_DEPTH:
                            truncated, reason = True, "max_depth"
                            break
                        stack.append((Path(entry.path), depth + 1))
                    continue
                if scanned_files >= PYTHON_MAX_FILES:
                    truncated, reason = True, "max_files"
                    break
                if stat.S_ISLNK(metadata.st_mode):
                    try:
                        target = Path(entry.path).resolve(strict=True)
                        if not target.is_relative_to(workspace_root) or not target.is_file():
                            continue
                        metadata = target.stat()
                        read_path = target
                    except OSError:
                        continue
                elif stat.S_ISREG(metadata.st_mode):
                    read_path = Path(entry.path)
                else:
                    continue
                remaining = PYTHON_MAX_BYTES - scanned_bytes
                if metadata.st_size > remaining:
                    truncated, reason = True, "max_bytes"
                    break
                try:
                    with read_path.open("rb") as source:
                        raw = source.read(remaining + 1)
                except OSError:
                    continue
                if len(raw) > remaining:
                    truncated, reason = True, "max_bytes"
                    break
                scanned_files += 1
                scanned_bytes += len(raw)
                if b"\x00" in raw:
                    continue
                try:
                    text = raw.decode("utf-8", errors="strict")
                except UnicodeDecodeError:
                    continue
                file_lines = text.splitlines()
                for index, line in enumerate(file_lines, start=1):
                    columns = _match_columns(line, needle, regex, effective_case)
                    for column in columns:
                        before = tuple(
                            file_lines[max(0, index - 1 - query.context_lines) : index - 1]
                        )
                        after = tuple(file_lines[index : index + query.context_lines])
                        matches.append(
                            SearchMatch(
                                path=relative,
                                line=index,
                                column=column,
                                snippet=_snippet(line, max_line_chars) or " ",
                                before=tuple(_snippet(item, max_line_chars) for item in before),
                                after=tuple(_snippet(item, max_line_chars) for item in after),
                            )
                        )
                        if len(matches) >= query.max_results:
                            truncated, reason = True, "max_matches"
                            break
                    if truncated:
                        break
                if truncated:
                    break
            if truncated:
                break
        matches.sort(key=lambda item: (item.path.casefold(), item.path, item.line, item.column))
        return SearchScan(
            engine=SearchEngine.PYTHON,
            matches=tuple(matches[: query.max_results]),
            truncated=truncated,
            budget_reason=reason,
        )


def _regex_flags(case: SearchCase) -> int:
    return re.IGNORECASE if case is SearchCase.INSENSITIVE else 0


def _effective_case(case: SearchCase, pattern: str) -> SearchCase:
    if case is SearchCase.SMART:
        return (
            SearchCase.SENSITIVE
            if any(char.isupper() for char in pattern)
            else SearchCase.INSENSITIVE
        )
    return case


def _match_columns(
    line: str, needle: str, regex: re.Pattern[str] | None, case: SearchCase
) -> tuple[int, ...]:
    if regex is not None:
        return tuple(match.start() + 1 for match in regex.finditer(line))
    haystack = line.casefold() if case is SearchCase.INSENSITIVE else line
    positions: list[int] = []
    start = 0
    while True:
        index = haystack.find(needle, start)
        if index < 0:
            return tuple(positions)
        positions.append(index + 1)
        start = index + max(1, len(needle))


def _normalize_rg_path(value: str, relative_root: str) -> str:
    normalized = value.replace("\\", "/")
    if normalized.startswith("./"):
        normalized = normalized[2:]
    if relative_root != "." and normalized == relative_root:
        return relative_root
    return normalized


def _relative_path(root: Path, path: Path) -> str:
    value = path.relative_to(root).as_posix()
    return value or "."


def _validate_glob(value: str) -> None:
    if not value or "\x00" in value or "\\" in value or value.startswith("/"):
        raise SearchAdapterError("invalid_glob", "文件匹配模式无效")
    if any(part == ".." for part in value.split("/")):
        raise SearchAdapterError("invalid_glob", "文件匹配模式无效")


def _ignored(relative: str, root: Path) -> bool:
    for name in (".gitignore", ".ignore", ".rgignore"):
        path = root / name
        try:
            lines = path.read_text(encoding="utf-8").splitlines()
        except (OSError, UnicodeDecodeError):
            continue
        for raw in lines:
            rule = raw.strip()
            if not rule or rule.startswith("#") or rule.startswith("!"):
                continue
            rule = rule.lstrip("/")
            if rule.endswith("/"):
                rule += "*"
            if fnmatch.fnmatchcase(relative, rule) or fnmatch.fnmatchcase(
                Path(relative).name, rule
            ):
                return True
    return False
